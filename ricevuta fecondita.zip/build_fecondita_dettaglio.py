#!/usr/bin/env python3
# ============================================================================
#  build_fecondita_dettaglio.py — RICETTA (Ricevuta CSD, 09/07/2026)
#  Prodotta DAL Magazzino certificato. Ricarica e RIVERIFICA.
#
#  ⚠ UNA FONTE (FE1), OTTO CSV, UNA TABELLA. [P4.4]
#    Chiave unica (provincia, anno); due misure su tre assi + genitore.
#    Con `misura` in COLONNA, tfr ed eta_media non si possono scambiare:
#    l'errore documentato il 28/06 (fecondita_ordine conteneva eta media)
#    diventa impossibile.
#
#  ⚠⚠ LA LEGENDA: "TFR = somma dei quozienti per ogni ETA FECONDA (15-49)".
#     '14-' e '50+' ESISTONO nel dato ma NON entrano nel TFR.
#     Includerli produce 217 falsi ROSSI (Vibo Valentia 2003 straniere:
#     Delta=+0,1227, per un tasso a 50+ di 125 per mille).
#
#  ⚠⚠ IL NOME DI UN FILE MENTE: 'Fecondita eta e ordine ITA' contiene
#     TUTTE le madri, non le italiane. Sigma(15-49)=1,3693 = TFR tutte (1,37),
#     non italiane (1,27). Prova negativa qui sotto.
#
#  [K9] · [P3.B] dtype+indici · [T15] chiave TEXT · [T30] anno INTEGER
#  USO:   python3 build_fecondita_dettaglio.py
#  Prova: ISTAT_DB=/tmp/test.db python3 build_fecondita_dettaglio.py
#  Exit:  0 = verde · 1 = rosso
# ============================================================================
import sqlite3, pandas as pd, os, sys, time

RECEIPT = os.environ.get("RECEIPT", "fecondita_dettaglio.csv.gz")
DB      = os.environ.get("ISTAT_DB", "istat.db")
RIGHE, TERRITORI = 569_580, 108
ANNI = (1999, 2025)
MISURE   = ['eta_media','tfr']
GENITORI = ['madre','padre']
CITT     = ['italiane','straniere','tutte']
ORDINI   = ['1','2','3+','totale']
N_ETA    = 38
PADRI    = 2_796
# saldature: numeri esatti [P4.2]
G_S1, G_S2, G_S3 = 4_968, 87_098, 11_770
# tolleranze: i valori sono arrotondati a 2 decimali
TOL1, TOL2, TOL3 = 0.006, 0.011, 0.013
ANCORE = {2010:1.44, 2020:1.24, 2024:1.18}     # TFR Italia, pubblicati
# ⚠ le eta che NON entrano nel TFR
FUORI = "('totale','14-','50+')"

print(f"RECEIPT: {RECEIPT}\nDB:      {DB}\n")
if not os.path.exists(RECEIPT): print(f"MANCA {RECEIPT}"); sys.exit(1)

df = pd.read_csv(RECEIPT, dtype={"codice":str,"nome":str,"misura":str,"genitore":str,
                                 "cittadinanza":str,"ordine":str,"eta":str},
                 keep_default_na=False, na_values=[])
df["anno"]   = df.anno.astype(int)
df["valore"] = df.valore.astype(float)

con = sqlite3.connect(DB)
con.execute("DROP TABLE IF EXISTS fecondita_dettaglio")
con.execute("""CREATE TABLE fecondita_dettaglio(
  codice TEXT, nome TEXT, anno INTEGER, misura TEXT, genitore TEXT,
  cittadinanza TEXT, ordine TEXT, eta TEXT, valore REAL)""")
t0=time.time()
df.to_sql("fecondita_dettaglio", con, if_exists="append", index=False, chunksize=100_000)
con.execute("CREATE INDEX idx_fecd_cod ON fecondita_dettaglio(codice)")
con.execute("CREATE INDEX idx_fecd_key ON fecondita_dettaglio(codice,anno,misura,cittadinanza,ordine,eta)")
con.commit()
print(f"caricate {len(df):,} righe in {time.time()-t0:.0f}s · indici creati\n")

ok=True
def prova(nome, cond, det=""):
    global ok; ok &= bool(cond)
    print(f"  [{'VERDE' if cond else 'ROSSO'}] {nome}{' — '+det if det else ''}")

print("PROVE")
r=con.execute("SELECT COUNT(*) FROM fecondita_dettaglio").fetchone()[0]
prova("righe", r==RIGHE, f"{r:,}")
t=con.execute("SELECT COUNT(DISTINCT codice) FROM fecondita_dettaglio").fetchone()[0]
prova("108 territori (107 province + Italia)", t==TERRITORI, f"{t}")
a=con.execute("SELECT MIN(anno),MAX(anno) FROM fecondita_dettaglio").fetchone()
prova("anni 1999-2025", a==ANNI, f"{a[0]}-{a[1]}")

for col, att in [("misura",MISURE),("genitore",GENITORI),("cittadinanza",CITT),("ordine",ORDINI)]:
    v=sorted(x[0] for x in con.execute(f"SELECT DISTINCT {col} FROM fecondita_dettaglio"))
    prova(f"  {col}", v==att, str(v))
n=con.execute("SELECT COUNT(DISTINCT eta) FROM fecondita_dettaglio").fetchone()[0]
prova("  38 eta (14-, 15..49, 50+, totale)", n==N_ETA, f"{n}")

prova("typeof(codice)='text' [T15]",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(codice) FROM fecondita_dettaglio")]==["text"])
prova("typeof(anno)='integer' [T30]",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(anno) FROM fecondita_dettaglio")]==["integer"])
prova("Lecco ITC43 presente (chiave NUTS)",
      con.execute("SELECT COUNT(*) FROM fecondita_dettaglio WHERE codice='ITC43'").fetchone()[0]>0)
prova("Trento ITD20 e Bolzano ITD10 (PROVINCIA, non regione [F7])",
      con.execute("SELECT COUNT(DISTINCT codice) FROM fecondita_dettaglio WHERE codice IN ('ITD10','ITD20')").fetchone()[0]==2)

# ⚠⚠ SALDATURA 1 — LA LEGENDA: solo le eta feconde 15-49
print(f"\n  SALDATURA 1 — la LEGENDA: TFR = Sigma dei quozienti per ETA FECONDA (15-49)")
q=f"""SELECT COUNT(*), SUM(ABS(d)>{TOL1}) FROM (
  SELECT (SELECT SUM(valore)/1000.0 FROM fecondita_dettaglio x
      WHERE x.codice=a.codice AND x.anno=a.anno AND x.cittadinanza=a.cittadinanza
        AND x.misura='tfr' AND x.ordine='totale' AND x.eta NOT IN {FUORI})
  - a.valore AS d
  FROM fecondita_dettaglio a
  WHERE a.misura='tfr' AND a.ordine='totale' AND a.eta='totale'
    AND a.cittadinanza IN ('italiane','straniere') AND a.anno BETWEEN 2002 AND 2024)
  WHERE d IS NOT NULL"""
n1,b1 = con.execute(q).fetchone()
prova(f"  Sigma(15-49) == TFR (toll. {TOL1})", n1==G_S1 and (b1 or 0)==0,
      f"{n1:,} confronti, {b1 or 0} oltre soglia")

# prova NEGATIVA: includendo 14- e 50+ DEVONO comparire i falsi rossi
q_neg=f"""SELECT SUM(ABS(d)>{TOL1}) FROM (
  SELECT (SELECT SUM(valore)/1000.0 FROM fecondita_dettaglio x
      WHERE x.codice=a.codice AND x.anno=a.anno AND x.cittadinanza=a.cittadinanza
        AND x.misura='tfr' AND x.ordine='totale' AND x.eta<>'totale')
  - a.valore AS d
  FROM fecondita_dettaglio a
  WHERE a.misura='tfr' AND a.ordine='totale' AND a.eta='totale'
    AND a.cittadinanza IN ('italiane','straniere') AND a.anno BETWEEN 2002 AND 2024)
  WHERE d IS NOT NULL"""
falsi = con.execute(q_neg).fetchone()[0]
prova("  PROVA NEGATIVA: includendo 14- e 50+ compaiono 217 falsi rossi",
      falsi==217, f"{falsi}")
print("       (Vibo Valentia 2003 straniere: Delta=+0,1227, per un tasso a 50+ di 125 per mille)")

# SALDATURA 2
print(f"\n  SALDATURA 2 — 1 + 2 + 3+ == totale (per ogni eta)")
q2=f"""SELECT COUNT(*), SUM(ABS(d)>{TOL2}) FROM (
  SELECT SUM(CASE ordine WHEN '1' THEN valore WHEN '2' THEN valore
                         WHEN '3+' THEN valore ELSE 0 END)
       - SUM(CASE ordine WHEN 'totale' THEN valore ELSE 0 END) AS d
  FROM fecondita_dettaglio WHERE misura='tfr' AND cittadinanza='tutte' AND eta<>'totale'
  GROUP BY codice,anno,eta HAVING COUNT(DISTINCT ordine)=4)"""
n2,b2 = con.execute(q2).fetchone()
prova(f"  1+2+3+ == totale (toll. {TOL2}: 4 arrotondamenti)", n2==G_S2 and (b2 or 0)==0,
      f"{n2:,} gruppi, {b2 or 0} oltre soglia")

# SALDATURA 3 — la MARGINALIZZAZIONE che giustifica la condensazione
print(f"\n  SALDATURA 3 — Sigma(15-49) del completo == 'per ordine'")
print("       (e' la prova che 'eta e ordine' CONTIENE 'per ordine'. [P4.4])")
q3=f"""SELECT COUNT(*), SUM(ABS(d)>{TOL3}) FROM (
  SELECT (SELECT SUM(valore)/1000.0 FROM fecondita_dettaglio x
      WHERE x.codice=a.codice AND x.anno=a.anno AND x.ordine=a.ordine
        AND x.misura='tfr' AND x.cittadinanza='tutte' AND x.eta NOT IN {FUORI})
  - a.valore AS d
  FROM fecondita_dettaglio a
  WHERE a.misura='tfr' AND a.cittadinanza='tutte' AND a.eta='totale'
    AND a.anno BETWEEN 2003 AND 2024 AND a.codice<>'IT')
  WHERE d IS NOT NULL"""
n3,b3 = con.execute(q3).fetchone()
prova(f"  Sigma(15-49) == TFR per ordine (toll. {TOL3})", n3==G_S3 and (b3 or 0)==0,
      f"{n3:,} confronti, {b3 or 0} oltre soglia")

# ⚠⚠ PROVA NEGATIVA: il file 'ITA' contiene TUTTE
print("\n  PROVA NEGATIVA [P4.2] — il file 'eta e ordine ITA' contiene TUTTE le madri")
v=con.execute(f"""SELECT SUM(valore)/1000.0 FROM fecondita_dettaglio
  WHERE codice='ITC11' AND anno=2015 AND misura='tfr' AND cittadinanza='tutte'
    AND ordine='totale' AND eta NOT IN {FUORI}""").fetchone()[0]
ita=con.execute("""SELECT valore FROM fecondita_dettaglio WHERE codice='ITC11' AND anno=2015
  AND misura='tfr' AND cittadinanza='italiane' AND ordine='totale' AND eta='totale'""").fetchone()[0]
tut=con.execute("""SELECT valore FROM fecondita_dettaglio WHERE codice='ITC11' AND anno=2015
  AND misura='tfr' AND cittadinanza='tutte' AND ordine='totale' AND eta='totale'""").fetchone()[0]
prova(f"  Torino 2015: Sigma == TFR TUTTE ({tut}), non italiane ({ita})",
      abs(v-tut)<TOL1 and abs(v-ita)>0.05, f"Sigma={v:.4f}")
print("       (se un domani coincidesse con le italiane, il file e' cambiato)")

print("\n  ancore — TFR Italia (valori pubblicati ISTAT):")
for anno, att in ANCORE.items():
    r=con.execute("""SELECT valore FROM fecondita_dettaglio WHERE codice='IT' AND anno=?
      AND misura='tfr' AND cittadinanza='tutte' AND ordine='totale' AND eta='totale'""",(anno,)).fetchone()
    prova(f"  TFR Italia {anno} = {att}", r and abs(r[0]-att)<0.005, f"{r[0]:.3f}" if r else "assente")

print("\n  eta media dei padri (genitore='padre'):")
n=con.execute("SELECT COUNT(*) FROM fecondita_dettaglio WHERE genitore='padre'").fetchone()[0]
prova(f"  {PADRI:,} valori", n==PADRI, f"{n:,}")
c=sorted(x[0] for x in con.execute("SELECT DISTINCT cittadinanza FROM fecondita_dettaglio WHERE genitore='padre'"))
prova("  i padri hanno solo cittadinanza='tutte' (ISTAT non li scompone)", c==['tutte'], str(c))
mis=sorted(x[0] for x in con.execute("SELECT DISTINCT misura FROM fecondita_dettaglio WHERE genitore='padre'"))
prova("  ...e solo misura='eta_media'", mis==['eta_media'], str(mis))

print("\n  Italia manca nei tre CSV per ordine (ISTAT non lo pubblica):")
n=con.execute("""SELECT COUNT(*) FROM fecondita_dettaglio
  WHERE codice='IT' AND ordine<>'totale'""").fetchone()[0]
prova("  0 righe con codice='IT' e ordine<>'totale'", n==0, f"{n}")

con.close()
print("\nESITO:", "VERDE — fecondita_dettaglio certificato" if ok else "ROSSO — NON usare")
sys.exit(0 if ok else 1)
