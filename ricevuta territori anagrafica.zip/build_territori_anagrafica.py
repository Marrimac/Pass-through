#!/usr/bin/env python3
# ============================================================================
#  build_territori_anagrafica.py — RICETTA (Ricevuta CSD, 09/07/2026)
#  Prodotta DAL Magazzino certificato. Ricarica e RIVERIFICA.
#
#  ⚠ E' IL PONTE. Ogni altro set vi si appoggia per la gerarchia territoriale.
#    Se e' sbagliato, tutte le somme per livello crollano.
#
#  ⚠⚠ IL PONTE CONTIENE LA SOLUZIONE ALLE TRAPPOLE [F7]:
#     · ITDA (Trentino) e' l'UNICA regione SENZA province -> e' l'AGGREGATO
#     · ITCD (Nord) e ITFG (Mezzogiorno) hanno ZERO regioni -> AGGREGATI
#     Il criterio e' NEL DATO, non in un documento.
#
#  [K9] · [P3.B] dtype+indici · [T15] chiave TEXT
#  USO:   python3 build_territori_anagrafica.py
#  Prova: ISTAT_DB=/tmp/test.db python3 build_territori_anagrafica.py
#  Exit:  0 = verde · 1 = rosso
# ============================================================================
import sqlite3, pandas as pd, os, sys

RECEIPT = os.environ.get("RECEIPT", "territori_anagrafica.csv.gz")
DB      = os.environ.get("ISTAT_DB", "istat.db")
RIGHE = 137
CONTA = {"Italia":1, "ripartizione":7, "regione":22, "provincia":107}
# gli aggregati, riconoscibili DAL DATO
REG_AGGREGATA = "ITDA"                    # unica regione senza province
RIP_AGGREGATE = {"ITCD": ("ITC","ITD"), "ITFG": ("ITF","ITG")}
RIP_VERE      = ["ITC","ITD","ITE","ITF","ITG"]
PROV_PER_RIP  = {"ITC":25, "ITD":22, "ITE":22, "ITF":24, "ITG":14}

print(f"RECEIPT: {RECEIPT}\nDB:      {DB}\n")
if not os.path.exists(RECEIPT): print(f"MANCA {RECEIPT}"); sys.exit(1)

# [K9]: i campi vuoti sono stringhe '', non NaN
df = pd.read_csv(RECEIPT, dtype=str, keep_default_na=False, na_values=[])

con = sqlite3.connect(DB)
con.execute("DROP TABLE IF EXISTS territori_anagrafica")
con.execute("""CREATE TABLE territori_anagrafica(
  codice TEXT, nome TEXT, livello TEXT,
  cod_rip TEXT, nome_rip TEXT, cod_reg TEXT, nome_reg TEXT,
  cod_prov TEXT, nome_prov TEXT)""")
df.to_sql("territori_anagrafica", con, if_exists="append", index=False)
con.execute("CREATE INDEX idx_ter_cod ON territori_anagrafica(codice)")
con.execute("CREATE INDEX idx_ter_reg ON territori_anagrafica(cod_reg)")
con.execute("CREATE INDEX idx_ter_rip ON territori_anagrafica(cod_rip)")
con.commit()
print(f"caricate {len(df)} righe · indici creati\n")

ok=True
def prova(nome, cond, det=""):
    global ok; ok &= bool(cond)
    print(f"  [{'VERDE' if cond else 'ROSSO'}] {nome}{' — '+det if det else ''}")

print("PROVE")
r=con.execute("SELECT COUNT(*) FROM territori_anagrafica").fetchone()[0]
prova("righe", r==RIGHE, f"{r}")
for liv, n in CONTA.items():
    v=con.execute("SELECT COUNT(*) FROM territori_anagrafica WHERE livello=?",(liv,)).fetchone()[0]
    prova(f"  {liv}", v==n, f"{v}")
prova("nessun COMUNE (il ponte non scende sotto la provincia)",
      con.execute("SELECT COUNT(*) FROM territori_anagrafica WHERE livello='comune'").fetchone()[0]==0)

prova("typeof(codice)='text' [T15]",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(codice) FROM territori_anagrafica")]==["text"])
prova("campi vuoti sono '' non NULL [K9]",
      con.execute("SELECT COUNT(*) FROM territori_anagrafica WHERE cod_reg IS NULL").fetchone()[0]==0)

# INTEGRITA' REFERENZIALE — il ponte deve chiudersi su se stesso
orf_reg=con.execute("""SELECT COUNT(*) FROM territori_anagrafica t
  WHERE t.cod_reg<>'' AND NOT EXISTS
    (SELECT 1 FROM territori_anagrafica r WHERE r.codice=t.cod_reg)""").fetchone()[0]
prova("integrita': ogni cod_reg esiste come codice", orf_reg==0, f"{orf_reg} orfani")
orf_rip=con.execute("""SELECT COUNT(*) FROM territori_anagrafica t
  WHERE t.cod_rip<>'' AND NOT EXISTS
    (SELECT 1 FROM territori_anagrafica r WHERE r.codice=t.cod_rip)""").fetchone()[0]
prova("integrita': ogni cod_rip esiste come codice", orf_rip==0, f"{orf_rip} orfani")

# ⚠ IL PONTE RICONOSCE GLI AGGREGATI — questo e' il cuore
print("  il ponte riconosce gli AGGREGATI, dal dato:")
q="""SELECT r.codice FROM territori_anagrafica r WHERE r.livello='regione'
     AND NOT EXISTS (SELECT 1 FROM territori_anagrafica p
       WHERE p.livello='provincia' AND p.cod_reg=r.codice)"""
senza = [x[0] for x in con.execute(q)]
prova(f"  '{REG_AGGREGATA}' e' l'UNICA regione senza province [F7]",
      senza==[REG_AGGREGATA], str(senza))
n_reg_vere=con.execute("""SELECT COUNT(DISTINCT cod_reg) FROM territori_anagrafica
  WHERE livello='provincia'""").fetchone()[0]
prova("  -> 21 regioni VERE (non 22)", n_reg_vere==21, f"{n_reg_vere}")

q2="""SELECT r.codice FROM territori_anagrafica r WHERE r.livello='ripartizione'
      AND NOT EXISTS (SELECT 1 FROM territori_anagrafica g
        WHERE g.livello='regione' AND g.cod_rip=r.codice)"""
rip_agg = sorted(x[0] for x in con.execute(q2))
prova(f"  {sorted(RIP_AGGREGATE)} sono le ripartizioni AGGREGATE (0 regioni) [F7]",
      rip_agg==sorted(RIP_AGGREGATE), str(rip_agg))
n_rip_vere=con.execute("""SELECT COUNT(DISTINCT cod_rip) FROM territori_anagrafica
  WHERE livello='provincia'""").fetchone()[0]
prova("  -> 5 ripartizioni VERE (non 7)", n_rip_vere==5, f"{n_rip_vere}")

# le 5 ripartizioni vere coprono TUTTE le 107 province
print("  le 5 ripartizioni vere coprono le 107 province:")
tot=0
for rip, n in PROV_PER_RIP.items():
    v=con.execute("""SELECT COUNT(*) FROM territori_anagrafica
      WHERE livello='provincia' AND cod_rip=?""",(rip,)).fetchone()[0]
    prova(f"  {rip} = {n} province", v==n, f"{v}"); tot+=v
prova("  -> totale 107", tot==107, f"{tot}")

# le province del Trentino puntano a ITD1/ITD2, MAI a ITDA
q3="""SELECT COUNT(*) FROM territori_anagrafica
      WHERE livello='provincia' AND cod_reg='ITDA'"""
prova("nessuna provincia punta a ITDA (l'aggregato)",
      con.execute(q3).fetchone()[0]==0)
q4="""SELECT codice, cod_reg FROM territori_anagrafica
      WHERE livello='provincia' AND cod_reg IN ('ITD1','ITD2') ORDER BY codice"""
tn = [(x[0],x[1]) for x in con.execute(q4)]
prova("Bolzano->ITD1, Trento->ITD2 (le due province autonome)",
      tn==[("ITD10","ITD1"),("ITD20","ITD2")], str(tn))

con.close()
print("\nESITO:", "VERDE — territori_anagrafica certificato" if ok else "ROSSO — NON usare")
sys.exit(0 if ok else 1)
