#!/usr/bin/env python3
# ============================================================================
#  build_nascite.py — RICETTA (Ricevuta CSD, 09/07/2026)
#  Prodotta DAL Magazzino certificato. Ricarica e RIVERIFICA.
#  [K9] · [P3.B] dtype+indici · [T15] chiave TEXT · [T30] anno INTEGER
#  USO:   python3 build_nascite.py
#  Prova: ISTAT_DB=/tmp/test.db python3 build_nascite.py
#  Exit:  0 = verde · 1 = rosso
# ============================================================================
import sqlite3, pandas as pd, os, sys

RECEIPT = os.environ.get("RECEIPT", "nascite.csv.gz")
DB      = os.environ.get("ISTAT_DB", "istat.db")
RIGHE, CODICI = 31_950, 137
ANNI    = list(range(1999, 2025))
LIVELLI = ['Italia','provincia','regione','ripartizione']
SESSI   = ['femmine','maschi','totale']
GRUPPI  = ['italiani','stranieri','tutti']
G_COMPLETI = 10_650
ANCORE = {1999: 537_242, 2010: 561_944, 2024: 369_944}   # nati in Italia

print(f"RECEIPT: {RECEIPT}\nDB:      {DB}\n")
if not os.path.exists(RECEIPT): print(f"MANCA {RECEIPT}"); sys.exit(1)

df = pd.read_csv(RECEIPT, dtype={"codice":str,"nome":str,"livello":str,
                                 "sesso":str,"gruppo":str},
                 keep_default_na=False, na_values=[])
df["anno"]   = df.anno.astype(int)
df["valore"] = df.valore.astype(float)

con = sqlite3.connect(DB)
con.execute("DROP TABLE IF EXISTS nascite")
con.execute("""CREATE TABLE nascite(
  codice TEXT, nome TEXT, livello TEXT, anno INTEGER,
  sesso TEXT, gruppo TEXT, valore REAL)""")
df.to_sql("nascite", con, if_exists="append", index=False)
con.execute("CREATE INDEX idx_nas_cod ON nascite(codice)")
con.execute("CREATE INDEX idx_nas_key ON nascite(codice,anno,sesso,gruppo)")
con.commit()
print(f"caricate {len(df):,} righe · indici creati\n")

ok=True
def prova(nome, cond, det=""):
    global ok; ok &= bool(cond)
    print(f"  [{'VERDE' if cond else 'ROSSO'}] {nome}{' — '+det if det else ''}")

print("PROVE")
r=con.execute("SELECT COUNT(*) FROM nascite").fetchone()[0]
prova("righe", r==RIGHE, f"{r:,}")
c=con.execute("SELECT COUNT(DISTINCT codice) FROM nascite").fetchone()[0]
prova("codici", c==CODICI, f"{c} (province+regioni+ripartizioni+Italia, MAI comuni)")
a=[x[0] for x in con.execute("SELECT DISTINCT anno FROM nascite ORDER BY anno")]
prova("anni 1999-2024", a==ANNI, f"{len(a)} anni")
lv=sorted(x[0] for x in con.execute("SELECT DISTINCT livello FROM nascite"))
prova("4 livelli", lv==LIVELLI, str(lv))
sx=sorted(x[0] for x in con.execute("SELECT DISTINCT sesso FROM nascite"))
prova("sesso", sx==SESSI, str(sx))
gr=sorted(x[0] for x in con.execute("SELECT DISTINCT gruppo FROM nascite"))
prova("gruppo", gr==GRUPPI, str(gr))

prova("typeof(codice)='text' [T15]",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(codice) FROM nascite")]==["text"])
prova("typeof(anno)='integer' [T30]",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(anno) FROM nascite")]==["integer"])
prova("Lecco ITC43 presente (chiave NUTS)",
      con.execute("SELECT COUNT(*) FROM nascite WHERE codice='ITC43'").fetchone()[0]>0)

# SALDATURA 1: italiani + stranieri = tutti
q="""SELECT COUNT(*), SUM(ABS(d)>0.001) FROM (
  SELECT codice,anno,sesso,
    SUM(CASE gruppo WHEN 'tutti'     THEN valore ELSE 0 END)
  - SUM(CASE gruppo WHEN 'italiani'  THEN valore ELSE 0 END)
  - SUM(CASE gruppo WHEN 'stranieri' THEN valore ELSE 0 END) AS d
  FROM nascite GROUP BY codice,anno,sesso HAVING COUNT(DISTINCT gruppo)=3)"""
n,b = con.execute(q).fetchone()
prova("saldatura  italiani + stranieri = tutti",
      n==G_COMPLETI and (b or 0)==0, f"{n:,} gruppi completi, {b or 0} eccezioni")

# SALDATURA 2: M + F = T
q2="""SELECT COUNT(*), SUM(ABS(d)>0.001) FROM (
  SELECT codice,anno,gruppo,
    SUM(CASE sesso WHEN 'maschi'  THEN valore
                   WHEN 'femmine' THEN valore
                   WHEN 'totale'  THEN -valore END) AS d
  FROM nascite GROUP BY codice,anno,gruppo HAVING COUNT(DISTINCT sesso)=3)"""
n2,b2 = con.execute(q2).fetchone()
prova("saldatura  M + F = T", n2==G_COMPLETI and (b2 or 0)==0,
      f"{n2:,} gruppi completi, {b2 or 0} eccezioni")

# CONFRONTO ESTERNO: Sigma province == Italia  ([F3]: mai Sigma comuni — qui non ce ne sono)
print("  confronto esterno — Sigma province == Italia (tutti, totale):")
for anno, att in ANCORE.items():
    sp=con.execute("""SELECT SUM(valore) FROM nascite
      WHERE livello='provincia' AND gruppo='tutti' AND sesso='totale' AND anno=?""",(anno,)).fetchone()[0]
    it=con.execute("""SELECT valore FROM nascite
      WHERE codice='IT' AND gruppo='tutti' AND sesso='totale' AND anno=?""",(anno,)).fetchone()
    prova(f"  {anno}: Sigma province == Italia == {att:,} nati",
          it and abs(sp-it[0])<0.5 and abs(sp-att)<0.5, f"{sp:,.0f}")

# province 103 -> 107 [K17]
p99=con.execute("SELECT COUNT(DISTINCT codice) FROM nascite WHERE livello='provincia' AND anno=1999").fetchone()[0]
p24=con.execute("SELECT COUNT(DISTINCT codice) FROM nascite WHERE livello='provincia' AND anno=2024").fetchone()[0]
prova("province 103 -> 107 [K17]", p99==103 and p24==107, f"{p99} -> {p24}")

con.close()
print("\nESITO:", "VERDE — nascite certificato" if ok else "ROSSO — NON usare")
sys.exit(0 if ok else 1)
