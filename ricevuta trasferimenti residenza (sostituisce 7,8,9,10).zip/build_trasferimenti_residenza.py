#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RICETTA DI BUILD — Set «Trasferimenti di residenza» (ISTAT / ANPR)
===================================================================
Una sola ricevuta per l'intero set. Rigenera TUTTE le tabelle di questo
set che sono state montate in Magazzino con fatica:

  · fuga_cervelli_regioni   ← Tavola 10  (laureati per l'ESTERO, per età)
  · emig_istruzione_regioni ← Tavola  9  (italiani per l'ESTERO, per istruzione)

Le due tavole hanno la STESSA struttura ostica (vedi TRAPPOLE.md): cambiano
solo la dimensione di dettaglio (classe d'età vs livello di istruzione) e il
fatto che la tavola 9 porta una colonna "totale" da escludere.

AUTOPORTANTE: legge i .xlsx grezzi, normalizza, scrive i CSV puliti, carica
in istat.db, e verifica la quadratura.

⚠  Le cinque trappole del set (perché NON entra liscio) — dettaglio in TRAPPOLE.md:
  1. Riga "Italia" CORROTTA nel file (riporta il totale iscritti in entrambi i
     blocchi) → si RICOSTRUISCE sommando le 20 regioni.
  2. Doppio blocco verticale ISCRITTI / CANCELLATI sulle stesse colonne.
  3. Sub-righe "Bolzano/Bozen" e "Trento" (componenti del Trentino-Alto Adige):
     ESCLUDERE dalla somma per non doppiare.
  4. Colonna "totale" presente nelle tavole per istruzione (T9): ESCLUDERE,
     è la somma di basso+medio+alto.
  5. Falso amico: le tavole "_int" (es. T16) sono INTERREGIONALI (interno),
     non estero — i loro totali nazionali iscritti/cancellati si CONSERVANO.
     Quadratura-spia: per l'estero iscritti != cancellati.
"""
import pandas as pd, sqlite3, os

SRC = os.environ.get('SRC_DIR', '.')
DB  = os.environ.get('ISTAT_DB', '/tmp/estint/istat.db')
OUT = os.environ.get('OUT_DIR', '.')

SUBROWS = {'Bolzano/Bozen', 'Trento'}
SKIP    = {'REGIONI', 'PAESI', 'ISCRITTI', 'CANCELLATI', 'nan', ''}

def normalizza(path, dim_col, dim_validi):
    """Normalizza una tavola del set in formato lungo:
         territorio · tipo · <dim_col> · anno · valore   (Italia ricostruita).
       dim_col   = nome della dimensione di dettaglio ('classe_eta' o 'istruzione')
       dim_validi= insieme dei valori ammessi (esclude 'totale' e simili)."""
    raw = pd.read_excel(path, header=None)
    anni = raw.iloc[1].ffill()
    dim  = raw.iloc[2]
    colmap = {}
    for j in range(1, raw.shape[1]):
        a, d = anni.iloc[j], dim.iloc[j]
        if pd.notna(a) and pd.notna(d) and str(d).strip().lower() in dim_validi:
            colmap[j] = (str(int(float(a))), str(d).strip().lower()
                         if dim_col == 'istruzione' else str(d).strip())
    sez = {}
    for i in range(raw.shape[0]):
        v = str(raw.iloc[i, 0]).strip().upper()
        if v in ('ISCRITTI', 'CANCELLATI'):
            sez[v] = i
    blocchi = sorted(sez.items(), key=lambda kv: kv[1])
    righe = []
    for k, (tipo, start) in enumerate(blocchi):
        end = blocchi[k + 1][1] if k + 1 < len(blocchi) else raw.shape[0]
        italia = {}
        for r in range(start + 1, end):
            nome = str(raw.iloc[r, 0]).strip()
            if nome in SKIP or nome in SUBROWS or nome.upper() in ('ITALIA', 'TOTALE'):
                continue
            for j, (anno, val) in colmap.items():
                v = raw.iloc[r, j]
                if isinstance(v, (int, float)) and pd.notna(v):
                    righe.append({'territorio': nome, 'tipo': tipo.lower(),
                                  dim_col: val, 'anno': int(anno), 'valore': float(v)})
                    italia[(anno, val)] = italia.get((anno, val), 0) + v
        for (anno, val), tot in italia.items():
            righe.append({'territorio': 'Italia', 'tipo': tipo.lower(),
                          dim_col: val, 'anno': int(anno), 'valore': float(tot)})
    return pd.DataFrame(righe)

# definizione delle tabelle del set (tavola, file, nome db, dimensione, valori)
TABELLE = [
    ('Tavola 10', 'tavola10_serie_istr.xlsx', 'fuga_cervelli_regioni',
     'classe_eta', {'0-24', '25-34', '35-64', '65+'}),
    ('Tavola 9',  'tavola9_serie_istr.xlsx',  'emig_istruzione_regioni',
     'istruzione', {'basso', 'medio', 'alto'}),
]

# ----- secondo schema: tavole per PAESE con aggregati continentali (T7/T8) -----
# Struttura diversa: blocco singolo (solo iscritti O solo cancellati), niente
# riga Italia, ma righe-aggregato continentali da ESCLUDERE (vedi TRAPPOLE.md #6).
AGG_CONTINENTI = {'Europa', 'EU27 (2020)', 'Extra EU27 (2020)', 'EU28 (2007-2020)',
                  'Extra EU28 (2007-2020)', 'Africa', 'Asia', 'America', 'Oceania',
                  'di cui:', 'ISCRITTI', 'CANCELLATI', 'PAESI', 'Apolidi', 'Totale'}
TABELLE_PAESE = [   # (tavola, file, tipo)  → confluiscono tutte in migr_stranieri_naz
    ('Tavola 7', 'tavola7_serie.xlsx', 'iscritti'),
    ('Tavola 8', 'tavola8_serie.xlsx', 'cancellati'),
]

def normalizza_paese(path, tipo):
    """Tavole stranieri per nazionalità (un solo blocco). Esclude gli aggregati
       continentali, tiene i singoli paesi."""
    raw = pd.read_excel(path, header=None)
    anni = raw.iloc[1].tolist()
    colmap = {j: int(float(anni[j])) for j in range(1, raw.shape[1])
              if str(anni[j]).replace('.0', '').strip().isdigit()}
    righe = []
    for r in range(2, raw.shape[0]):
        nome = str(raw.iloc[r, 0]).strip()
        if nome in AGG_CONTINENTI or nome == 'nan' or not nome:
            continue
        for j, anno in colmap.items():
            v = raw.iloc[r, j]
            if isinstance(v, (int, float)) and pd.notna(v):
                righe.append({'paese': nome, 'tipo': tipo, 'anno': anno, 'valore': float(v)})
    return pd.DataFrame(righe)

def main():
    con = sqlite3.connect(DB)
    for etichetta, fname, dbname, dim_col, dim_validi in TABELLE:
        df = normalizza(os.path.join(SRC, fname), dim_col, dim_validi)
        # quadratura-spia: per l'estero iscritti != cancellati
        q = df[df.territorio == 'Italia'].groupby('tipo').valore.sum()
        assert q.get('iscritti', 0) != q.get('cancellati', 0), \
            f"{etichetta}: totali iscritti/cancellati IDENTICI → file interno, non estero!"
        # CSV pulito
        p = os.path.join(OUT, dbname + '.csv'); df.to_csv(p, index=False)
        # carica in Magazzino
        df.to_sql(dbname, con, if_exists='replace', index=False)
        n = con.execute(f"SELECT COUNT(*) FROM {dbname}").fetchone()[0]
        print(f"  {etichetta:10} → {dbname:26} {n:>6,} righe  "
              f"(rientri {int(q['iscritti']):,} ≠ partenze {int(q['cancellati']):,})")

    # tabella stranieri per nazionalità: T7 (iscritti) + T8 (cancellati) → una tabella
    parti = [normalizza_paese(os.path.join(SRC, fname), tipo)
             for _, fname, tipo in TABELLE_PAESE]
    naz = pd.concat(parti, ignore_index=True)
    p = os.path.join(OUT, 'migr_stranieri_naz.csv'); naz.to_csv(p, index=False)
    naz.to_sql('migr_stranieri_naz', con, if_exists='replace', index=False)
    nn = con.execute("SELECT COUNT(*) FROM migr_stranieri_naz").fetchone()[0]
    npa = con.execute("SELECT COUNT(DISTINCT paese) FROM migr_stranieri_naz").fetchone()[0]
    print(f"  Tavole 7+8 → migr_stranieri_naz         {nn:>6,} righe  ({npa} nazionalità)")

    con.commit(); con.close()
    print("FATTO — set «Trasferimenti di residenza» installato in Magazzino.")

if __name__ == '__main__':
    main()
