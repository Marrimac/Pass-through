# TRAPPOLE — Set «Trasferimenti di residenza» (ISTAT / ANPR)

Ricevuta **unica per set**. Copre tutte le tabelle di questo set montate in
Magazzino con fatica. Le tavole condividono strutture ostiche: la fatica vera è
stata decifrarle una volta, e questa nota la congela per sempre.

Fonte: ISTAT, *Trasferimenti di residenza* — Migrazioni interne e
internazionali della popolazione residente (registro ANPR), arco 2002–2024
(le tavole per istruzione/età/sesso: 2013–2024, provvisorie).

## Tabelle del set attualmente in Magazzino

| tabella db | tavola/e | contenuto | righe |
|---|---|---|---|
| `fuga_cervelli_regioni`   | T10   | italiani laureati da/per estero, per regione ed **età** | 2.001 |
| `emig_istruzione_regioni` | T9    | italiani da/per estero, per regione e **istruzione** | 1.512 |
| `migr_stranieri_naz`      | T7+T8 | **stranieri** iscritti/cancellati da/per estero, per **nazionalità** | 966 |

Due strutture diverse, due funzioni di normalizzazione nello script:
- T9/T10 (per regione): doppio blocco, riga Italia da ricostruire → `normalizza`.
- T7/T8 (per nazionalità): blocco singolo, aggregati continentali → `normalizza_paese`.

---

## Le trappole del set

**1. Riga «Italia» CORROTTA (T9/T10).**
Riporta lo stesso numero — il totale degli *iscritti* — in entrambi i blocchi.
=> Italia va RICOSTRUITA sommando le 20 regioni, separatamente per tipo.

**2. Doppio blocco verticale ISCRITTI/CANCELLATI (T9/T10).**
Due blocchi impilati sulle stesse colonne (ISCRITTI ~4-26, CANCELLATI ~31-53).

**3. Sub-righe Bolzano/Trento da NON doppiare (T9/T10).**
Componenti del Trentino-Alto Adige: escluse dalla somma (`SUBROWS`).

**4. Colonna «totale» nelle tavole per istruzione (T9).**
`basso . medio . alto . totale`: la colonna `totale` è la somma, va esclusa.

**5. Il falso amico «_int» = INTERNO, non estero (T16 ecc.).**
Migrazione interregionale: i totali nazionali iscritti/cancellati COINCIDONO
(sistema chiuso). NON è la fuga all'estero. Quadratura-spia nello script
(`assert iscritti != cancellati`): scatta se si dà in pasto una tavola interna.

**6. Aggregati continentali mescolati ai paesi (T7/T8).**
Le tavole per nazionalità elencano, insieme ai singoli paesi, righe-aggregato:
`Europa, EU27, Extra EU27, EU28, Extra EU28, Africa, Asia, America` e separatori
`di cui:`. Sommando tutto si raddoppia. => si tengono SOLO i singoli paesi
(`AGG_CONTINENTI` li esclude). La tabella contiene quindi le ~21 nazionalità
nominate, non un totale nazionale.

---

## Numeri-chiave di controllo

- `fuga_cervelli_regioni` (laureati 25-34, Italia): saldo netto +6.047 (2013)
  -> +20.706 (2024); tutte le età +30.503 (2024).
- `emig_istruzione_regioni` (Italia): quota istruzione **alta** fra i cancellati
  23,8% (2013) -> 31,7% (2024); fra gli iscritti 24,3% (2024).
- `migr_stranieri_naz` (saldo 2024 = iscritti-cancellati): Bangladesh +29.907,
  Romania +7.813 (con partenze 15.335, di gran lunga le più alte: la Romania è UE).

## Cosa NON entra in Magazzino (e perché)

- **Tavole italiani per paese** (T12 istruzione, T13 laureati/età): i totali non
  riconciliano con le tavole per regione (aggregati continentali + asimmetrie).
  Si usano solo in lettura per la *classifica* delle destinazioni, mai come
  conteggi assoluti.
- **Tavole «_int»** (interregionali, T15-17): vedi trappola 5. Materiale per
  un'eventuale analisi futura del divario Sud->Nord, non per la fuga all'estero.

## Come rigenerare l'intero set

```
SRC_DIR="<cartella con le tavole grezze>" \
OUT_DIR="." \
ISTAT_DB="/tmp/estint/istat.db" \
python3 build_trasferimenti_residenza.py
```

Per aggiungere altre tavole: estendi `TABELLE` (per regione) o `TABELLE_PAESE`
(per nazionalità) in fondo allo script.
