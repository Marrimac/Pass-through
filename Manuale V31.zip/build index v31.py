#!/usr/bin/env python3
import os, subprocess, zipfile, re, json, html, unicodedata
from pypdf import PdfReader

DOCX = "Manuale_API_ISTAT_Popolazione_v31.docx"
PDF  = "Manuale_API_ISTAT_Popolazione_v31.pdf"
ENV_NODE = {**os.environ, "NODE_PATH": "/home/claude/work/node_modules"}
ENV_LO   = {**os.environ, "HOME": "/home/claude"}

def render():
    subprocess.run(["node", "genera_manuale_v31.js"], env=ENV_NODE, check=True)
def to_pdf():
    subprocess.run(["soffice","--headless","-env:UserInstallation=file:///tmp/lo",
                    "--convert-to","pdf","--outdir",".",DOCX],
                   env=ENV_LO, check=True, capture_output=True)

def extract_headings():
    xml = zipfile.ZipFile(DOCX).read("word/document.xml").decode("utf-8")
    out = []
    for p in re.findall(r"<w:p\b.*?</w:p>", xml, re.S):
        m = re.search(r'<w:pStyle w:val="Heading([123])"/>', p)
        if not m: continue
        t = "".join(re.findall(r"<w:t[^>]*>(.*?)</w:t>", p, re.S))
        t = html.unescape(t)
        t = re.sub(r"\s+", " ", t).strip()
        if not t or t == "Indice": continue
        out.append({"level": int(m.group(1)), "title": t, "page": None})
    return out

def key(s):
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    return re.sub(r"[^0-9a-zA-Z]", "", s).lower()
def footer(t):
    m = re.findall(r"pag\.?\s*(\d+)", t)
    return int(m[-1]) if m else None

def map_pages(toc):
    pages = [(p.extract_text() or "") for p in PdfReader(PDF).pages]
    pk = [key(t) for t in pages]
    ch1 = key(toc[0]["title"])
    occ = [i for i, k in enumerate(pk) if ch1 in k]
    start = occ[1] if len(occ) >= 2 else (occ[0] if occ else 0)
    cur = start; miss = []; res = []
    for e in toc:
        tk = key(e["title"]); f = None
        for i in range(cur, len(pk)):
            if tk and tk in pk[i]: f = i; break
        if f is None:
            for i in range(cur, len(pk)):
                if tk[:18] and tk[:18] in pk[i]: f = i; break
        if f is None: f = cur; miss.append(e["title"])
        fn = footer(pages[f]); res.append(fn if fn else f + 1); cur = f
    return res, miss

# 1) titoli puliti
toc = extract_headings()
json.dump(toc, open("toc.json", "w"), ensure_ascii=False, indent=0)
print("titoli:", len(toc), "| con apostrofo:", sum("'" in e["title"] for e in toc))

# 2) render indice a lunghezza piena (pagine nulle) + PDF di misura
render(); to_pdf()

# 3) misura pagine
pp, miss = map_pages(toc)
for e, pg in zip(toc, pp): e["page"] = pg
json.dump(toc, open("toc.json", "w"), ensure_ascii=False, indent=0)
print("non agganciati (misura):", len(miss), miss[:4])

# 4) render definitivo
render()

# 5) verifica indipendente sul definitivo
to_pdf()
pp2, miss2 = map_pages(toc)
mism = [(e["title"], e["page"], q) for e, q in zip(toc, pp2) if e["page"] != q]
print("non agganciati (verifica):", len(miss2))
print("DISCREPANZE indice-vs-realtà:", len(mism))
for t, claim, real in mism[:10]:
    print(f"   '{t[:48]}'  indice={claim}  reale={real}")
print("OK" if not mism and not miss else "DA CONTROLLARE")
