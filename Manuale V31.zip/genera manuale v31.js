const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  AlignmentType, LevelFormat, HeadingLevel, BorderStyle, WidthType,
  ShadingType, PageNumber, Footer, TableOfContents, TabStopType, LeaderType
} = require("docx");

// ===== misure pagina A4 =====
const PW = 11906, PH = 16838, MARG = 1418;          // A4, margini ~2,5 cm
const CW = PW - 2 * MARG;                            // larghezza utile = 9070 DXA

// ===== helper testo =====
const P = (text, opts = {}) => new Paragraph({
  spacing: { after: 140, line: 288 }, alignment: opts.align,
  children: Array.isArray(text) ? text : [new TextRun({ text, ...opts })],
});
const R   = (text, opts = {}) => new TextRun({ text, ...opts });
const M   = (text) => new TextRun({ text, font: "Consolas", size: 20 });   // mono inline
const B   = (text) => new TextRun({ text, bold: true });
const I   = (text) => new TextRun({ text, italics: true });
const H1  = (text) => new Paragraph({ heading: HeadingLevel.HEADING_1, pageBreakBefore: true, children: [new TextRun(text)] });
const H1n = (text) => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(text)] });
const H2  = (text) => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(text)] });
const H3  = (text) => new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun(text)] });
const BULLET = (children) => new Paragraph({
  numbering: { reference: "bul", level: 0 }, spacing: { after: 90, line: 288 },
  children: Array.isArray(children) ? children : [new TextRun(children)],
});

// ===== code box (riquadro grigio bordato, monospazio) =====
const cb = { style: BorderStyle.SINGLE, size: 2, color: "D0D7DE" };
function codeBox(src) {
  const lines = src.replace(/^\n/, "").replace(/\n$/, "").split("\n");
  const paras = lines.map((line) => {
    const m = line.match(/^(\s*)(.*)$/);
    const indent = m[1].replace(/ /g, "\u00A0");
    return new Paragraph({ spacing: { after: 0, line: 240 },
      children: [new TextRun({ text: (indent + m[2]) || "\u00A0", font: "Consolas", size: 18 })] });
  });
  return new Table({
    width: { size: CW, type: WidthType.DXA }, columnWidths: [CW],
    rows: [new TableRow({ children: [new TableCell({
      borders: { top: cb, bottom: cb, left: cb, right: cb },
      shading: { fill: "F6F8FA", type: ShadingType.CLEAR },
      margins: { top: 110, bottom: 110, left: 150, right: 150 },
      children: paras })] })],
  });
}

// ===== riquadro/callout (filetto laterale colorato + sfondo tenue) =====
function callout(paras, fill, accent) {
  const thin = { style: BorderStyle.SINGLE, size: 2, color: accent };
  return new Table({
    width: { size: CW, type: WidthType.DXA }, columnWidths: [CW],
    rows: [new TableRow({ children: [new TableCell({
      borders: { left: { style: BorderStyle.SINGLE, size: 18, color: accent }, top: thin, bottom: thin, right: thin },
      shading: { fill, type: ShadingType.CLEAR },
      margins: { top: 130, bottom: 130, left: 180, right: 170 },
      children: paras })] })],
  });
}
const info = (paras) => callout(paras, "EAF1FB", "2E5496");   // azzurro
const warn = (paras) => callout(paras, "FBF1DD", "C8902A");   // ambra (⚠)

// ===== tabella dati =====
const bd = { style: BorderStyle.SINGLE, size: 1, color: "BFBFBF" };
const bds = { top: bd, bottom: bd, left: bd, right: bd };
function cell(content, w, head) {
  const kids = Array.isArray(content) ? content : [new TextRun({ text: String(content), bold: !!head, size: 19 })];
  return new TableCell({
    borders: bds, width: { size: w, type: WidthType.DXA },
    shading: head ? { fill: "D9E2F3", type: ShadingType.CLEAR } : undefined,
    margins: { top: 55, bottom: 55, left: 110, right: 110 },
    children: [new Paragraph({ spacing: { after: 0, line: 252 }, children: kids })],
  });
}
function table(rows, widths) {
  return new Table({
    width: { size: widths.reduce((a, b) => a + b, 0), type: WidthType.DXA },
    columnWidths: widths,
    rows: rows.map((r, ri) => new TableRow({
      tableHeader: ri === 0,
      children: r.map((c, ci) => cell(c, widths[ci], ri === 0)),
    })),
  });
}
const SP = () => new Paragraph({ spacing: { after: 60 }, children: [new TextRun("")] });

// ============================================================
//  CONTENUTO DEL CAMPIONE
// ============================================================
// ===== SCRIPT certificati (appendice) =====
const S1_FETCH = `
# === SCRIPT 1 - FETCH cubo CORRENTE (a range) -> ricevuta ===
# Cubo 22_289_DF_DCIS_POPRES1_1 (2019->oggi). DA_ANNO/A_ANNO impostati da Claude.
# Bug +1: una richiesta DA..A rende anche A+1 (2019..2021 -> 2019..2022).
from pathlib import Path
import sdmx, time

DA_ANNO, A_ANNO = 2019, 2021

istat = sdmx.Client("ISTAT", timeout=120)
t0 = time.time()
risposta = istat.data("22_289_DF_DCIS_POPRES1_1", key="A..JAN..TOTAL.99",
                      params={"startPeriod": str(DA_ANNO), "endPeriod": str(A_ANNO)})
tab = sdmx.to_pandas(risposta).reset_index()
print(f"fetch {time.time()-t0:.1f}s | {tab.shape} | anni {sorted(tab['TIME_PERIOD'].unique())}")
ric = Path("ISTAT") / "ricevute"; ric.mkdir(parents=True, exist_ok=True)
tab.to_csv(ric / f"fetch_full_{DA_ANNO}.csv", index=False)
print("salvata:", ric / f"fetch_full_{DA_ANNO}.csv")
`;

const S2_STORICO = `
# === SCRIPT 2 - FETCH cubo STORICO a bocconi -> ricevute ===
# Cubo 164_164_DF_DCIS_RICPOPRES2011_1 (2001->2019). Chiave nell'ordine del cubo storico:
# FREQ.REF_AREA.DATA_TYPE.AGE.SEX.CITIZENSHIP -> "A..JAN.TOTAL..TOTAL" (totali).
# Bocconi da 3 anni: il server crolla su risposte grandi. Si nominano fetch_full_{anno}:
# la ricostruzione (Script 3) li fonde col corrente, perche' ridotti ai totali hanno la stessa grana.
import sdmx, time
import pandas as pd
from pathlib import Path

STO = "164_164_DF_DCIS_RICPOPRES2011_1"
RIC = Path("ISTAT") / "ricevute"; RIC.mkdir(parents=True, exist_ok=True)
istat = sdmx.Client("ISTAT", timeout=120)
BOCCONI = [(2007, 2009), (2010, 2012), (2013, 2015), (2016, 2018)]

for da, a in BOCCONI:
    nome = RIC / f"fetch_full_{da}.csv"
    if nome.exists():
        print(f"{da}-{a}: gia' in casa, salto."); continue
    print(f"Boccone {da}-{a} ...")
    try:
        t0 = time.time()
        risp = istat.data(STO, key="A..JAN.TOTAL..TOTAL",
                          params={"startPeriod": str(da), "endPeriod": str(a)})
        tab = sdmx.to_pandas(risp).reset_index()
        tab["TIME_PERIOD"] = tab["TIME_PERIOD"].astype(int)
        tab = tab[(tab["TIME_PERIOD"] >= da) & (tab["TIME_PERIOD"] <= a)]   # neutralizzo il +1
        print(f"  {time.time()-t0:.1f}s | righe {tab.shape[0]} | anni {sorted(tab['TIME_PERIOD'].unique())}")
        tab.to_csv(nome, index=False)
    except Exception as e:
        print(f"  FALLITO ({type(e).__name__}). Rilancia: i bocconi presi vengono saltati.")
    time.sleep(3)
`;

const S3_RICOSTR = `
# === SCRIPT 3 - RICOSTRUZIONE consolidante: fonde TUTTE le ricevute ===
# Magazzino unico (SQLite) + vista larga. Idempotente. Gestisce schemi misti
# (corrente con MARITAL_STATUS, storico con CITIZENSHIP): usa solo REF_AREA/SEX/TIME_PERIOD/value.
from pathlib import Path
import pandas as pd, sqlite3, shutil

BASE = Path("ISTAT"); RICEVUTE = BASE / "ricevute"; VISTE = BASE / "viste"
RICEVUTE.mkdir(parents=True, exist_ok=True); VISTE.mkdir(exist_ok=True)
for f in BASE.glob("fetch_full_*.csv"):
    d = RICEVUTE / f.name
    if not d.exists(): shutil.move(str(f), str(d))

files = sorted(RICEVUTE.glob("fetch_full_*.csv"))
print("Ricevute fuse:", [f.name for f in files])
grezzo = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
grezzo = grezzo.drop_duplicates(subset=["REF_AREA", "SEX", "TIME_PERIOD"])

terr = pd.read_csv(BASE / "territori_istat.csv", keep_default_na=False, na_values=[])
nome = dict(zip(terr["codice"].astype(str), terr["nome_it"].astype(str)))
parent = dict(zip(terr["codice"].astype(str), terr["parent"].astype(str)))
def livello(code):
    if code == "IT": return "Italia"
    p, c = 0, code
    while c != "IT" and p < 12:
        c = parent.get(c); p += 1
        if c is None or c == "nan": return "altro"
    return {1:"ripartizione", 2:"regione", 3:"provincia"}.get(p, "altro")

ez = {1:"maschi", 2:"femmine", 9:"totale"}; cod = grezzo["REF_AREA"].astype(str)
lungo = pd.DataFrame({"codice":cod, "nome":cod.map(nome), "livello":cod.map(livello),
    "anno":grezzo["TIME_PERIOD"].astype(int), "sesso":grezzo["SEX"].astype(int).map(ez),
    "valore":grezzo["value"].astype(int)})
con = sqlite3.connect(str(BASE / "istat.db"))
lungo.to_sql("popolazione", con, if_exists="replace", index=False)
rip = pd.read_sql_query("SELECT * FROM popolazione", con); con.close()

prov = rip[rip.livello == "provincia"]
larga = prov.pivot(index=["codice","nome"], columns=["anno","sesso"], values="valore")
anni = sorted({a for a, s in larga.columns})
larga = larga.reindex(columns=pd.MultiIndex.from_tuples(
    [(a, s) for a in anni for s in ["maschi","femmine","totale"]], names=["anno","sesso"]))
larga.to_csv(VISTE / "vista_province.csv")
sp = prov.pivot_table(index="anno", columns="sesso", values="valore", aggfunc="sum")
it = rip[rip.livello == "Italia"].pivot_table(index="anno", columns="sesso", values="valore")
print(f"Ricostruito: anni {anni}, vista {larga.shape}")
print("Province == Italia su ogni anno?", bool((sp.sort_index(axis=1) == it.sort_index(axis=1)).all().all()))
`;

const S4_ANAGRAFICA = `
# === SCRIPT 4 - ANAGRAFICA territori (ascendenza) + viste alberate ===
# Schema a stella: tabella territori_anagrafica + viste province/regioni con i padri.
# Legge il magazzino, NON riscarica. Generalizza ai Comuni (un padre in piu': cod_prov).
from pathlib import Path
import pandas as pd, sqlite3

BASE = Path("ISTAT"); (BASE / "viste").mkdir(exist_ok=True)
con = sqlite3.connect(str(BASE / "istat.db"))
pop = pd.read_sql_query("SELECT * FROM popolazione", con)
terr = pd.read_csv(BASE / "territori_istat.csv", keep_default_na=False, na_values=[])
nome = dict(zip(terr["codice"].astype(str), terr["nome_it"].astype(str)))
parent = dict(zip(terr["codice"].astype(str), terr["parent"].astype(str)))

def catena(code):
    out = []; c = code; n = 0
    while c != "IT" and n < 12:
        c = parent.get(c)
        if c is None or c == "nan": break
        out.append(c); n += 1
    return out
def liv(code):
    if code == "IT": return "Italia"
    return {1:"ripartizione", 2:"regione", 3:"provincia", 4:"comune"}.get(len(catena(code)), "altro")
def riga_ana(c):
    s = {"ripartizione":("",""), "regione":("",""), "provincia":("","")}
    for a in catena(c):
        la = liv(a)
        if la in s: s[la] = (a, nome.get(a, ""))
    l = liv(c)
    if l in s: s[l] = (c, nome.get(c, ""))
    return {"codice":c, "nome":nome.get(c, c), "livello":l,
            "cod_rip":s["ripartizione"][0], "nome_rip":s["ripartizione"][1],
            "cod_reg":s["regione"][0], "nome_reg":s["regione"][1],
            "cod_prov":s["provincia"][0], "nome_prov":s["provincia"][1]}

ana = pd.DataFrame([riga_ana(c) for c in sorted(pop["codice"].astype(str).unique())])
ana.to_sql("territori_anagrafica", con, if_exists="replace", index=False)

SES = ["maschi", "femmine", "totale"]
def vista(liv_sel, idx):
    d = pop[pop.livello == liv_sel].merge(ana, on="codice", suffixes=("", "_a"))
    w = d.pivot_table(index=idx, columns=["anno", "sesso"], values="valore")
    anni = sorted({a for a, s in w.columns})
    return w.reindex(columns=pd.MultiIndex.from_tuples(
        [(a, s) for a in anni for s in SES], names=["anno", "sesso"])).sort_index()

vista("provincia", ["nome_rip", "nome_reg", "codice", "nome"]).to_csv(BASE / "viste" / "vista_province.csv")
vista("regione",   ["nome_rip", "codice", "nome"]).to_csv(BASE / "viste" / "vista_regioni.csv")
print("Anagrafica + viste alberate: fatto.")
`;

const S5_NATI = `
# === SCRIPT 5 - FETCH nati (LBIRTH) tutte le province -> ricevute (mattone laterale) ===
# I nati vivono nei cubi BILANCIO, non negli stock. Due cubi, due ordini di variabili:
#   storico  164_164_DF_DCIS_RICPOPRES2011_2  (2002-2018)  FREQ.REF_AREA.DATA_TYPE.AGE.SEX.CITIZENSHIP
#   moderno  22_315_DF_DCIS_POPORESBIL1_1     (2019-2025)  FREQ.REF_AREA.DATA_TYPE.SEX
# Giuntura 2018|2019: i nati sono un FLUSSO, anni consecutivi, nessuna sovrapposizione.
from pathlib import Path
import sdmx, time
import pandas as pd

istat = sdmx.Client("ISTAT", timeout=120)
RIC = Path("ISTAT") / "ricevute"; RIC.mkdir(parents=True, exist_ok=True)
def salva(df, nome): df.to_csv(RIC / nome, index=False); print("  salvata:", nome, df.shape)

HIST = "164_164_DF_DCIS_RICPOPRES2011_2"           # bilancio storico
for da, a in [(2002, 2009), (2010, 2018)]:
    nome = f"fetch_nati_{da}.csv"
    if (RIC / nome).exists(): print("  gia' in casa:", nome); continue
    try:
        r = istat.data(HIST, key="A..LBIRTH.TOTAL.9.TOTAL", params={"startPeriod": str(da), "endPeriod": str(a)})
        t = sdmx.to_pandas(r).reset_index(); t["TIME_PERIOD"] = t["TIME_PERIOD"].astype(int)
        salva(t[(t["TIME_PERIOD"] >= da) & (t["TIME_PERIOD"] <= a)], nome)
    except Exception as e: print("  FALLITO (rilancia):", type(e).__name__)
    time.sleep(3)

MOD = "22_315_DF_DCIS_POPORESBIL1_1"               # bilancio moderno
if not (RIC / "fetch_nati_2019.csv").exists():
    r = istat.data(MOD, key="A..LBIRTH.9", params={"startPeriod": "2019", "endPeriod": "2025"})
    t = sdmx.to_pandas(r).reset_index(); t["TIME_PERIOD"] = t["TIME_PERIOD"].astype(int)
    salva(t[(t["TIME_PERIOD"] >= 2019) & (t["TIME_PERIOD"] <= 2025)], "fetch_nati_2019.csv")
`;

const S6_INTEGRA = `
# === SCRIPT 6 - INTEGRA: tabella unificata 'fatti' (popolazione + nati) con colonna MISURA ===
# Lo schema lungo passa da 6 a 7 colonne: codice, nome, livello, anno, sesso, MISURA, valore.
# Un solo motore, piu' misure. Legge le ricevute, non riscarica.
from pathlib import Path
import pandas as pd, sqlite3

BASE = Path("ISTAT"); RIC = BASE / "ricevute"
terr = pd.read_csv(BASE / "territori_istat.csv", keep_default_na=False, na_values=[])
nome = dict(zip(terr["codice"].astype(str), terr["nome_it"].astype(str)))
parent = dict(zip(terr["codice"].astype(str), terr["parent"].astype(str)))
def livello(c):
    if c == "IT": return "Italia"
    p, x = 0, c
    while x != "IT" and p < 12:
        x = parent.get(x); p += 1
        if x is None or x == "nan": return "altro"
    return {1: "ripartizione", 2: "regione", 3: "provincia", 4: "comune"}.get(p, "altro")
ez = {1: "maschi", 2: "femmine", 9: "totale"}

def carica(glob, misura):
    files = sorted(RIC.glob(glob))
    if not files: return pd.DataFrame()
    g = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
    g = g.dropna(subset=["value"]).drop_duplicates(subset=["REF_AREA", "SEX", "TIME_PERIOD"])
    cod = g["REF_AREA"].astype(str)
    return pd.DataFrame({"codice": cod, "nome": cod.map(nome), "livello": cod.map(livello),
        "anno": g["TIME_PERIOD"].astype(int), "sesso": g["SEX"].astype(int).map(ez),
        "misura": misura, "valore": g["value"].round().astype(int)})

fatti = pd.concat([carica("fetch_full_*.csv", "popolazione"),
                   carica("fetch_nati_*.csv", "nati")], ignore_index=True)
con = sqlite3.connect(str(BASE / "istat.db"))
fatti.to_sql("fatti", con, if_exists="replace", index=False); con.close()
print("Tabella 'fatti':", fatti.shape[0], "righe, misure", sorted(fatti["misura"].unique()))
`;

const S7_ETA = `
# === SCRIPT 7 - PIRAMIDE: fasce d'eta su misura da anni singoli (cubo POPRES1_2 "By age") ===
# Lezioni incorporate: (a) si scaricano gli ANNI SINGOLI e si sommano nelle fasce volute;
# (b) le fasce-scopo si SOVRAPPONGONO e NON si sommano fra loro; (c) ESCLUDERE il codice
# TOTAL quando si sommano gli anni (altrimenti doppio conteggio); (d) sesso: SEX=9 e SEX=2
# bastano (i maschi sono derivabili). Esempio: Nuoro, anziani in dettaglio + fertili femminili.
import sdmx, re
import pandas as pd

istat = sdmx.Client("ISTAT", timeout=120)
CUBO = "22_289_DF_DCIS_POPRES1_2"
# FREQ.REF_AREA.DATA_TYPE.SEX.AGE.MARITAL_STATUS ; sesso ed eta vuoti, stato civile totale(99)
r = istat.data(CUBO, key="A.ITG26.JAN...99", params={"startPeriod": "2019", "endPeriod": "2026"})
t = sdmx.to_pandas(r).reset_index(); t["TIME_PERIOD"] = t["TIME_PERIOD"].astype(int)
t = t[(t.TIME_PERIOD >= 2019) & (t.TIME_PERIOD <= 2026)]
t["SEX"] = t["SEX"].astype(str); t["AGE"] = t["AGE"].astype(str)
def eta(c):
    m = re.match(r"^Y_?(?:GE)?(\\d+)$", c); return int(m.group(1)) if m else None
t["e"] = t["AGE"].map(eta)                      # None per TOTAL -> escluso dalle somme

def banda(y, sesso, lo, hi):
    s = t[(t.TIME_PERIOD == y) & (t.SEX == sesso) & (t.e >= lo) & (t.e <= hi)]
    return int(s["value"].sum())
def totale(y, sesso):
    return int(t[(t.TIME_PERIOD == y) & (t.SEX == sesso) & (t.AGE == "TOTAL")]["value"].sum())

def quadro(y):
    pop = totale(y, "9"); fem = totale(y, "2")
    return {"popolazione": pop, "over-66": banda(y, "9", 66, 200),
            "over-66 %": round(banda(y, "9", 66, 200) / pop * 100, 1),
            "66-74": banda(y, "9", 66, 74), "75-84": banda(y, "9", 75, 84),
            "85-94": banda(y, "9", 85, 94), "95-99": banda(y, "9", 95, 99),
            "100+": banda(y, "9", 100, 200),
            "fertili F 14-45": banda(y, "2", 14, 45),
            "fertili % su F": round(banda(y, "2", 14, 45) / fem * 100, 1)}

df = pd.DataFrame({"2019": quadro(2019), "2026": quadro(2026)})
df["delta"] = df["2026"] - df["2019"]
print(df.to_string())
`;

const S8_CONV = `
# === SCRIPT 8 - CONVERGENZA: TFR italiane vs straniere (somma ASFR / 1000) ===
# Cubo FECONDITA1_7: tassi specifici per eta (ASFR) x cittadinanza (solo ITL/FRG/TOTAL) x eta madre.
# Il TFR si ricava sommando i tassi per eta e dividendo per mille. Niente per-paese: e' la "fatica".
import sdmx
import pandas as pd

istat = sdmx.Client("ISTAT", timeout=120)
CUBO = "25_326_DF_DCIS_FECONDITA1_7"
# FREQ.REF_AREA.DATA_TYPE.CITIZENSHIP.MOTHER_AGE ; cittadinanza ed eta vuote
r = istat.data(CUBO, key="A.IT.ASFR..", params={"startPeriod": "2002", "endPeriod": "2024"})
t = sdmx.to_pandas(r).reset_index(); t["TIME_PERIOD"] = t["TIME_PERIOD"].astype(int)
t = t[(t.TIME_PERIOD >= 2002) & (t.TIME_PERIOD <= 2024)]
tfr = (t.groupby(["TIME_PERIOD", "CITIZENSHIP"])["value"].sum().div(1000)
         .unstack("CITIZENSHIP")).round(2)
tfr = tfr.rename(columns={"ITL": "italiane", "FRG": "straniere", "TOTAL": "totale"})
tfr["divario"] = (tfr["straniere"] - tfr["italiane"]).round(2)
print(tfr.to_string())
`;

const children = [];

// ---------- PAGINA DI INTESTAZIONE ----------
children.push(new Paragraph({ spacing: { before: 1900, after: 0 }, alignment: AlignmentType.CENTER,
  children: [new TextRun({ text: "Manuale API ISTAT", bold: true, size: 56, font: "Arial", color: "1F3864" })] }));
children.push(new Paragraph({ spacing: { before: 120, after: 0 }, alignment: AlignmentType.CENTER,
  children: [new TextRun({ text: "Popolazione e declino demografico", bold: true, size: 40, font: "Arial", color: "2E5496" })] }));
children.push(new Paragraph({ spacing: { before: 260, after: 0 }, alignment: AlignmentType.CENTER,
  children: [new TextRun({ text: "Interrogazione via SDMX REST \u2014 guida operativa verificata sul campo", italics: true, size: 26, color: "444444" })] }));
children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 420, after: 420 },
  border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: "2E5496", space: 8 } }, children: [new TextRun("")] }));
children.push(new Paragraph({ spacing: { before: 80, after: 0 }, alignment: AlignmentType.CENTER,
  children: [new TextRun({ text: "Documento unico \u00B7 v25 \u00B7 giugno 2026", size: 24, color: "666666" })] }));
children.push(new Paragraph({ spacing: { before: 40, after: 0 }, alignment: AlignmentType.CENTER,
  children: [new TextRun({ text: "Dataflow di riferimento: ", size: 20, color: "888888" }), new TextRun({ text: "IT1,22_289_DF_DCIS_POPRES1_1,1.0", size: 18, font: "Consolas", color: "888888" })] }));

children.push(new Paragraph({ spacing: { before: 700, after: 0 }, children: [new TextRun("")] }));
children.push(info([
  new Paragraph({ spacing: { after: 100 }, children: [B("A chi legge.  "), R("Questo manuale ha due destinatari: chi deve "), I("usare"), R(" l\u2019API ISTAT partendo da zero, e chi lo "), I("conserva e stampa"), R(" come riferimento del Progetto. \u00C8 scritto perch\u00E9, lette queste pagine, il primo sappia comporre una richiesta che funziona davvero, e il secondo ritrovi tutto in ordine.")] }),
  new Paragraph({ spacing: { after: 0 }, children: [B("Criterio guida.  "), R("Ogni cosa qui dentro \u00E8 stata "), B("provata interrogando il server"), R(", non \u00E8 teoria: dove fuori si trova solo confusione, qui ci sono i primi esempi che hanno funzionato.")] }),
]));

// ---------- INDICE ----------
children.push(new Paragraph({ pageBreakBefore: true, heading: HeadingLevel.HEADING_1, children: [new TextRun("Indice")] }));
children.push(SP());
if (fs.existsSync("toc.json")) {
  const entries = JSON.parse(fs.readFileSync("toc.json", "utf-8"));
  for (const e of entries) {
    const l1 = e.level === 1;
    children.push(new Paragraph({
      spacing: { before: l1 ? 90 : 0, after: l1 ? 60 : 30, line: 268 },
      indent: { left: l1 ? 0 : 380 },
      tabStops: [{ type: TabStopType.RIGHT, position: CW, leader: LeaderType.DOT }],
      children: [
        new TextRun({ text: e.title.replace(/\s+/g, " "), bold: l1, size: l1 ? 22 : 21, color: l1 ? "1F3864" : "333333" }),
        new TextRun({ text: "\t" + (e.page == null ? "" : e.page), bold: l1, size: l1 ? 22 : 21, color: l1 ? "1F3864" : "333333" }),
      ],
    }));
  }
} else {
  children.push(new TableOfContents("Sommario", { hyperlink: true, headingStyleRange: "1-3" }));
}

// ---------- 1. A COSA SERVE ----------
children.push(H1("1.  A cosa serve questo manuale"));
children.push(P([
  R("Questo documento raccoglie ci\u00F2 che \u00E8 stato "), B("verificato direttamente"), R(" interrogando il server ISTAT: l\u2019indirizzo a cui chiedere, come si compone una richiesta, quali codici usare per ogni filtro e come leggere la risposta. Ogni informazione \u00E8 stata provata e ha funzionato \u2014 non \u00E8 materiale teorico."),
]));
children.push(P([
  R("Lo scopo del Progetto a cui serve: studiare il "), B("declino demografico dei piccoli comuni"), R(" italiani. L\u2019approccio \u00E8 "), I("territorio-centrico"), R(": la varianza "), I("fra"), R(" i territori "), I("\u00E8"), R(" il fenomeno, e le medie nazionali la nascondono. L\u2019obiettivo pratico immediato: scaricare i dati di popolazione (per territorio, sesso, et\u00E0 e anno) in un formato pulito e tabellare, pronto per Excel e per l\u2019analisi."),
]));
children.push(P([
  R("Lo strumento con cui si eseguono le richieste \u00E8 "), B("Python"), R(" (in pratica, l\u2019app Carnets su iPhone). Il motivo \u00E8 semplice e importante: il browser e altri strumenti non permettono di impostare correttamente l\u2019intestazione che chiede i dati in formato CSV, e finiscono per ricevere risposte illeggibili o per non rispondere affatto. Python invece controlla la richiesta in ogni dettaglio."),
]));

// ---------- 2. ENDPOINT E REGOLE ----------
children.push(H1("2.  L\u2019indirizzo base e le regole da rispettare"));
children.push(P([R("Tutte le richieste partono da questo indirizzo (endpoint):")]));
children.push(codeBox("https://esploradati.istat.it/SDMXWS/rest"));
children.push(P([B("Regole d\u2019oro"), R(", da rispettare sempre:")]));
children.push(BULLET([B("Massimo 5 richieste al minuto."), R("  Superare questo limite comporta il blocco dell\u2019accesso per 1\u20132 giorni. \u00C8 la regola pi\u00F9 importante in assoluto.")]));
children.push(BULLET([R("Nessuna autenticazione: non servono password n\u00E9 chiavi. L\u2019accesso \u00E8 libero.")]));
children.push(BULLET([B("Una richiesta = pochi dati."), R("  Richieste troppo ampie (tutti i territori insieme, molti anni in blocco) rischiano di non ricevere risposta. Meglio molte richieste piccole e mirate.")]));
children.push(BULLET([R("Il formato si chiede con l\u2019intestazione, mai nell\u2019indirizzo. Aggiungere "), M("?format=\u2026"), R(" all\u2019URL non funziona: viene ignorato.")]));

// ---------- 3. ANATOMIA RICHIESTA ----------
children.push(H1("3.  Come \u00E8 fatta una richiesta dati"));
children.push(P([
  B("Due parole, per evitare equivoci.  "), R("SDMX chiama "), B("\u00ABcubo\u00BB"), R(" il contenitore di dati su un argomento (indicato da un identificativo detto "), B("\u00ABdataflow\u00BB"), R("), e "), B("\u00ABvariabili\u00BB"), R(" i suoi assi (ci\u00F2 che SDMX chiama "), I("dimensions"), R("). Attenzione: \u00ABcubo\u00BB \u00E8 una convenzione storica e non implica tre assi \u2014 un dataflow pu\u00F2 avere sei, nove o pi\u00F9 variabili. A rigore sarebbe un "), I("ipercubo"), R(", ma il termine corrente resta \u00ABcubo\u00BB; qui diremo per lo pi\u00F9 "), B("dataflow"), R("."),
]));
children.push(P([R("Una richiesta di dati ha questa forma generale:")]));
children.push(codeBox("{endpoint}/data/{dataflow}/{chiave}?{periodo}"));
children.push(P([R("I tre pezzi che cambiano sono "), M("dataflow"), R(", "), M("chiave"), R(" e "), M("periodo"), R(". Vediamoli.")]));

children.push(info([
  new Paragraph({ spacing: { after: 90 }, children: [B("Un po\u2019 di vocabolario \u2014 stessa cosa, un nome solo.")] }),
  new Paragraph({ spacing: { after: 50 }, children: [B("dataflow"), R("  \u2014  il contenitore di dati su un argomento (informalmente \u00ABcubo\u00BB).")] }),
  new Paragraph({ spacing: { after: 50 }, children: [B("variabili"), R("  \u2014  gli assi del dataflow (le "), I("dimensions"), R(" di SDMX): FREQ, REF_AREA, DATA_TYPE, SEX, AGE\u2026")] }),
  new Paragraph({ spacing: { after: 50 }, children: [B("filtrare / filtro"), R("  \u2014  scegliere i valori su una variabile (l\u2019operazione che restringe).")] }),
  new Paragraph({ spacing: { after: 50 }, children: [B("chiave"), R("  \u2014  la stringa che concatena un valore per ciascuna variabile (la "), I("key"), R(" dell\u2019URL).")] }),
  new Paragraph({ spacing: { after: 0 }, children: [B("codelist"), R("  \u2014  il dizionario dei valori "), I("possibili"), R(" di una variabile; i "), I("valori ammessi"), R(" sono quelli effettivamente presenti.")] }),
]));
children.push(SP());
children.push(H2("3.1  Il dataflow (quale tabella di dati)"));
children.push(P([R("Identifica il \u00ABcubo\u00BB da interrogare. Per la popolazione residente al 1\u00B0 gennaio \u00E8:")]));
children.push(codeBox("IT1,22_289_DF_DCIS_POPRES1_1,1.0"));
children.push(P([R("\u00C8 composto da tre parti separate da virgola:")]));
children.push(table([
  ["Parte", "Valore", "Significato"],
  ["Agency", "IT1", "L\u2019ente che pubblica (ISTAT)"],
  ["ID dataflow", "22_289_DF_DCIS_POPRES1_1", "Il codice della tabella \u00ABpopolazione\u00BB"],
  ["Versione", "1.0", "La versione della struttura dati"],
], [1700, 3670, 3700]));
children.push(SP());
children.push(warn([new Paragraph({ children: [B("\u26A0  Forma completa obbligatoria.  "), R("Vanno usate agency e versione. La forma \u00ABnuda\u00BB (solo "), M("22_289_\u2026"), R(") non riceve risposta dal server.")] })]));

children.push(H2("3.2  La chiave e le sei variabili"));
children.push(P([R("La chiave \u00E8 il cuore della richiesta: seleziona "), I("quali"), R(" dati vuoi. Concatena un valore per ciascuna delle "), B("sei variabili"), R(", separati da un punto, in un ordine "), B("rigoroso e fisso"), R(":")]));
children.push(table([
  ["Pos.", "Variabile", "Cosa filtra"],
  ["1", "FREQ", "Frequenza del dato (annuale)"],
  ["2", "REF_AREA", "Il territorio (Italia, regione, provincia, comune)"],
  ["3", "DATA_TYPE", "Il tipo di indicatore demografico"],
  ["4", "SEX", "Il sesso"],
  ["5", "AGE", "L\u2019et\u00E0"],
  ["6", "MARITAL_STATUS", "Lo stato civile"],
], [900, 2600, 5570]));
children.push(SP());
children.push(P([R("I sei valori si scrivono di fila separati da un punto: servono sempre "), B("cinque punti"), R(" (sei posizioni). Esempio di chiave completa:")]));
children.push(codeBox("A.ITC45.JAN.9.TOTAL.99"));
children.push(P([R("che si legge: annuale \u00B7 provincia di Milano \u00B7 popolazione al 1\u00B0 gennaio \u00B7 sesso totale \u00B7 tutte le et\u00E0 \u00B7 stato civile totale.")]));
children.push(warn([new Paragraph({ children: [B("\u26A0  Il punto va comunque messo.  "), R("Un campo vuoto significa \u00ABtutti i valori\u00BB, ma il punto resta: il server "), B("conta i punti prima di tutto"), R(", e se non sono cinque risponde con un errore ("), M("422 \u2014 expecting 6 got 5"), R(") senza nemmeno guardare i codici.")] })]));

children.push(H2("3.3  Il periodo (quali anni)"));
children.push(P([R("Gli anni si indicano con due parametri in coda all\u2019indirizzo:")]));
children.push(codeBox("?startPeriod=2024&endPeriod=2024"));
children.push(warn([new Paragraph({ children: [B("\u26A0  Bug noto e confermato: un anno in pi\u00F9.  "), R("Il server restituisce sempre "), B("un anno in pi\u00F9"), R(" rispetto a "), M("endPeriod"), R(". Chiedendo "), M("endPeriod=2024"), R(" si ottengono il 2024 "), I("e"), R(" il 2025. Per avere i dati fino all\u2019anno N, impostare "), M("endPeriod = N-1"), R(" (oppure filtrare in pandas).")] })]));

// ---------- 3.4  perche' l'ordine non e' universale ----------
children.push(H2("3.4  Perch\u00E9 l\u2019ordine non \u00E8 universale \u2014 e di chi \u00E8 la colpa"));
children.push(P([R("L\u2019ordine appena visto \u00E8 fisso "), I("dentro questo dataflow"), R(". Ma non \u00E8 lo stesso in tutti: un altro dataflow pu\u00F2 mettere le stesse variabili in un altro ordine, chiamarle con altri nomi, e usare altri codici per il \u00ABtotale\u00BB. Vale la pena capire perch\u00E9 \u2014 \u00E8 ci\u00F2 che pi\u00F9 sorprende (e fa perdere tempo) a chi arriva da fuori.")]));
children.push(P([R("Lo standard SDMX impone che le variabili di una chiave siano "), B("ordinate e posizionali"), R(", e che quell\u2019ordine sia dichiarato dentro ogni dataflow. Questo \u00E8 "), B("obbligatorio"), R(", e ISTAT lo rispetta: per questo la chiave funziona. Ma SDMX lascia a chi pubblica due libert\u00E0 in pi\u00F9 \u2014 dare alle variabili "), I("nomi coerenti"), R(" e un "), I("ordine stabile tra dataflow diversi"), R(" \u2014 e ISTAT le ha sprecate entrambe. Ogni dataflow numera le sue variabili da capo, in silos, come se gli altri non esistessero.")]));
children.push(warn([new Paragraph({ children: [B("\u26A0  Il disordine \u00E8 di ISTAT, non dello standard.  "), R("Sarebbe bastato numerare le variabili una volta sola ("), M("1\u2026N"), R(") e far s\u00EC che ogni dataflow, usandone un sottoinsieme, le disponesse sempre in quell\u2019ordine: "), M("{2, 5, 8}"), R(", mai "), M("{5, 8, 2}"), R(". Le chiavi sarebbero leggibili a colpo d\u2019occhio. SDMX l\u2019avrebbe accettato senza un fiato \u2014 \u00E8 la disciplina che lo standard auspica. ISTAT non l\u2019ha adottata.")] })]));
children.push(P([R("Lo stesso vale per i nomi. La stessa variabile cambia etichetta tra famiglie \u2014 "), M("SEX"), R(" diventa "), M("GENDER"), R(", "), M("DATA_TYPE"), R(" diventa "), M("INDICATOR"), R(", "), M("AGE"), R(" diventa "), M("AGE_NOCLASS"), R(" \u2014 e a volte uno stesso nome copre due concetti diversi ("), M("CITIZENSHIP"), R(" \u00E8 la dicotomia italiano/straniero in un dataflow, l\u2019elenco di centinaia di paesi in un altro). I concetti veri sono una quindicina; i nomi con cui ISTAT li chiama sono molti di pi\u00F9. Manca un\u2019"), B("autorit\u00E0 centrale dei metadati"), R(": ogni indagine ha costruito i suoi dataflow per conto proprio, in epoche diverse.")]));
children.push(P([R("La conseguenza pratica \u00E8 una sola regola di sopravvivenza: di un dataflow nuovo "), B("non dare mai per scontato nulla"), R(" \u2014 n\u00E9 l\u2019ordine, n\u00E9 i nomi, n\u00E9 i codici-totale \u2014 e chiedilo alla struttura (Fase 2, cap. 12). "), B("L\u2019unica cosa che si trasferisce da un dataflow all\u2019altro \u00E8 il procedimento."), R(" Per fortuna, dentro una stessa famiglia molto si trasferisce: \u00E8 il primo dataflow della famiglia a costare, i fratelli scivolano. Conviene perci\u00F2 aprire i dataflow "), I("per famiglia"), R(", non saltando di palo in frasca.")]));

// ---------- 4. CSV ----------
children.push(H1("4.  Chiedere i dati in formato CSV"));
children.push(P([R("Per ricevere i dati come tabella CSV (e non come XML illeggibile), la richiesta deve includere questa "), B("intestazione"), R(" (header HTTP):")]));
children.push(codeBox("Accept: application/vnd.sdmx.data+csv;version=1.0.0"));
children.push(P([R("Senza questa intestazione il server risponde in XML. Con essa, risponde con righe e colonne pulite. "), B("Nota:"), R(" questa intestazione vale per le richieste di "), I("dati"), R(". Le richieste di "), I("struttura"), R(" (gli elenchi di codici) usano un\u2019intestazione diversa, indicata pi\u00F9 avanti.")]));

// ---------- 5. ESEMPIO COMPLETO (ORO) ----------
children.push(H1("5.  Esempio completo, passo per passo"));
children.push(P([
  R("Questo \u00E8 il codice Python minimo che scarica la popolazione totale della provincia di Milano e la stampa. \u00C8 lo schema da cui partire per "), B("qualsiasi"), R(" altra richiesta \u2014 basta cambiare la chiave e il periodo. "), I("\u00C8 il cuore \u00ABsotto il cofano\u00BB: capire questo significa non dipendere da nessuna scorciatoia."),
]));
children.push(codeBox(
`import requests

url = "https://esploradati.istat.it/SDMXWS/rest/data/" \\
      "IT1,22_289_DF_DCIS_POPRES1_1,1.0/A.ITC45.JAN.9.TOTAL.99"

params  = {"startPeriod": "2024", "endPeriod": "2024"}
headers = {"Accept": "application/vnd.sdmx.data+csv;version=1.0.0"}

r = requests.get(url, params=params, headers=headers, timeout=60)
print("Status:", r.status_code)
print(r.text)`));
children.push(P([R("La risposta del server, in CSV, ha questa forma (semplificata alle colonne utili):")]));
children.push(table([
  ["REF_AREA", "DATA_TYPE", "SEX", "AGE", "TIME_PERIOD", "OBS_VALUE"],
  ["ITC45", "JAN", "9", "TOTAL", "2024", "3.245.459"],
  ["ITC45", "JAN", "9", "TOTAL", "2025", "3.246.455"],
], [1640, 1640, 900, 1300, 1990, 1600]));
children.push(SP());
children.push(P([R("La colonna col numero di popolazione \u00E8 "), M("OBS_VALUE"), R("; le altre ripetono i filtri scelti. Si nota subito che i dati arrivano gi\u00E0 pronti per una tabella e che \u2014 come previsto dal bug \u2014 chiedendo solo il 2024 \u00E8 arrivato anche il 2025.")]));

children.push(H2("5.1  Lo stesso esempio, con output gi\u00E0 ripulito"));
children.push(P([R("L\u2019esempio sopra stampa la risposta cos\u00EC com\u2019\u00E8 \u2014 un CSV a 19 colonne, scomodo da leggere. Volendo invece solo l\u2019anno e il numero di residenti, con le migliaia all\u2019italiana, basta far filtrare il CSV a Python:")]));
children.push(codeBox(
`import requests, csv, io

def formato_it(valore):
    """Numero all'italiana: punto migliaia, virgola decimali.
       Gestisce sia interi (conteggi) sia decimali (tassi)."""
    if valore == int(valore):
        intero, decimali = int(valore), ""
    else:
        intero = int(valore)
        decimali = "," + f"{valore:.1f}".split(".")[1]
    s = f"{intero:,}".replace(",", ".")
    return s + decimali

url = "https://esploradati.istat.it/SDMXWS/rest/data/" \\
      "IT1,22_289_DF_DCIS_POPRES1_1,1.0/A.ITC45.JAN.9.TOTAL.99"
params  = {"startPeriod": "2024", "endPeriod": "2024"}
headers = {"Accept": "application/vnd.sdmx.data+csv;version=1.0.0"}

r = requests.get(url, params=params, headers=headers, timeout=60)
righe = list(csv.DictReader(io.StringIO(r.text)))

print(f"{'Anno':<6}{'Residenti al 1 gennaio':>26}")
print("-" * 32)
for x in righe:
    print(f"{x['TIME_PERIOD']:<6}"
          f"{formato_it(float(x['OBS_VALUE'])):>26}")`));
children.push(P([R("Il risultato a schermo, finalmente leggibile:")]));
children.push(table([
  ["Anno", "Residenti al 1\u00B0 gennaio"],
  ["2024", "3.245.459"],
  ["2025", "3.246.455"],
], [2200, 6870]));
children.push(SP());
children.push(info([new Paragraph({ children: [B("Perch\u00E9 cos\u00EC.  "), R("La funzione "), M("formato_it"), R(" fa il lavoro a mano apposta, senza il modulo "), M("locale"), R(" di Python: su iPhone/Carnets quei formati nazionali non sono installati e darebbero errore. Questo approccio invece funziona ovunque.")] })]));

// ---------- 6. sdmx1 ----------
children.push(H1("6.  Un aiuto potente: la libreria sdmx1"));
children.push(P([
  R("Tutto quanto visto finora \u2014 comporre l\u2019indirizzo a mano, contare i punti, chiedere il CSV con l\u2019intestazione giusta, ripulire l\u2019output \u2014 funziona, ed \u00E8 "), B("importante capirlo"), R(" perch\u00E9 mostra cosa succede davvero sotto il cofano. Ma c\u2019\u00E8 uno strumento che fa gran parte di questo lavoro al posto nostro: una libreria Python dedicata a SDMX, lo standard di cui le API ISTAT sono un\u2019implementazione."),
]));
children.push(P([
  R("Quella adottata qui \u00E8 "), B("sdmx1"), R(" (si installa con questo nome, ma una volta installata la si richiama come "), M("sdmx"), R("). \u00C8 la pi\u00F9 completa e mantenuta, conosce ISTAT \u00ABdi fabbrica\u00BB, ed \u00E8 verificata funzionante su Carnets. "), B("Da qui in avanti il manuale la usa"), R(": i capitoli 1\u20135 restano validi per capire i fondamenti e per i casi in cui si voglia il controllo totale.")]));

children.push(H2("6.1  Installazione (una volta sola)"));
children.push(P([R("Da eseguire una volta sola su Carnets. La forzatura serve perch\u00E9 su iPhone la prima installazione a volte resta a met\u00E0 (scrive la cache ma non i file veri):")]));
children.push(codeBox(
`import subprocess, sys
subprocess.run([sys.executable, "-m", "pip", "install",
                "--force-reinstall", "--no-cache-dir",
                "--no-deps", "sdmx1"])`));

children.push(H2("6.2  Scaricare dati: lo stesso esempio di Milano"));
children.push(P([R("L\u2019esempio del capitolo 5 \u2014 la provincia di Milano \u2014 rifatto con la libreria. Stesso risultato, ma senza comporre l\u2019URL n\u00E9 impostare intestazioni:")]));
children.push(codeBox(
`import sdmx

istat = sdmx.Client("ISTAT")

risposta = istat.data(
    "22_289_DF_DCIS_POPRES1_1",
    key="A.ITC45.JAN.9.TOTAL.99",
    params={"startPeriod": "2024", "endPeriod": "2024"})

df = sdmx.to_pandas(risposta)
print(df)`));
children.push(P([R("Si nomina il dataflow, la chiave e il periodo; "), M("to_pandas"), R(" trasforma la risposta in una tabella ordinata, con i sei filtri come colonne e il valore in fondo. Niente parsing, niente pulizia manuale.")]));

children.push(H2("6.3  Leggere i codici: i \u00ABdizionari\u00BB delle variabili"));
children.push(P([R("La libreria scarica anche le "), B("codelist"), R(" (gli elenchi di codici) gi\u00E0 pronte come tabella codice \u2192 descrizione, e con etichette "), B("in italiano"), R(" tramite "), M("locale=\"it\""), R(". Esempio con il sesso:")]));
children.push(codeBox(
`import sdmx
istat = sdmx.Client("ISTAT")

r = istat.codelist("CL_SEXISTAT1")
tabella = sdmx.to_pandas(r, locale="it")["codelist"]["CL_SEXISTAT1"]
print(tabella)`));
children.push(P([R("La struttura: "), M("to_pandas"), R(" restituisce una \u00ABscatola\u00BB da cui si estrae la tabella con "), M("[\"codelist\"][\"NOME_CODELIST\"]"), R(". Lo stesso vale per qualsiasi altra codelist ("), M("CL_TIPO_DATO15"), R(", "), M("CL_STATCIV2"), R(", \u2026).")]));

children.push(H2("6.4  Un regalo in pi\u00F9: la gerarchia dei territori"));
children.push(P([R("Scaricando la codelist dei territori ("), M("CL_ITTER107"), R(") la libreria fornisce, oltre al nome, la colonna "), M("parent"), R(" \u2014 il territorio \u00ABpadre\u00BB nella gerarchia. Questo dato a mano non si otteneva, e risolve il problema degli omonimi (gli \u00ABotto Lecco\u00BB).")]));
children.push(codeBox(
`import sdmx
istat = sdmx.Client("ISTAT")
r = istat.codelist("CL_ITTER107")
terr = sdmx.to_pandas(r, locale="it")["codelist"]["CL_ITTER107"]

print(terr.loc["097042"])   # Lecco comune -> parent ITC43`));
children.push(P([R("Il comune di Lecco ("), M("097042"), R(") ha come padre "), M("ITC43"), R(", la provincia di Lecco. Seguendo la catena dei padri si ricostruisce il livello di ogni territorio (comune \u2192 provincia \u2192 ripartizione \u2192 Italia) e si distinguono i codici omonimi.")]));

children.push(H2("6.5  Certificare un nodo: il principio dei nodi gemelli"));
children.push(P([R("Il progetto gira su più "), B("nodi"), R(" che eseguono lo stesso codice (gli iPhone-fabbrichetta, e domani il PC-fabbrica). Perché «se funziona qui, funziona là» regga, i nodi devono essere "), B("equivalenti"), R(" — ma "), I("funzionalmente"), R(", non identici bit-per-bit. Ciò che può divergere senza danno (l’OS, l’hardware, i pacchetti che non usiamo) lo si lascia divergere; ciò che deve combaciare lo si "), B("verifica"), R(".")]));
children.push(P([R("Procedura di "), B("certificazione"), R(" di un nodo — quattro controlli, in quest’ordine:")]));
children.push(BULLET([B("Python"), R(": "), M("import sys; print(sys.version)"), R(" — stessa "), I("major.minor"), R(" degli altri nodi.")]));
children.push(BULLET([B("Ambiente"), R(": "), M("%pip freeze"), R(" — le librerie-chiave ("), M("sdmx1"), R(", "), M("pandas"), R(", "), M("lxml"), R(", "), M("requests"), R(") alla stessa versione.")]));
children.push(BULLET([B("Libreria-cardine"), R(": "), M("%pip show sdmx1"), R(" + "), M("import sdmx"), R(" — installata "), I("e"), R(" importabile, versione allineata.")]));
children.push(BULLET([B("Catena viva"), R(": una "), B("fetch a risultato noto"), R(" (Esino stock 2023 = "), M("32"), R("). È l’unico test che prova che il nodo "), I("raggiunge davvero ISTAT e legge bene"), R(" — non basta che la libreria si importi. Un nodo è «in produzione» solo dopo questo punto.")]));
children.push(info([new Paragraph({ children: [B("Riscontro reale (2 iPhone, 2 iOS).  "), R("11 Pro Max (iOS 18.3) e 15 Pro Max, stessa Carnets gratuita: "), M("Python 3.13.1"), R(", "), M("sdmx1 2.26.0"), R(", fetch Esino = 32 su entrambi → "), B("gemelli operativi"), R(". Ma i "), M("pip freeze"), R(" "), I("non"), R(" sono identici: il 15 ha in più "), M("istatapi"), R("+"), M("fastcore"), R(" (un esperimento abbandonato, innocui) e "), M("packaging"), R(" più nuovo (26.2 vs 25.0, spostato proprio da quell’installazione). Tutto benigno: 32 su entrambi. "), B("L’ 11 è il nodo di riferimento pulito."), R(" Lezione: «stessa app, stessi giorni» non garantisce identità — basta un’installazione passata a spostare una dipendenza.")] })]));
children.push(P([R("La install vera (6.1) usa "), M("--no-deps"), R(" perché le dipendenze di "), M("sdmx1"), R(" ("), M("lxml, packaging, pandas, platformdirs, python-dateutil, requests"), R(") sono "), B("già dentro Carnets"), R(", precompilate — nel "), M("pip freeze"), R(" appaiono come "), M("nome @ Carnets/…"), R(". Per questo "), M("--no-deps"), R(" non lascia buchi.")]));
children.push(warn([new Paragraph({ children: [B("In vista del PC-fabbrica.  "), R("L’allineamento sarà "), I("meno"), R(" semplice: pip libero, librerie in package diversi, OS tutt’altro. Se due iPhone con la stessa app già divergono così, il PC divergerà di più. Conclusione: "), B("non si insegue l’identità fotografica"), R(" dell’ambiente (impossibile già tra due iPhone) — si certifica l’"), B("equivalenza funzionale"), R(": i 4 controlli + la fetch a 32. La "), I("procedura d’installazione"), R(" cambierà (niente "), M("--no-deps"), R("); la "), I("procedura di certificazione"), R(" resta identica.")] })]));

// ---------- 7. VALORI AMMESSI ----------
children.push(H1("7.  I valori ammessi di ogni variabile"));
children.push(P([R("Domanda naturale: dato un dataflow, come so "), I("quali valori sono davvero ammessi"), R(" in ciascuna variabile, così da non chiedere combinazioni che non esistono? Lo standard SDMX prevede esattamente questo (l\u2019endpoint "), M("availableconstraint"), R("), documentato come suo uso principale.")]));
children.push(warn([new Paragraph({ children: [B("\u26A0  ISTAT non offre questa funzione.  "), R("Verificato per tre vie: "), M("availableconstraint"), R(" va in timeout o \u00E8 dichiarato non supportato; "), M("preview_data"), R(" resta appeso finch\u00E9 il server chiude (oltre 10 minuti). Eurostat e OCSE, invece, le offrono.")] })]));

children.push(H2("7.1  La soluzione: ricostruirli \u00ABa forza bruta\u00BB"));
children.push(P([R("Poich\u00E9 ISTAT non li dichiara, i valori ammessi si scoprono "), B("empiricamente"), R(": si interroga il dataflow lasciando "), I("vuota"), R(" la variabile che interessa, e il server risponde con tutti e soli i valori per cui esistono dati. \u00C8 la tecnica documentata anche da Eurostat per \u00ABscoprire i confini\u00BB di un dataset.")]));
children.push(codeBox(`import sdmx
istat = sdmx.Client("ISTAT")

# DATA_TYPE lasciato vuoto: i due punti di fila '..' fra REF_AREA e SEX
risposta = istat.data("22_289_DF_DCIS_POPRES1_1",
                      key="A.IT..9.TOTAL.99",
                      params={"startPeriod": "2024", "endPeriod": "2024"})
df = sdmx.to_pandas(risposta).reset_index()
print(df["DATA_TYPE"].unique())   # -> ['JAN']  (questo dataflow ne popola uno solo)`));
children.push(P([R("Pur avendo la codelist 471 tipi di dato possibili, questo dataflow ne popola "), B("uno solo"), R(": "), M("JAN"), R(". \u00C8 la differenza cruciale fra il "), B("men\u00F9"), R(" (la codelist, cap. 8) e ci\u00F2 che c\u2019\u00E8 davvero "), B("in cucina"), R(". Ripetuto su ogni variabile, il metodo ricostruisce i vincoli che ISTAT non fornisce.")]));

children.push(H2("7.2  La controprova: altrove gli elenchi ci sono"));
children.push(P([R("Per essere certi che il problema sia di ISTAT e non del metodo: interrogato l\u2019"), B("OCSE"), R(" sullo stesso endpoint, la risposta arriva in meno di un secondo, con per ogni variabile l\u2019elenco dei valori disponibili. La differenza:")]));
children.push(table([
  ["", "OCSE (e simili)", "ISTAT"],
  ["availableconstraint", "risponde (\u22481 s)", "timeout o 404, mai"],
  ["valori ammessi", "una query, lista pronta", "forza bruta, variabile per variabile"],
  ["tempo necessario", "immediato", "molte query, col vincolo dei 5/minuto"],
], [2600, 3235, 3235]));
children.push(SP());
children.push(P([R("Nota strategica: per analisi comparate fra Paesi, l\u2019OCSE pubblica molti dati (Italia inclusa) ed \u00E8 spesso pi\u00F9 comodo di ISTAT proprio per questo.")]));

children.push(H2("7.3  ISTAT in dettaglio: due endpoint, ciascuno mutilato"));
children.push(P([R("La verit\u00E0, verificata sul campo, \u00E8 pi\u00F9 sottile di \u00ABnon offre gli elenchi\u00BB. ISTAT ha "), B("due"), R(" web service, ciascuno incompleto a modo suo:")]));
children.push(table([
  ["", "nuovo (esploradati)", "vecchio (sdmx.istat.it)"],
  ["availableconstraint", "non risponde (timeout)", "funziona, ma\u2026"],
  ["dati popolazione", "freschi, completi", "VUOTO (svuotato)"],
  ["altri domini", "presenti", "alcuni vivi e aggiornati"],
], [2470, 3300, 3300]));
children.push(SP());
children.push(P([R("Il vecchio risponde a "), M("availableconstraint"), R(" (forma corta dell\u2019id e "), M("?references=all&detail=full"), R(") ma "), B("solo per i dataflow che vi conservano ancora dati"), R(": la popolazione \u00E8 stata svuotata e migrata, e l\u00EC risponde \u00ABNo available data\u00BB. "), B("Conclusione per la popolazione:"), R(" i valori ammessi non sono ottenibili su nessun endpoint; resta la forza bruta sul nuovo (7.1).")]));
children.push(info([new Paragraph({ children: [B("Dettaglio tecnico.  "), R("Il vecchio server usa un handshake SSL datato: contesto SSL \u00ABlegacy\u00BB ("), M("ssl.OP_LEGACY_SERVER_CONNECT"), R(", "), M("check_hostname=False"), R(", verifica certificato off, User-Agent da browser).")] })]));

// ---------- 8. I CODICI ----------
children.push(H1("8.  I codici di ogni variabile"));
children.push(P([R("Per ciascuna variabile, i codici utili. Il modo pi\u00F9 comodo \u00E8 la libreria (cap. 6.3), che li d\u00E0 gi\u00E0 come tabella in italiano. Senza libreria, si interroga l\u2019endpoint di struttura ("), M("/codelist/IT1/<NOME>"), R(") con questa intestazione:")]));
children.push(codeBox("Accept: application/vnd.sdmx.structure+json;version=2.0.0"));
children.push(info([new Paragraph({ children: [B("Doppia codifica.  "), R("Molte variabili hanno due sistemi equivalenti, uno numerico storico e uno alfabetico. Il sesso accetta sia "), M("9"), R(" sia "), M("T"), R(" per \u00ABtotale\u00BB. Qui si usa il numerico, gi\u00E0 collaudato.")] })]));

children.push(H2("8.1  FREQ \u2014 frequenza  \u00B7  CL_FREQ"));
children.push(table([["Codice", "Significato"], ["A", "Annuale \u2014 \u00E8 l\u2019unico che serve"]], [2200, 6870]));
children.push(H2("8.2  DATA_TYPE \u2014 tipo di dato  \u00B7  CL_TIPO_DATO15"));
children.push(P([R("Oltre 400 indicatori. Per la popolazione al 1\u00B0 gennaio il codice \u00E8 uno solo:")]));
children.push(table([["Codice", "Significato"], ["JAN", "Popolazione al 1\u00B0 gennaio"]], [2200, 6870]));
children.push(P([R("Altri codici dello stesso dominio, utili pi\u00F9 avanti: "), M("DEC"), R(" (31 dic), "), M("LBIRTH"), R(" (nati vivi), "), M("DEATH"), R(" (morti), "), M("FJAN"), R(" (stranieri al 1\u00B0 gen), "), M("MEANAGEP"), R(" (et\u00E0 media), "), M("AGEINDEX"), R(" (indice di vecchiaia).")]));
children.push(H2("8.3  SEX \u2014 sesso  \u00B7  CL_SEXISTAT1"));
children.push(table([["Numerico", "Alfabetico", "Significato"], ["1", "M", "Maschi"], ["2", "F", "Femmine"], ["9", "T", "Totale"]], [2400, 2400, 4270]));
children.push(H2("8.4  AGE \u2014 et\u00E0  \u00B7  CL_ETA1"));
children.push(P([R("343 codici (anni singoli, classi, fasce). I pi\u00F9 utili:")]));
children.push(table([["Codice", "Significato"], ["TOTAL", "Tutte le et\u00E0 (totale)"], ["Y0, Y1, \u2026 Y99", "Singolo anno di et\u00E0"], ["Y_GE100", "100 anni e pi\u00F9"]], [2700, 6370]));
children.push(H2("8.5  MARITAL_STATUS \u2014 stato civile  \u00B7  CL_STATCIV2"));
children.push(table([["Numerico", "Alfab.", "Significato"], ["99", "ALL", "Totale (tutti gli stati civili)"], ["1", "SIN", "Celibe / nubile"], ["2", "MAR", "Coniugato/a"], ["3", "DIV", "Divorziato/a"], ["4", "WID", "Vedovo/a"]], [2000, 2000, 5070]));
children.push(H2("8.6  REF_AREA \u2014 il territorio  \u00B7  CL_ITTER107"));
children.push(P([R("La variabile pi\u00F9 ricca: 12.471 territori, dall\u2019Italia al singolo comune (elenco completo in "), M("territori_istat.csv"), R("). I codici seguono due sistemi:")]));
children.push(table([
  ["Livello", "Tipo di codice", "Esempi"],
  ["Italia, ripartizioni, regioni, province", "Alfabetico (NUTS)", "IT, ITC, ITC4, ITC45"],
  ["Comuni", "Numerico a 6 cifre", "015146 (Milano)"],
], [3500, 2600, 2970]));
children.push(SP());
children.push(warn([new Paragraph({ children: [B("\u26A0  Falsi codici.  "), R("I numeri d\u2019ordine dei PDF del portale (es. \u00AB2338\u00BB accanto a Milano) "), B("non"), R(" sono REF_AREA validi ("), M("NoRecordsFound"), R("). I codici veri sono solo quelli di "), M("territori_istat.csv"), R(".")] })]));
children.push(warn([new Paragraph({ children: [B("\u26A0  Codici affidabili, nomi no.  "), R("\u00ABSud Sardegna\u00BB ("), M("IT111"), R(") \u00E8 il fossile di una provincia abolita; la Valle d\u2019Aosta porta nomi su tre livelli. Fidati dei codici, mai delle etichette.")] })]));

// ---------- 9. RICETTARIO ----------
children.push(H1("9.  Ricettario di chiavi pronte"));
children.push(P([R("Chiavi gi\u00E0 pronte per il dataflow base: si sostituiscono nello schema del cap. 5 o 6. Ricorda il "), M("+1"), R(" di "), M("endPeriod"), R(".")]));
children.push(table([
  ["Cosa si ottiene", "Chiave"],
  ["Italia, popolazione totale", [M("A.IT.JAN.9.TOTAL.99")]],
  ["Italia, soli maschi", [M("A.IT.JAN.1.TOTAL.99")]],
  ["Italia, sole femmine", [M("A.IT.JAN.2.TOTAL.99")]],
  ["Lombardia (regione), totale", [M("A.ITC4.JAN.9.TOTAL.99")]],
  ["Milano (provincia), totale", [M("A.ITC45.JAN.9.TOTAL.99")]],
  ["Milano (comune), totale", [M("A.015146.JAN.9.TOTAL.99")]],
  ["Italia, maschi di 65 anni", [M("A.IT.JAN.1.Y65.99")]],
], [4600, 4470]));

// ---------- 10. COMUNI ----------
children.push(H1("10.  Scendere ai comuni"));
children.push(P([R("Il dataflow base ("), M("22_289_DF_DCIS_POPRES1_1"), R(") si ferma alla "), B("provincia"), R(": i codici dei comuni, pur presenti nella codelist, non restituiscono dati. Per il livello comunale servono altri dataflow.")]));
children.push(P([B("La serie annuale comunale"), R(" sta in "), M("22_289_DF_DCIS_POPRES1_24"), R(" (\u00ABAll municipalities by age\u00BB), stessa famiglia del base: la popolazione del comune anno per anno.")]));
children.push(P([R("Per l\u2019incrocio ricco \u2014 popolazione per "), B("singolo anno \u00D7 sesso \u00D7 cittadinanza"), R(" fino al comune \u2014 c\u2019\u00E8 invece la famiglia censuaria DCSS ("), M("DF_DCSS_POP_DEMCITMIG_SETA_1"), R(", nove variabili, fra cui "), M("CITIZENSHIP"), R("). Ma \u00E8 una "), B("fotografia censuaria"), R(" (2021), non una serie: fotografa la struttura, non conta anno per anno.")]));
children.push(info([new Paragraph({ children: [B("Il principio generale.  "), R("ISTAT non ha un dataflow che incrocia tutto: ne ha "), B("molti"), R(", ciascuno una \u00ABvista\u00BB pre-incrociata di variabili diverse. Per trovare quello giusto si segue il metodo del capitolo 12.")] })]));

// ---------- 11. LE CATENE ----------
children.push(H1("11.  Le catene: come \u00E8 organizzato il magazzino ISTAT"));
children.push(P([R("Due \u00ABcatene\u00BB reggono l\u2019organizzazione dei dati. Capirle distingue chi "), I("sa cosa cercare"), R(" da chi va a tentoni. Entrambe sono ricostruibili dai file di consultazione, senza interrogare ISTAT.")]));
children.push(H2("11.1  La catena territoriale: la piramide dei luoghi"));
children.push(P([R("Ogni territorio \u00ABsa\u00BB qual \u00E8 il suo padre: la colonna "), M("parent"), R(" di "), M("CL_ITTER107"), R(". Risalendo i padri si va dal comune fino all\u2019Italia. Esempio, Pasturo (Valsassina):")]));
children.push(codeBox(`Italia [IT]
   Nord-ovest [ITC]
      Lombardia [ITC4]
         Lecco [ITC43]
            Pasturo [097065]`));
children.push(P([R("La "), B("forma del codice"), R(" rivela il livello: "), M("IT"), R(" \u00E8 l\u2019Italia; "), M("IT"), R("+lettere una ripartizione; +lettera e cifra una regione; +due una provincia; un codice "), B("numerico a 6 cifre"), R(" un comune. \u00C8 anche la base della classificazione della Fase 4.")]));
children.push(H2("11.2  La stessa catena, in orizzontale"));
children.push(P([R("Girando la prospettiva, tutti i comuni con lo stesso padre stanno sotto la stessa provincia. Filtrando "), M("CL_ITTER107"), R(" per "), M("parent = ITC43"), R(" si ottengono i 93 comuni della provincia di Lecco \u2014 inclusi i micro-comuni della Valsassina (Pasturo, Premana, Introbio\u2026) e Morterone, fra i pi\u00F9 piccoli d\u2019Italia. \u00C8 cos\u00EC che si verifica se un livello \u00E8 coperto "), I("per intero"), R(".")]));
children.push(H2("11.3  La catena interna al dataflow: variabile \u2192 codelist \u2192 valori"));
children.push(P([R("Ogni variabile \u00E8 una \u00ABfessura\u00BB che accetta solo i codici di una specifica codelist. Per il dataflow base:")]));
children.push(table([
  ["Variabile", "Codelist", "N. valori", "Esempi"],
  ["FREQ", "CL_FREQ", "\u2014", "A"],
  ["REF_AREA", "CL_ITTER107", "12.471", "IT, ITC4, 097035"],
  ["DATA_TYPE", "CL_TIPO_DATO15", "471", "JAN, LBIRTH, FJAN"],
  ["SEX", "CL_SEXISTAT1", "8", "1, 2, 9"],
  ["AGE", "CL_ETA1", "343", "TOTAL, Y0, Y_GE100"],
  ["MARITAL_STATUS", "CL_STATCIV2", "50", "99, 1, 2, 4"],
], [2900, 2470, 1300, 2400]));
children.push(SP());
children.push(P([R("Una "), B("chiave"), R(" si costruisce prendendo un valore da ciascuna fessura, nell\u2019ordine: "), M("A.097035.JAN.9.TOTAL.99"), R(" \u00E8 \u00ABEsino Lario, popolazione al 1\u00B0 gennaio, totale, tutte le et\u00E0, tutti gli stati civili\u00BB. La codelist elenca il "), I("possibile"), R("; una query reale ne usa pochissimi.")]));

// ---------- 12. LE 4 FASI ----------
children.push(H1("12.  Trovare e validare un dataflow: le 4 fasi"));
children.push(P([R("Trovare il dataflow giusto \u2014 e accertarsi che copra il livello che serve \u2014 \u00E8 un percorso in "), B("quattro fasi"), R(": strumenti a s\u00E9, da usare in sequenza ma "), B("non concatenati"), R(". L\u2019intelligenza sta nello sguardo umano fra una fase e l\u2019altra, e l\u2019attesa fa da freno ai 5/minuto. Solo la Fase 1 \u00E8 locale.")]));
children.push(info([new Paragraph({ children: [B("Gli script non vanno ricopiati da qui.  "), R("I frammenti di questo capitolo mostrano la "), B("logica"), R(" di ogni fase, non sono da grabbare dal testo. I quattro script "), B("pronti"), R(" \u2014 autoportanti, con la sezione "), M("CAMBIA QUI"), R(" in testa e i commenti su cosa guardare \u2014 vivono come file "), M(".py"), R(" nel pacchetto "), M("4_fasi_CSD"), R(", custodito (al minimo) nel "), B("Salva Maglio"), R(". Si aprono in Carnets e si lanciano uno alla volta, cambiando id e codici nella sezione apposita.")] })]));
children.push(warn([new Paragraph({ children: [B("\u26A0  Dove girano le fasi.  "), R("Solo la "), B("Fase 1"), R(" \u00E8 locale (catalogo). Le Fasi "), B("2, 3 e 4 interrogano "), M("esploradati.istat.it"), R(": richiedono una macchina con "), B("rete aperta verso ISTAT"), R(" \u2014 la "), B("Fabbrichetta"), R(" (iPhone + Carnets + SIM) o il "), B("PC-Fabbrica"), R(". "), B("Non"), R(" girano in ambienti a rete ristretta (es. la sandbox dell\u2019officina, che risponde "), M("403 host_not_allowed"), R(" su ISTAT). L\u00EC un "), M("403"), R(" su "), I("qualsiasi"), R(" dataflow \u2014 anche "), M("POPRES1"), R(" che \u00E8 notoriamente funzionante \u2014 non \u00E8 un problema di SSL, di agency o di codice: \u00E8 la firma dell\u2019ambiente sbagliato. Riconoscerlo subito evita di debuggare codice gi\u00E0 corretto.")] })]));
children.push(warn([new Paragraph({ children: [B("\u26A0  Carnets e gli input.  "), R("Carnets non digerisce l\u2019underscore dentro un "), M("input()"), R(": il kernel si blocca. E gli id ISTAT ne sono pieni. Perci\u00F2 id e codici si scrivono "), B("dentro il codice"), R(", mai chiesti via "), M("input()"), R(".")] })]));

children.push(H2("12.1  Fase 1 \u2014 cercare i dataflow candidati"));
children.push(P([R("Lavora sul catalogo locale ("), M("catalogo_dataflow.csv"), R("), quindi "), B("non interroga ISTAT"), R(". Frammenti corti in OR pescano rumore: meglio parole lunghe in AND. Gli "), I("id"), R(" hanno frammenti stabili ("), M("POP"), R(", "), M("DCIS"), R(", "), M("DCSS"), R(", "), M("_COM"), R(").")]));
children.push(codeBox(`import csv, os
CAT = os.path.expanduser("~/Documents/ISTAT/catalogo_dataflow.csv")

def cerca_dataflow(parole, modo="and"):
    parole = [p.lower() for p in parole]; out = []
    with open(CAT, encoding="utf-8") as f:
        for r in csv.DictReader(f):
            testo = (r["id"] + " " + r["nome_it"]).lower()
            hit = [p in testo for p in parole]
            if (modo=="and" and all(hit)) or (modo=="or" and any(hit)): out.append(r)
    return out

for r in cerca_dataflow(["pop", "com"], modo="and"):
    print(r["id"], "->", r["nome_it"])`));

children.push(H2("12.2  Fase 2 \u2014 leggere le variabili di un dataflow"));
children.push(P([R("Dato un id, ne elenca le variabili "), I("in ordine"), R(", con la codelist di ciascuna. Una sola richiesta. "), B("Da fare sempre prima di costruire una chiave"), R(", perch\u00E9 l\u2019ordine cambia da una famiglia all\u2019altra.")]));
children.push(warn([new Paragraph({ children: [B("\u26A0  L\u2019autenticazione SSL.  "), R("I frammenti da qui in poi mostrano la "), B("logica"), R(", non l\u2019impalcatura: presuppongono che il client sappia gi\u00E0 dialogare in HTTPS con ISTAT. Il server ISTAT richiede il "), B("trucco SSL"), R(" ("), M("OP_LEGACY_SERVER_CONNECT"), R(", "), M("check_hostname=False"), R(", User-Agent da browser \u2014 cap. 5). Sulla Fabbrichetta l\u2019ambiente lo fornisce gi\u00E0; altrove va montato a mano, o "), M("sdmx.Client(\"ISTAT\")"), R(" fallisce con "), M("CERTIFICATE_VERIFY_FAILED"), R(".")] })]));
children.push(codeBox(`import sdmx

def trova_variabili(flow_id):                 # le variabili = le "dimensions" SDMX
    istat = sdmx.Client("ISTAT", timeout=300)
    msg = istat.dataflow(flow_id, params={"references": "datastructure"})
    out = []
    for _, dsd in msg.structure.items():
        for dim in dsd.dimensions.components:
            cl = dim.local_representation.enumerated.id \\
                 if (dim.local_representation and dim.local_representation.enumerated) else ""
            out.append((dim.id, cl))
    return out                                # [(variabile, codelist), ...] in ordine

for i, (nome, cl) in enumerate(trova_variabili("22_289_DF_DCIS_POPRES1_1"), 1):
    print(i, nome, "->", cl)`));

children.push(H2("12.3  Fase 3 \u2014 provare un territorio reale"));
children.push(P([R("Verifica se un dataflow contiene "), B("dati veri"), R(" per un territorio. Chiave \u00Aba dizionario\u00BB: si fissa solo "), M("REF_AREA"), R(", la libreria riempie il resto \u2014 cos\u00EC funziona senza conoscere in anticipo la struttura.")]));
children.push(codeBox(`import sdmx
istat = sdmx.Client("ISTAT", timeout=300)
risposta = istat.data("22_289_DF_DCIS_POPRES1_1",
                      key={"REF_AREA": "097065"},      # Pasturo
                      params={"startPeriod": "2023", "endPeriod": "2023"})
df = sdmx.to_pandas(risposta).reset_index()
print(len(df), "righe")     # 0 = territorio assente nel dataflow`));

children.push(H2("12.4  Fase 4 \u2014 misurare la copertura territoriale"));
children.push(P([R("La fase decisiva per l\u2019analisi comunale: dice "), B("quali livelli"), R(" il dataflow copre, e "), B("con quanti comuni"), R(". Interroga lasciando vuoto solo "), M("REF_AREA"), R(" e classifica i territori dalla forma del codice.")]));
children.push(warn([new Paragraph({ children: [B("\u26A0  Query leggera, obbligatoria.  "), R("Vuotando "), I("tutte"), R(" le variabili, il dataflow restituisce la combinatoria completa: centinaia di migliaia di righe, e il server chiude. Fissare gli altri filtri al totale ("), M("SEX=9, AGE=TOTAL, MARITAL_STATUS=99"), R(") e variare solo il territorio.")] })]));
children.push(codeBox(`import sdmx, re
def classifica(c):
    if c == "IT": return "Italia"
    if re.fullmatch(r"\\d{6}", c): return "comune"
    if re.fullmatch(r"IT\\d{3}", c): return "provincia"
    if c.startswith("IT"):
        resto = c[2:]
        if re.fullmatch(r"[A-Z]{1,2}", resto): return "ripartizione"
        if re.fullmatch(r"[A-Z][A-Z0-9]", resto): return "regione"
        if re.fullmatch(r"[A-Z][A-Z0-9]{2}", resto): return "provincia"
    return "altro"

istat = sdmx.Client("ISTAT", timeout=300)
risposta = istat.data("22_289_DF_DCIS_POPRES1_1",
                      key={"SEX": "9", "AGE": "TOTAL", "MARITAL_STATUS": "99"},
                      params={"startPeriod": "2023", "endPeriod": "2023"})
codici = set(sdmx.to_pandas(risposta).reset_index()["REF_AREA"])
conteggio = {}
for c in codici: conteggio[classifica(c)] = conteggio.get(classifica(c), 0) + 1
print(conteggio)   # base: {Italia:1, ripartizione:8, regione:21, provincia:107, comune:0}`));
children.push(P([R("Lo zero sui comuni conferma che il dataflow base si ferma alla provincia. Su un dataflow DCSS comunale si vedrebbero migliaia di comuni.")]));
children.push(warn([new Paragraph({ children: [B("\u26A0  Server lunatico \u2014 riprovare prima di correggere.  "), R("La stessa query pu\u00F2 fallire (\u00ABConnection reset\u00BB) e, rilanciata subito, riuscire. Davanti a un errore di rete, "), B("ripeti lo script"), R(", non debuggare codice che funzionava. I tempi vanno da 30\u2033 a oltre 25 minuti.")] })]));
children.push(H2("12.5  Il tubo Fase2\u2192Fase4: la chiave posizionale senza disallineamenti"));
children.push(P([R("La Fase 4 originale aveva la chiave costruita a mano con i nomi e il numero di variabili di POPRES1. Su un dataflow di famiglia diversa \u2014 con pi\u00F9 o meno dimensioni, in ordine diverso \u2014 la chiave slitta di posizione e il server risponde "), M("404"), R(". Non \u00E8 un errore di codice: \u00E8 un disallineamento strutturale tra la chiave scritta a mano e la firma reale del cubo.")]));
children.push(P([R("La soluzione non \u00E8 un avvertimento (che si legge e si dimentica) ma un "), B("tubo"), R(": la Fase 2 posa il foglietto, la Fase 4 lo legge e costruisce la chiave nell\u2019ordine giusto. \u00C8 semi-automazione dell\u2019idraulica, non del giudizio: l\u2019umano decide ancora i codici-totale, ma le posizioni non possono pi\u00F9 sbagliare.")]));
children.push(table([
  ["Fase", "Cosa fa il tubo", "Dove"],
  ["Fase 2", "Posa il foglietto: una riga per dimensione, nell\u2019ordine esatto del cubo. Crea ~/Documents/ISTAT/4fasi/ se non esiste. Riscrive il file se esiste (l\u2019ultimo passaggio vince). Non cancella mai la cartella: accumula la storia di tutti i dataflow sondati.", "~/Documents/ISTAT/4fasi/<FLOW_ID>"],
  ["Fase 4", "Legge il foglietto, costruisce la chiave posizionale nell\u2019ordine del foglietto, lancia la query. Se il foglietto non c\u2019\u00E8: si ferma e stampa \u00ABFare passare Fase 2\u00BB.", "stessa cartella"],
], [1500, 5000, 2570]));
children.push(SP());
children.push(info([new Paragraph({ children: [B("Perch\u00E9 la Fase 4 non gira senza le precedenti.  "), R("La Fase 4 da sola non ha senso: per costruire la chiave le serve la struttura del cubo (Fase 2), per sapere quali codici-totale usare le serve l\u2019output della Fase 3. Lanciare la Fase 4 senza le fasi precedenti significa lanciarla senza sapere n\u00E9 "), I("cosa"), R(" si misuri n\u00E9 "), I("com\u2019\u00E8 fatto"), R(". Il tubo materializza questa dipendenza su disco: se il foglietto manca, la Fase 4 si rifiuta di partire."), ] })]));
children.push(warn([new Paragraph({ children: [B("\u26A0  GENDER=T nei cubi DCSS.  "), R("Nei cubi della famiglia DCSS (Censimento permanente) il codice totale del sesso \u00E8 "), M("T"), R(", non "), M("9"), R(" come in POPRES1 n\u00E9 "), M("TOTAL"), R(" come in altri cubi. Fonte: collaudato sul campo su "), M("DF_DCSS_POP_DEMCITMIG_SETA_1"), R(". Ogni famiglia ha i suoi codici: leggere sempre la Fase 3 prima di compilare la chiave della Fase 4."), ] })]));

// ---------- 13. ATLANTE ----------
children.push(H1("13.  Strumenti pronti: un atlante critico"));
children.push(P([R("Oltre a lavorare \u00ABa cofano aperto\u00BB, esistono strumenti che impacchettano il dialogo con ISTAT. Conviene conoscerli \u2014 e sapere "), B("dove smettono di funzionare"), R(". La lezione: danno per scontato che ISTAT rispetti lo standard SDMX, e si rompono proprio dove ISTAT lo viola. La pipeline artigianale, che aggira le idiosincrasie, \u00E8 pi\u00F9 robusta.")]));
children.push(BULLET([B("Librerie generaliste:  "), M("sdmx1"), R(" (quella usata qui) e la sorella "), M("pandaSDMX"), R(". Robuste, mantenute, multi-provider; il ragionamento \u2014 quale dataflow, quali variabili \u2014 resta all\u2019utente.")]));
children.push(BULLET([B("Libreria specifica per ISTAT:  "), M("istatapi"), R(". Su iPhone si installa solo con "), M("--no-deps"), R(" (altrimenti tira "), M("cryptography"), R(", che vuole il compilatore Rust, assente su iOS). Soprattutto: punta al "), B("vecchio"), R(" endpoint e per costruire un dataset chiede i valori via "), M("availableconstraint"), R("; sui cubi svuotati l\u00EC (popolazione!) fallisce. "), B("Per l\u2019analisi demografica comunale \u00E8 inservibile"), R("; vede inoltre ~500 dataflow contro i ~4.800 reali.")]));
children.push(BULLET([B("Server MCP per ISTAT:  "), R("i pi\u00F9 citati sono costruiti "), I("sopra"), R(" "), M("istatapi"), R(", quindi ne ereditano i limiti; e presuppongono un client desktop, non Carnets.")]));
children.push(BULLET([B("Servizi \u00Aba richiesta\u00BB:  "), R("il Contact Centre ISTAT (anche microdati ed elaborazioni su misura) o intermediari accademici (UniData / Bicocca). Vie legittime, ma incompatibili con un lavoro guidato dalla curiosit\u00E0, dove serve prendere qualunque dato subito. Per quel profilo, l\u2019autonomia a cofano aperto \u00E8 l\u2019unica strada.")]));

// ---------- 14. RISPOSTE DEL SERVER ----------
children.push(H1("14.  Capire le risposte del server"));
children.push(table([
  ["Risposta", "Significato", "Cosa fare"],
  ["200 + righe CSV", "successo", "leggere OBS_VALUE / la colonna value"],
  ["422 expecting 6 got 5", "punti mancanti nella chiave", "aggiungere i punti"],
  ["422 Unable to generate SQL", "un codice della chiave non \u00E8 valido", "verificare i codici (cap. 8)"],
  ["404 NoRecordsFound", "chiave valida, nessun dato", "controllare il codice territorio"],
  ["406 + lista formati", "header Accept sbagliato", "header giusto (dati vs struttura)"],
  ["nessuna risposta (timeout)", "richiesta troppo pesante o dataflow nudo", "ridurre l\u2019ampiezza; forma completa"],
], [2600, 3470, 3000]));

// ---------- 15. PROMEMORIA ----------
children.push(H1("15.  Promemoria del metodo"));
children.push(BULLET([B("Mai pi\u00F9 di 5 richieste al minuto.")]));
children.push(BULLET([R("Dataflow sempre in forma completa: "), M("IT1,22_289_DF_DCIS_POPRES1_1,1.0"), R(".")]));
children.push(BULLET([R("Chiave: un valore per variabile, nell\u2019ordine del dataflow; campo vuoto = punto comunque.")]));
children.push(BULLET([R("CSV: header "), M("Accept: application/vnd.sdmx.data+csv;version=1.0.0"), R(".")]));
children.push(BULLET([R("Ricorda il "), M("+1"), R(" di "), M("endPeriod"), R(".")]));
children.push(BULLET([R("Codici territorio veri in "), M("territori_istat.csv"), R(", non i numeri d\u2019ordine dei PDF.")]));
children.push(BULLET([R("Il dataflow base si ferma alla provincia; per i comuni "), M("POPRES1_24"), R(" (serie) o DCSS (censimento).")]));
children.push(BULLET([R("Gli elenchi di valori ammessi non esistono su ISTAT: forza bruta (cap. 7). OCSE le offre pronte.")]));
children.push(BULLET([R("Per trovare un dataflow: le 4 fasi (cap. 12) \u2014 cerca, variabili, prova territorio, copertura.")]));
children.push(BULLET([R("Carnets non digerisce l\u2019underscore negli "), M("input()"), R(": codici nel codice.")]));
children.push(BULLET([R("Esplorazione: fissa le variabili al totale, varia solo ci\u00F2 che indaghi.")]));
children.push(BULLET([R("Errore di rete? Riprova lo stesso script: il server \u00E8 lunatico.")]));

// ---------- 16. ARCHITETTURA ----------
children.push(H1("16.  L\u2019architettura del magazzino"));
children.push(P([R("I capitoli precedenti dicono come "), I("chiedere"), R(" i dati. Da qui in poi: come "), I("conservarli e usarli"), R(" senza rifare ogni volta lo stesso lavoro. L\u2019impianto regge su tre strati \u2014 ricevute, fatti, viste \u2014 e su un principio: "), B("una sola fetch, due rese"), R(" — prima gli strumenti (§16.1) e il principio (§16.2), poi i tre strati, e infine il giro operativo \u2014 le due copie, la sandbox, la continuit\u00E0 tra thread (§16.7).")]));
children.push(H2("16.1  Perché Carnets, pandas e SQLite"));
children.push(P([R("Tre strumenti, una ragione ciascuno. Insieme: "), B("sdmx1 pesca, pandas plasma, SQLite conserva e interroga, Excel sfoglia"), R(" — e tutto gira identico su iPhone e PC.")]));
children.push(P([B("Carnets non è «l’interprete»: è un Jupyter completo. "), R("L’interprete è CPython, il motore; Carnets è l’officina che lo contiene, col sistema notebook. Ciò che conta è il "), B("kernel con memoria persistente"), R(": una cella scarica il dato in una variabile, e quella variabile "), I("resta viva"), R(" tra una cella e l’altra — la si interroga quante volte si vuole senza ritoccare ISTAT. Conseguenza diretta: il limite di 5 richieste/minuto e il server lunatico mordono "), B("solo"), R(" al momento della fetch; appena il dato è in memoria è una banca dati viva in RAM, e l’esplorazione è gratis e immediata. (Per anni Carnets è stato usato come «interprete one-shot» — scrivo, lancio, copio — cioè a un decimo di quel che è.)")]));
children.push(P([B("pandas è il banco di lavoro. "), R("Il dato, appena sceso da sdmx1, è prima di tutto un "), B("DataFrame"), R(": una tabella che vive in memoria e si rimodella con poche righe (filtra, aggrega, pivota). È lo stesso «tabella» degli export web, ma programmabile. Per chi ragiona in SQL: un DataFrame è una tabella SQL in RAM — "), M(".query()"), R(" è il WHERE, "), M(".groupby()"), R(" il GROUP BY, "), M(".pivot_table()"), R(" la rotazione.")]));
children.push(P([B("SQLite è il magazzino interrogabile. "), R("Tre ragioni, "), I("specie sul telefono"), R(": (1) è nella "), B("libreria standard"), R(" di Python — c’è sempre, zero installazioni, e un aggiornamento dell’app non può portarlo via (non compare nemmeno in "), M("pip list"), R("); (2) è un "), B("file"), R(" ("), M("istat.db"), R(") — quindi è il mattone durevole e sincronizzabile, identico su iPhone e PC; (3) parla "), B("SQL"), R(", la lingua dei "), I("join"), R(" su cui poggia l’estensibilità del magazzino (la colonna "), M("misura"), R(", §16.4). Il pivot non lo fa lui (niente operatore "), M("PIVOT"), R("): quello lo fanno pandas o Excel. SQLite "), B("interroga"), R(", pandas ed Excel "), B("ruotano"), R(".")]));
children.push(P([R("Nota di confine: "), M("DuckDB"), R(" sarebbe il lusso dell’analista, ma non è puro Python → su iOS non si installa. Resta un eventuale upgrade «più avanti, sul PC», senza toccare i dati nel file.")]));

children.push(H2("16.2  Una sola fetch, due rese — la chiave"));
children.push(P([R("È il principio che tiene insieme il capitolo, e da cui discende tutto il resto dell’impianto. Il bisogno di partenza era un conflitto "), I("apparente"), R(": serve una "), B("vista larga"), R(" da guardare a occhio (una riga per territorio, gli anni × sesso come colonne) "), I("e"), R(" una forma "), B("pratica per analizzare"), R(". Sembravano due archivi paralleli — due cose da mantenere, che col tempo divergono.")]));
children.push(P([R("La soluzione è "), B("non averne due"), R(". Il dato vero è "), B("uno solo"), R(": quello che si pesca da ISTAT. Da lì lo stesso codice produce "), B("entrambe"), R(" le rese — la tabella larga per gli occhi (le viste, §16.5) e la forma lunga per lavorarci (i fatti, §16.4). Nessun doppio libro mastro, nessuna deriva: se cambia un numero cambia in tutt’e due, perché vengono dalla stessa fetch. La vista non si mantiene: si "), B("genera"), R(".")]));
children.push(P([R("Conseguenza pratica: la vista larga — il formato non-negoziabile per l’occhio umano — non è un peso da aggiornare a mano, è una "), I("fotografia"), R(" ricalcolata dal magazzino ogni volta. Da qui la regola dei tre strati (§16.3–16.5): "), B("ricevute immutabili in ingresso; magazzino e vista unici, rigenerati"), R(". Le ricevute sono la verità; "), M("istat.db"), R(" e le viste sono sue fotografie, sempre ricostruibili e mai in conflitto.")]));
children.push(P([R("È la chiave che ha aperto tutte le porte di questo impianto: senza, ogni nuova esigenza (un’altra misura, un altro livello territoriale) imporrebbe di rifare il lavoro; con essa, basta "), I("una fetch in più"), R(" — e le due rese si aggiornano da sole.")]));

children.push(H2("16.3  Le ricevute: ci\u00F2 che arriva, intatto"));
children.push(P([R("Ogni scarico riuscito si salva subito su disco in "), M("ISTAT/ricevute/"), R(", prima di qualsiasi elaborazione: \u00E8 la difesa contro i crash del kernel di Carnets. I nomi distinguono la misura: "), M("fetch_full_<anno>.csv"), R(" (popolazione), "), M("fetch_nati_<anno>.csv"), R(" (nati). Rilanciare uno script salta ci\u00F2 che \u00E8 gi\u00E0 in casa.")]));
children.push(H2("16.4  I fatti: una tabella lunga, un motore solo"));
children.push(P([R("Tutte le ricevute confluiscono in un\u2019unica tabella \u00ABlunga\u00BB (tidy), "), M("fatti"), R(", comoda per pandas. Una riga per ogni combinazione territorio \u00D7 anno \u00D7 sesso \u00D7 misura:")]));
children.push(table([
  ["Colonna", "Contenuto"],
  ["codice / nome / livello", "il territorio e il suo rango (Italia\u2026comune)"],
  ["anno", "l\u2019anno del dato"],
  ["sesso", "maschi / femmine / totale"],
  ["misura", "popolazione  oppure  nati"],
  ["valore", "il numero"],
], [3100, 5970]));
children.push(SP());
children.push(P([R("La colonna "), M("misura"), R(" \u00E8 la chiave dell\u2019estensibilit\u00E0: aggiungere i morti, gli stranieri, i matrimoni significa aggiungere "), I("righe"), R(", non rifare l\u2019impianto.")]));
children.push(H2("16.5  Le viste: la faccia leggibile, per Excel"));
children.push(P([R("Dalla tabella lunga si "), I("rendono"), R(" le viste \u00ABlarghe\u00BB ("), M("vista_province.csv"), R(", "), M("vista_regioni.csv"), R("): righe = territori coi loro padri (ripartizione, regione), colonne = anni \u00D7 sesso. \u00C8 il formato da sfogliare a occhio in Excel. La tabella lunga \u00E8 il "), B("motore"), R("; le viste e i grafici sono la "), B("faccia"), R(". Nessuna doppia manutenzione: nascono dalla stessa fetch.")]));
children.push(H2("16.6  Dove vive tutto"));
children.push(codeBox(`~/Documents/ISTAT/
   catalogo_dataflow.csv      # i ~4.800 dataflow (Fase 1)
   territori_istat.csv        # i 12.471 territori con 'parent'
   ricevute/                  # gli scarichi grezzi, intatti
   viste/                     # vista_province.csv, vista_regioni.csv
   istat.db                   # SQLite: tabelle 'popolazione', 'territori_anagrafica'`));

children.push(H2("16.7  Le due copie, la sandbox, la continuit\u00E0 tra thread"));
children.push(P([R("Il magazzino esiste in "), B("due copie"), R(", e tenerle distinte evita confusione. La "), B("copia sovrana"), R(" vive in Carnets sull\u2019iPhone (in "), M("~/Documents/ISTAT/istat.db"), R("): \u00E8 il dato di propriet\u00E0, stabile, custodito dall\u2019autore. La "), B("copia di lavoro"), R(" vive nella sandbox di Claude \u2014 la macchina temporanea dove si fa l\u2019elaborazione pesante: fondere le ricevute, interrogare in SQL, pivotare in pandas, generare le viste Excel e i grafici. Le due "), B("non sono sincronizzate"), R(": nessun filo le collega, il ponte \u00E8 lo scambio di file a mano (l\u2019autore carica, Claude consegna). Restano allineate per una garanzia esplicita \u2014 la copia in Carnets \u00E8 sempre e solo l\u2019ultima inviata da Claude, mai modificata a mano \u2014 e divergono nell\u2019istante in cui una delle due cambia da sola.")]));
children.push(P([R("Da qui il confine pi\u00F9 utile da ricordare: la sandbox "), B("non raggiunge ISTAT"), R(". La porta sul server non c\u2019\u00E8. L\u2019unico anello che richiede Carnets \u00E8 quindi la "), B("fetch"), R(" \u2014 scaricare dati nuovi. Tutto il resto \u2014 analisi, pivot, grafici, viste, documenti \u2014 Claude lo fa "), I("in casa"), R(", e non serve che l\u2019autore sia su un dispositivo con Carnets: basta la conversazione. Il giorno in cui le fetch le facesse Claude Code sul PC \u2014 che la rete ce l\u2019ha \u2014 Carnets non servirebbe pi\u00F9 nemmeno per quelle.")]));
children.push(P([R("La sandbox per\u00F2 \u00E8 "), B("effimera"), R(": a fine sessione viene smontata, e nel thread successivo la copia di lavoro non c\u2019\u00E8 pi\u00F9. Per ripartire col magazzino in mano, il dato deve "), I("rientrare"), R(" da qualche parte \u2014 e qui un vincolo concreto, "), B("verificato"), R(": i \u00ABfiles\u00BB del Progetto accettano "), B("testo"), R(" (CSV, documenti) ma "), B("non file binari"), R(". Il "), M("istat.db"), R(" \u00E8 stato rifiutato. Il magazzino, dunque, non viaggia come tale.")]));
children.push(P([R("La via "), B("canonica"), R(" sfrutta il principio dei tre strati (\u00A716.2): le "), B("ricevute sono la verit\u00E0"), R(", il "), M(".db"), R(" \u00E8 una loro fotografia ricostruibile. A inizio thread l\u2019autore ri-fornisce le ricevute (i CSV, che passano sempre) e Claude "), B("ricostruisce"), R(" il magazzino \u2014 fondendole, ritagliando la provenienza, riclassificando i livelli, riattaccando i nomi, e verificando l\u2019integrit\u00E0 (maschi + femmine = totale; una firma nota). Per la ricostruzione serve anche l\u2019anagrafica dei territori come CSV nei \u00ABfiles\u00BB (oggi vive solo dentro il "), M(".db"), R("). Con ricevute, anagrafica e questa ricetta, il magazzino si rigenera identico in qualunque thread. In alternativa, da verificare, l\u2019autore pu\u00F2 ricaricare il "), M(".db"), R(" stesso in chat (un file solo), se l\u2019upload regge la dimensione.")]));
children.push(P([R("Stato attuale del magazzino: la tabella si chiama "), M("popolazione"), R(" ("), M("codice \u00B7 nome \u00B7 livello \u00B7 anno \u00B7 sesso \u00B7 valore \u00B7 fonte"), R("), copre l\u2019"), B("arco intero 2001-2026"), R(" \u2014 comuni, province e aggregati \u2014 e la colonna "), M("fonte"), R(" distingue le due serie saldate al confine 2018|2019 (ricostruita fino al 2018, anagrafica dal 2019). Il disegno generalizzato "), M("fatti"), R(" / "), M("misura"), R(" (\u00A716.4) resta la rotta per quando affiancheremo altre misure, come i nati.")]));
children.push(SP());

// ---------- 17. DATAFLOW VERIFICATI ----------
children.push(H1("17.  I dataflow verificati"));
children.push(P([R("I \u00ABgioielli\u00BB: i dataflow provati sul campo, con il loro ordine di variabili e una chiave pronta. Sostituiscono mesi di tentativi.")]));
children.push(warn([new Paragraph({ children: [B("\u26A0  L\u2019ordine delle variabili cambia da famiglia a famiglia.  "), R("La famiglia storica mette "), M("AGE"), R(" prima di "), M("SEX"), R(" e aggiunge "), M("CITIZENSHIP"), R(". Leggere SEMPRE la struttura (Fase 2) prima di costruire una chiave.")] })]));
children.push(H2("17.1  Popolazione (stock) \u2014 famiglia POPRES1"));
children.push(P([R("Variabili, in ordine: "), M("FREQ \u00B7 REF_AREA \u00B7 DATA_TYPE \u00B7 SEX \u00B7 AGE \u00B7 MARITAL_STATUS"), R(". Anni 2019\u2192oggi.")]));
children.push(table([
  ["Dataflow", "Cosa contiene", "Chiave esempio"],
  ["\u2026POPRES1_1", "Italia / regioni / province", [M("A.IT.JAN.9.TOTAL.99")]],
  ["\u2026POPRES1_2", "Province per anno singolo (piramide)", [M("A.ITG26.JAN...99")]],
  ["\u2026POPRES1_24", "Tutti i comuni (serie annuale)", [M("A.097035.JAN.9.TOTAL.99")]],
], [2500, 3770, 2800]));
children.push(SP());
children.push(H2("17.2  Flussi e ricostruzione storica \u2014 bilanci"));
children.push(P([R("I "), B("flussi"), R(" (nati, morti) stanno nei bilanci, non negli stock. Due famiglie, due ordini:")]));
children.push(table([
  ["Dataflow", "Variabili (in ordine)", "Anni / nota"],
  ["22_315_\u2026POPORESBIL1_1", "FREQ\u00B7REF_AREA\u00B7DATA_TYPE\u00B7SEX", "2019\u20132025 (moderno)"],
  ["164_164_\u2026RICPOPRES2011_1", "FREQ\u00B7REF_AREA\u00B7DATA_TYPE\u00B7AGE\u00B7SEX\u00B7CITIZENSHIP", "stock storico (solo JAN)"],
  ["164_164_\u2026RICPOPRES2011_2", "idem (bilancio)", "nati 2002\u20132018"],
  ["164_164_\u2026RICPOPRES2011_24", "idem", "comuni \u00Abai confini di oggi\u00BB"],
], [2950, 3920, 2200]));
children.push(SP());
children.push(P([R("Chiave nati moderna "), M("A.<prov>.LBIRTH.9"), R("; storica "), M("A.<prov>.LBIRTH.TOTAL.9.TOTAL"), R(" (ordine diverso!).")]));
children.push(H2("17.3  Stranieri \u2014 famiglia POPSTR"));
children.push(table([
  ["Dataflow", "Cosa contiene", "Misura / nota"],
  ["29_7_\u2026POPSTRRES1", "stranieri per et\u00E0 (no cittadinanza)", "JAN"],
  ["29_317_\u2026POPSTRCIT1", "stranieri per cittadinanza", "FJAN; totale = WORLD"],
  ["29_316_\u2026POPSTRBIL1", "bilancio stranieri", "misure col prefisso F"],
], [2700, 3670, 2700]));
children.push(SP());
children.push(H2("17.4  I \u00ABconigli bianchi\u00BB"));
children.push(P([R("Dataflow speciali, utili o ingannevoli: "), M("25_326_\u2026FECONDITA1_7"), R(" (tassi ASFR per cittadinanza [solo ITL/FRG/TOTAL] \u00D7 et\u00E0 madre; "), B("TFR = somma ASFR / 1000"), R("); "), M("\u2026DCSS\u2026SETA"), R(" (censimento, anni singoli \u00D7 sesso \u00D7 cittadinanza, fino al comune); "), M("25_74_\u2026NATI2"), R(" (dettaglio fecondit\u00E0, "), B("nomi di variabili NON standard"), R(": "), M("RESIDENCE_TERR"), R(", "), M("MOTHER_AGE"), R("); "), M("29_956_\u2026CV_STRA_1"), R(" (\u00E8 un\u2019"), I("indagine"), R(" a 14 variabili \u2014 una trappola, non un conteggio).")]));

children.push(H2("17.5  Stranieri × et\u00E0 × cittadinanza × comune \u2014 famiglia DCSS (Censimento permanente)"));
children.push(P([R("Cubo certificato con le 4 fasi il 23 giugno 2026. \u00C8 il dato che il Magazzino non aveva: et\u00E0 singola, sesso, cittadinanza e comune nella stessa tabella. "), B("Copertura piena"), R(": 7.906 comuni, 103 province, 21 regioni, 6 ripartizioni, Italia.")]));
children.push(warn([new Paragraph({ children: [B("\u26A0  Attenzione al tipo di misura.  "), R("Questo cubo \u00E8 Censimento permanente, non anagrafe. Il valore dell\u2019indicatore "), M("RESPOP_AV"), R(" \u00E8 la "), B("popolazione media del periodo"), R(", non lo stock al 1\u00B0 gennaio come in POPRES1. Non si somma e non si confronta direttamente con le tabelle anagrafiche: sono due binari paralleli. Per le analisi interne al cubo (struttura per et\u00E0, cittadinanza, mobilit\u00E0) \u00E8 ricchissimo; per i confronti col Magazzino anagrafico va dichiarato come dato distinto."), ] })]));
children.push(P([B("Variabili (in ordine, dalla Fase 2):  "), M("FREQ \u00B7 REF_AREA \u00B7 INDICATOR \u00B7 GENDER \u00B7 AGE_NOCLASS \u00B7 MARITAL_STATUS \u00B7 CITIZENSHIP \u00B7 AREA_CONTRY_CITIZEN \u00B7 USUAL_RESID_1Y \u00B7 TIME_PERIOD"), R(". Totale: 10 dimensioni (TIME_PERIOD va in startPeriod/endPeriod, non nella chiave).")]));
children.push(table([
  ["Variabile", "Codice totale", "Note"],
  ["FREQ", "(vuota)", "lasciare libera"],
  ["REF_AREA", "(vuota)", "territorio \u2014 lasciare libero per coprire tutto"],
  ["INDICATOR", "RESPOP_AV", "popolazione media del periodo \u2014 l\u2019unico indicatore disponibile"],
  ["GENDER", "T", "attenzione: \u00ABT\u00BB non \u00ABTOTAL\u00BB (diverso dalla famiglia POPRES1)"],
  ["AGE_NOCLASS", "TOTAL", "et\u00E0 singola 0\u2013100+; TOTAL = somma di tutte le et\u00E0"],
  ["MARITAL_STATUS", "ALL", ""],
  ["CITIZENSHIP", "TOTAL", "singoli paesi + raggruppamenti; TOTAL = tutte le cittadinanze"],
  ["AREA_CONTRY_CITIZEN", "ALL", "macro-area geografica della cittadinanza"],
  ["USUAL_RESID_1Y", "ALL", "bonus: residenza un anno prima \u2014 misura la mobilit\u00E0"],
  ["TIME_PERIOD", "\u2014", "va in startPeriod/endPeriod (2022, 2023)"],
], [2700, 1800, 4570]));
children.push(SP());
children.push(P([B("Chiave posizionale per la copertura territoriale (Fase 4):  "), M("..RESPOP_AV.T.TOTAL.ALL.TOTAL.ALL.ALL"), R("  (9 posizioni; FREQ e REF_AREA vuote = tutti i territori).")]));
children.push(P([B("Anni disponibili:  "), R("2022 e 2023 (Censimento permanente \u2014 cadenza diversa dall\u2019anagrafe annuale). Se un anno non risponde, provare l\u2019altro.")]));
children.push(P([B("Dataflow completo:  "), M("DF_DCSS_POP_DEMCITMIG_SETA_1"), R(". Il foglietto delle 10 dimensioni \u00E8 in "), M("~/Documents/ISTAT/4fasi/DF_DCSS_POP_DEMCITMIG_SETA_1"), R(" (posato dalla Fase 2).")]));
children.push(info([new Paragraph({ children: [B("Il bonus USUAL_RESID_1Y.  "), R("La dimensione \u00ABresidenza abituale un anno prima\u00BB \u00E8 una finestra sulla "), B("mobilit\u00E0"), R(": dice se la persona, un anno fa, stava nello stesso comune o altrove. Con questa dimensione libera si pu\u00F2 misurare non solo lo "), I("stock"), R(" di stranieri per et\u00E0 e cittadinanza, ma anche i "), I("flussi"), R(" \u2014 chi \u00E8 arrivato nell\u2019ultimo anno e da dove. \u00C8 il dato che trasforma il cubo da fotografia a dinamica di coorte. Da esplorare nella prossima apertura.")] })]));

children.push(H2("17.6  Fecondit\u00E0 per et\u00E0 della madre \u00D7 cittadinanza \u2014 famiglia DCIS"));
children.push(P([R("Cubo certificato con le 4 fasi il 23 giugno 2026. Contiene il tasso di fecondit\u00E0 per et\u00E0 singola della madre (ASFR) distinto per cittadinanza italiana vs straniera. \u00C8 il mattone demografico che manca alla tabella \u00ABfecondita\u00BB del Magazzino, che ha solo il TFR aggregato.")]));
children.push(warn([new Paragraph({ children: [B("\u26A0  Questo cubo non arriva al comune.  "), R("Esino (097035) risponde 404; il cubo si ferma alla "), B("provincia"), R(". Per dati di fecondit\u00E0 a livello comunale i numeri sono troppo piccoli (pochi nati per et\u00E0 per nazionalit\u00E0 per anno). Copertura: 103 province + 4 province_nuova, 21 regioni, Italia."), ] })]));

children.push(P([B("Variabili (in ordine, dalla Fase 2):  "), M("FREQ \u00B7 REF_AREA \u00B7 DATA_TYPE \u00B7 CITIZENSHIP \u00B7 MOTHER_AGE \u00B7 TIME_PERIOD"), R(". Totale: 6 dimensioni.")]));
children.push(table([
  ["Variabile", "Codice totale / note"],
  ["INDICATOR", "ASFR (Age-Specific Fertility Rate \u2014 tasso per 1.000 donne di quell\u2019et\u00E0)"],
  ["CITIZENSHIP", "TOTAL (tutte le madri); ITL = italiane; FRG = straniere"],
  ["MOTHER_AGE", "Non ha un codice-totale: usare un\u2019et\u00E0 specifica (es. Y25) per la Fase 4. Il TFR = \u03A3 ASFR / 1.000"],
  ["TIME_PERIOD", "2023-2024 (almeno); va in startPeriod/endPeriod"],
], [2500, 7070]));
children.push(SP());
children.push(P([B("Chiave Fase 4 (copertura territoriale):  "), M("..ASFR.TOTAL.Y25"), R("  (5 posizioni; MOTHER_AGE fissata su Y25 perch\u00E9 TOTAL non esiste).")]));
children.push(P([B("Dataflow:  "), M("25_326_DF_DCIS_FECONDITA1_7"), R(". Complementare a "), M("fecondita"), R(" (TFR storico 1999\u20132025): questo aggiunge la struttura per et\u00E0 della fecondit\u00E0 negli anni recenti. "), B("Non entra nello Schedario stranieri \u00D7 comuni"), R(" (no livello comunale), ma \u00E8 candidato al Magazzino come tabella separata.")]));

children.push(H2("17.7  Stranieri nati in Italia (seconde generazioni) \u2014 famiglia DCSS"));
children.push(P([R("Cubo certificato con le 4 fasi il 23 giugno 2026. Contiene la popolazione straniera "), B("nata in Italia"), R(" per cittadinanza, luogo di nascita dei genitori, et\u00E0 e istruzione. \u00C8 il cubo delle seconde generazioni: chi \u00E8 figlio di immigrati ma nato in Italia. Copertura comunale: "), B("7.190 comuni"), R(" (i 716 mancanti rispetto al cubo 17.5 sono quelli senza bambini stranieri nati in Italia \u2014 assenza reale, non buco di copertura).")]));
children.push(warn([new Paragraph({ children: [B("\u26A0  INDICATOR = FOR_B_IT, non RESPOP_AV.  "), R("Questo cubo usa l\u2019indicatore "), M("FOR_B_IT"), R(" (Foreign Born in Italy), diverso da "), M("RESPOP_AV"), R(" del cubo 17.5. Non sono confrontabili: uno conta chi \u00E8 nato in Italia, l\u2019altro la popolazione residente media. Tenerli su binari separati."), ] })]));

children.push(P([B("Variabili (in ordine, dalla Fase 2):  "), M("FREQ \u00B7 REF_AREA \u00B7 INDICATOR \u00B7 GENDER \u00B7 AGE_CLASS \u00B7 CITIZENSHIP \u00B7 PREVOUS_CITIZEN \u00B7 PLACE_BIRTH_PAR \u00B7 EDU_ATTAIN \u00B7 TIME_PERIOD"), R(". Totale: 10 dimensioni.")]));
children.push(table([
  ["Variabile", "Codice totale", "Note"],
  ["INDICATOR", "FOR_B_IT", "Foreign Born in Italy \u2014 l\u2019unico indicatore del cubo"],
  ["GENDER", "T", "DCSS: T non 9 (come cubo 17.5)"],
  ["AGE_CLASS", "TOTAL", "classi d\u2019et\u00E0, non anni singoli: TOTAL, Y10-19, Y_UN17"],
  ["CITIZENSHIP", "FRGAPO", "tutti gli stranieri + apolidi; EU27 = solo cittadini UE. No singoli paesi."],
  ["PREVOUS_CITIZEN", "TOTAL", "cittadinanza precedente (naturalizzazioni)"],
  ["PLACE_BIRTH_PAR", "ALL", "BPBAB = entrambi i genitori nati all\u2019estero \u2014 la dimensione delle seconde generazioni vere"],
  ["EDU_ATTAIN", "ALL", "titolo di studio"],
], [2500, 1800, 5270]));
children.push(SP());
children.push(P([B("Chiave Fase 4:  "), M("..FOR_B_IT.T.TOTAL.FRGAPO.TOTAL.ALL.ALL"), R("  (9 posizioni).")]));
children.push(info([new Paragraph({ children: [B("La dimensione chiave: PLACE_BIRTH_PAR = BPBAB.  "), R("Filtrando "), M("PLACE_BIRTH_PAR=BPBAB"), R(" (Both Parents Born ABroad) si isolano le "), B("seconde generazioni vere"), R(": nate in Italia da entrambi i genitori immigrati. \u00C8 il dato che permette di misurare l\u2019integrazione demografica \u2014 non solo quanti stranieri ci sono, ma quanti sono gi\u00E0 italiani di fatto anche se non ancora di diritto. Nessun\u2019altra tabella del Magazzino lo cattura."), ] })]));
children.push(P([B("Dataflow:  "), M("DF_DCSS_MIGR_BACKG_PAR_TV_6_COM"), R(". Foglietto: "), M("~/Documents/ISTAT/4fasi/DF_DCSS_MIGR_BACKG_PAR_TV_6_COM"), R(". "), B("Entra nello Schedario stranieri \u00D7 comuni"), R(" (7.190 comuni), con nota: cittadinanza solo a livello di macro-gruppo (EU27/FRGAPO), non singolo paese.")]));

children.push(H2("17.8  Nota sullo Schedario come strumento di prima sgrossatura"));
children.push(P([R("Lo Schedario \u00E8 stato costruito come test pre-Maglio: 41 cubi selezionati dal catalogo per il tema stranieri \u00D7 comuni, ciascuno sondato con Esino e Lipari. Il criterio di qualificazione era: "), I("\u00ABEsino risponde?\u00BB"), R(". \u00C8 una condizione necessaria ma non sufficiente.")]));
children.push(P([R("L\u2019apertura con le 4 fasi ha mostrato che lo Schedario sa "), B("che"), R(" i cubi esistono e "), B("che"), R(" il comune risponde. Non sa: quante dimensioni ha davvero il cubo, qual \u00E8 il codice-totale di ogni dimensione, se la cittadinanza \u00E8 a singolo paese o solo a macro-gruppo, se la misura \u00E8 stock o media o tasso, quali dimensioni bonus sono presenti ("), M("USUAL_RESID_1Y"), R(", "), M("PLACE_BIRTH_PAR"), R(", "), M("EDU_ATTAIN"), R("). Per il cubo DCSS SETA_1 lo Schedario contava 9 dimensioni: sono 10. Per il cubo MIGR_BACKG lo Schedario marcava OK senza notare che la cittadinanza \u00E8 solo EU27/FRGAPO e che "), M("PLACE_BIRTH_PAR=BPBAB"), R(" \u00E8 la porta sulle seconde generazioni.")]));
children.push(BULLET([B("Lo Schedario serve come: "), R("\u00ABprima sgrossatura\u00BB \u2014 meglio di niente, utile per selezionare i candidati da aprire con le 4 fasi. Non \u00E8 utile per nessuna catalogazione seria.")]));
children.push(BULLET([B("Il criterio corretto di qualificazione"), R(" \u00E8 in tre domande (cap. 12): (1) comuni ci sono? (2) la cittadinanza \u00E8 disaggregata per singolo paese al livello comunale? (3) \u00E8 una misura diretta o un proxy? Solo le 4 fasi rispondono a tutte e tre.")]));

children.push(H2("17.9  Stranieri per PAESE \u00D7 et\u00E0 \u00D7 comune \u2014 famiglia DCSS (il cubo regina TV_3)"));
children.push(P([R("Cubo certificato con le 4 fasi il 24 giugno 2026 e scaricato massivamente dalla Fabbrichetta. \u00C8 il cubo pi\u00F9 ricco per il tracking degli stranieri: d\u00E0 la cittadinanza per singolo paese fino al comune."), B("  Attenzione alla dimensione insolita: "), R("i paesi non stanno in "), M("CITIZENSHIP"), R(" (che \u00E8 sempre "), M("FRGAPO"), R(" = tutti gli stranieri) ma in "), B("AREA_CONTRY_CITIZEN"), R(", che in questo cubo \u00E8 popolata con 215 valori (paesi singoli + aggregati continentali).")]));
children.push(warn([new Paragraph({ children: [B("\u26A0  INDICATOR = RESFORPOP_AV, non RESPOP_AV.  "), R("L\u2019indicatore \u00E8 "), M("RESFORPOP_AV"), R(" ("), I("RES\u0268dent FORe\u0268gn POPulation Average"), R(") \u2014 non il generico "), M("RESPOP_AV"), R(" del cubo 17.5. Ogni famiglia DCSS ha il suo codice: non si trasferisce mai senza verificare con la sonda dimensioni."), ] })]));
children.push(warn([new Paragraph({ children: [B("\u26A0  AGE_CLASS = solo TOTAL al comune.  "), R("A livello provinciale il cubo espone classi d\u2019et\u00E0 multiple; scendendo al comune resta solo "), M("TOTAL"), R(". Il dettaglio per et\u00E0 degli stranieri al comune non \u00E8 disponibile in TV_3. Per l\u2019et\u00E0 fine al comune serve il cubo 17.5 (SETA_1), che per\u00F2 non ha i singoli paesi: i due cubi sono complementari senza sovrapposizione."), ] })]));
children.push(P([B("Variabili (in ordine, dalla Fase 2):  "), M("FREQ \u00B7 REF_AREA \u00B7 INDICATOR \u00B7 GENDER \u00B7 AGE_CLASS \u00B7 MARITAL_STATUS \u00B7 CITIZENSHIP \u00B7 AREA_CONTRY_CITIZEN \u00B7 USUAL_RESID_1Y \u00B7 TIME_PERIOD"), R(". Totale: 10 dimensioni.")]));
children.push(table([
  ["Variabile", "Codice totale", "Note"],
  ["INDICATOR", "RESFORPOP_AV", "popolazione straniera media del periodo — distinto da RESPOP_AV del cubo 17.5"],
  ["GENDER", "T", "DCSS: T non 9"],
  ["AGE_CLASS", "TOTAL", "solo TOTAL al comune; classi disponibili solo a livello provinciale"],
  ["MARITAL_STATUS", "ALL", ""],
  ["CITIZENSHIP", "FRGAPO", "sempre FRGAPO = tutti gli stranieri+apolidi"],
  ["AREA_CONTRY_CITIZEN", "ALL", "QUI stanno i 215 paesi — non in CITIZENSHIP. ALL = tutti i paesi insieme"],
  ["USUAL_RESID_1Y", "ALL", ""],
], [2800, 1800, 5370]));
children.push(SP());
children.push(P([B("Chiave Fase 4 (copertura territoriale):  "), M("..RESFORPOP_AV.T.TOTAL.ALL.FRGAPO.ALL.ALL"), R("  (9 posizioni).")]));
children.push(P([B("Anni disponibili:  "), R("2018\u20132024 (7 fotografie). La Fase 3 mostra i dati per 2 anni in una sola query: il cubo copre tutto l\u2019arco senza interruzioni.")]));
children.push(P([B("Copertura:  "), R("7.882 comuni, 103 province, 21 regioni, 6 ripartizioni, Italia. I 24 comuni mancanti rispetto a SETA_1 sono quelli senza nemmeno uno straniero.")]));
children.push(info([new Paragraph({ children: [B("Sonda dimensioni: uno step in pi\u00F9 prima della Fase 4.  "), R("Quando una Fase 3 rivela valori inaspettati (come "), M("AREA_CONTRY_CITIZEN"), R(" con 167 valori invece dei soliti 3), prima di costruire la chiave della Fase 4 conviene lanciare una "), B("sonda dimensioni"), R(" mirata: una singola query su "), M("REF_AREA"), R(" noto che risponde (es. la provincia di Lecco ITC43) con tutti gli altri filtri liberi. La sonda stampa, per ogni colonna, tutti i valori distinti e il candidato-totale. Cos\u00EC si leggono i codici esatti \u2014 senza indovinare \u2014 prima di costruire la chiave della Fase 4. \u00C8 una query in pi\u00F9, ma evita 404 da codice sbagliato."), ] })]));
children.push(P([B("Dataflow:  "), M("DF_DCSS_POP_DEMCITMIG_TV_3"), R(". Foglietto: "), M("~/Documents/ISTAT/4fasi/DF_DCSS_POP_DEMCITMIG_TV_3"), R(". "), B("Entra nello Schedario stranieri \u00D7 comuni"), R(" (7.882 comuni). Nota: la cittadinanza \u00E8 in "), M("AREA_CONTRY_CITIZEN"), R(", non in "), M("CITIZENSHIP"), R(".")]));

children.push(H2("17.10  Scarico massivo TV_3 e tabella stranieri\u2019paese"));
children.push(P([R("Il cubo TV_3 \u00E8 stato scaricato massivamente dalla Fabbrichetta il 24 giugno 2026 con lo script "), M("scarico_TV3_v01.py"), R(", ossatura identica a "), M("scarico_eta_v03.py"), R(" (che ha macinato 9.380 comuni per l\u2019et\u00E0). Le differenze: chiave a "), B("dizionario"), R(" invece che posizionale (per evitare il disallineamento che causa 404), lotto iniziale G0=4 (TV_3 ha pi\u00F9 righe per comune dell\u2019et\u00E0), e la coda fissa "), M("RESFORPOP_AV + FRGAPO + ALL"), R(". Tutto il resto \u2014 freno 12,5s, retry, auto-split sul 400, "), M("_done.txt"), R(" per la ripartenza \u2014 invariato.")]));
children.push(table([
  ["Parametro scarico", "Valore"],
  ["Script", "scarico_TV3_v01.py (Salva Maglio v3, cartella 4_fasi/)"],
  ["Durata", "516 minuti (8,6 ore) · 1 restart per hung · poi filato liscio"],
  ["Lotti", "~2.350 da 4 comuni · 0 auto-split · 149 vuoti (404 comuni senza stranieri)"],
  ["Freno", "12,5s/query → 4,8 query/minuto"],
  ["Chiave", "dizionario Python, non stringa posizionale (evita disallineamento)"],
  ["Output grezzo", "2.345 file CSV in ISTAT/limbo/tv3_g/ · 18,6 MB zip · 136 MB decompressi"],
], [3200, 6770]));
children.push(SP());
children.push(P([B("Nota sulla chiave a dizionario.  "), R("Lo script costruisce la chiave passando un "), M("dict"), R(" a "), M("ISTAT.data()"), R(": "), M("key={\"INDICATOR\":\"RESFORPOP_AV\",\"REF_AREA\":cod1+\"+\"+cod2, ...}"), R(". sdmx1 mette ogni dimensione al suo posto nell\u2019ordine corretto, senza rischio di slittamento. Il bug di una chiave posizionale costruita a mano (es. "), M("\"A.097035.RESFORPOP_AV..ALL.FRGAPO..ALL\""), R(" con 8 posizioni invece di 9) produce un 404 silenzioso e apparentemente inspiegabile. La chiave a dizionario lo elimina alla radice.")]));
children.push(P([B("Tabella stranieri_paese (12\u00AA tabella del Magazzino):  "), R("4.777.708 righe · 7.980 comuni · 215 paesi/aree · anni 2018\u20132024 · sesso M/F/T · classe_eta sempre TOTAL. Schema: "), M("territorio \u00B7 sesso \u00B7 classe_eta \u00B7 paese \u00B7 anno \u00B7 valore"), R(". Ricevuta: "), M("stranieri_paese.csv.xz"), R(" (9,5 MB). Builder: "), M("build_stranieri_paese.py"), R(". Sentinelle: Esino Romania 2024 T = 16,0 \u2713 · Lipari paesi distinti 2024 \u2265 60 \u2713.")]));
children.push(P([B("Excel di consultazione:  "), M("stranieri_paese.xlsx"), R(" (31 MB, generato con xlsxwriter in streaming \u2014 openpyxl va in OOM su > 500k righe). Struttura cap. 32: foglio "), B("Comuni"), R(" (Vista larga, 283.290 righe, nomi comuni inclusi da tabella "), M("popolazione"), R("), foglio "), B("Lungo"), R(" (692.099 righe, 2022\u20132024, sesso=T), foglio "), B("Note"), R(". Nota tecnica: su file Excel con > 500k righe usare sempre xlsxwriter (streaming su disco) invece di openpyxl (tiene tutto in RAM \u2014 OOM su questa sandbox).")]));

// ---------- 18. NATI ----------
children.push(H1("18.  Il mattone laterale: i nati"));
children.push(P([R("I nati sono l\u2019indicatore "), B("anticipatore"), R(" del declino: crollano prima e pi\u00F9 ripidamente della popolazione. Ma non stanno negli stock: vivono nei cubi di "), B("bilancio"), R(", come tipo di dato "), M("LBIRTH"), R(".")]));
children.push(P([R("Due famiglie coprono il periodo lungo, con due ordini di variabili diversi:")]));
children.push(BULLET([B("moderno"), R("  \u2014  "), M("22_315_\u2026POPORESBIL1_1"), R(", 2019\u20132025, chiave "), M("A.<prov>.LBIRTH.9"), R(".")]));
children.push(BULLET([B("storico"), R("  \u2014  "), M("164_164_\u2026RICPOPRES2011_2"), R(", 2002\u20132018, chiave "), M("A.<prov>.LBIRTH.TOTAL.9.TOTAL"), R(" (ordine diverso).")]));
children.push(P([R("La "), B("giuntura"), R(" sta a 2018|2019: i nati sono un "), I("flusso"), R(" annuale, anni consecutivi senza sovrapposizione \u2014 a differenza degli stock, qui non c\u2019\u00E8 doppio conteggio. Copertura risultante: 2002\u20132025.")]));
children.push(warn([new Paragraph({ children: [B("\u26A0  Il mozzicone 2001.  "), R("Il bilancio storico parte di fatto dal 2002; il 2001 \u00E8 parziale e va scartato. E vale sempre il "), M("+1"), R(" di "), M("endPeriod"), R(", da neutralizzare filtrando in pandas.")] })]));
children.push(P([R("Lo script di scarico e giuntura \u00E8 in appendice (S5).")]));

// ---------- 19. PIRAMIDE ----------
children.push(H1("19.  La piramide: la variabile et\u00E0"));
children.push(P([R("La struttura per et\u00E0 si ricava dal dataflow "), M("22_289_\u2026POPRES1_2"), R(" (\u00ABBy age\u00BB), che d\u00E0 la popolazione provinciale per "), B("anno singolo"), R(" ("), M("Y0"), R("\u2026"), M("Y99"), R(", "), M("Y_GE100"), R(", pi\u00F9 "), M("TOTAL"), R("). Da l\u00EC si compongono le fasce volute.")]));
children.push(P([R("Quattro regole, pagate con errori veri:")]));
children.push(BULLET([R("si scaricano gli "), B("anni singoli"), R(" e si "), B("sommano"), R(" nelle fasce desiderate;")]));
children.push(BULLET([R("le fasce-scopo (over-66, 66\u201374, fertili 14\u201345\u2026) "), B("si sovrappongono e NON si sommano"), R(" fra loro;")]));
children.push(BULLET([R("quando si sommano gli anni singoli, "), B("ESCLUDERE il codice "), M("TOTAL"), R("  (altrimenti doppio conteggio);")]));
children.push(BULLET([R("bastano "), M("SEX=9"), R(" e "), M("SEX=2"), R(": i maschi si ricavano per differenza.")]));
children.push(P([R("Con questo si calcolano la quota di over-66, le sotto-fasce della vecchiaia, le femmine in et\u00E0 fertile e i centenari. Script in appendice (S7).")]));

// ---------- 20. STRANIERI ----------
children.push(H1("20.  Gli stranieri: un sottosistema a s\u00E9"));
children.push(P([R("La popolazione straniera ha i suoi cubi, i suoi totali e le sue insidie: va trattata come un sottosistema separato, non come un filtro della popolazione generale.")]));
children.push(BULLET([M("29_7_\u2026POPSTRRES1"), R("  \u2014  stranieri per et\u00E0 (senza cittadinanza), misura "), M("JAN"), R(".")]));
children.push(BULLET([M("29_317_\u2026POPSTRCIT1"), R("  \u2014  per cittadinanza, misura "), M("FJAN"), R("; il totale \u00E8 "), M("WORLD"), R(", "), B("non"), R(" "), M("TOTAL"), R(".")]));
children.push(BULLET([M("29_316_\u2026POPSTRBIL1"), R("  \u2014  bilancio, misure col prefisso F ("), M("FLBIRTH"), R(", "), M("ACQCITIZ"), R("\u2026).")]));
children.push(P([R("Per la "), B("fecondit\u00E0"), R(", il coniglio bianco "), M("FECONDITA1_7"), R(": tassi ASFR per cittadinanza (solo "), M("ITL"), R("/"), M("FRG"), R("/"), M("TOTAL"), R(" \u2014 nessun dettaglio per Paese), da cui il TFR per somma/1000. Per la "), B("composizione"), R(", il rapporto fra i sessi di "), M("POPSTRCIT1"), R(" rivela il modello migratorio (lavoro maschile, cura femminile, famiglia stabile). Script di convergenza in appendice (S8).")]));

// ---------- 21. INSIDIE ----------
children.push(H1("21.  Insidie e discipline tecniche"));
children.push(P([R("Le trappole pi\u00F9 costose, raccolte come disciplina operativa. Quasi tutte sono gi\u00E0 emerse: qui stanno insieme, da rileggere prima di ogni nuova campagna di scarico.")]));
children.push(BULLET([B("Mai vuotare "), I("tutte"), B(" le variabili.  "), R("La combinatoria completa abbatte il server. Fissare le non-indagate al totale ("), M("SEX=9, AGE=TOTAL, MARITAL_STATUS=99"), R(") e variare una cosa sola.")]));
children.push(BULLET([B("Validare ci\u00F2 che arriva.  "), R("Una fetch pu\u00F2 tornare parziale o malformata: prima di fidarsi, controllare forma, intervallo dei valori e numero di territori attesi (es. 107 province).")]));
children.push(BULLET([B("Nomi di variabili non standard.  "), R("Alcuni dataflow ("), M("NATI2"), R(") usano "), M("RESIDENCE_TERR"), R(", "), M("MOTHER_AGE"), R(" invece di "), M("REF_AREA"), R("/"), M("AGE"), R(". Non dare per scontati i nomi: leggere la struttura.")]));
children.push(BULLET([B("Escludere "), M("TOTAL"), B(" sommando gli anni singoli"), R("  (altrimenti doppio conteggio).")]));
children.push(BULLET([B("Gli ordini differiscono.  "), R("Tra famiglie l\u2019ordine delle variabili cambia: Fase 2 sempre, prima di una chiave.")]));
children.push(BULLET([B("Salvare su disco subito.  "), R("Il kernel di Carnets crolla: la ricevuta su file sopravvive; rilanciare salta il fatto.")]));
children.push(BULLET([B("Niente "), M("input()"), R(" (underscore); installazioni fragili con "), M("--no-deps"), R(".")]));
children.push(BULLET([B("Leggibilit\u00E0.  "), R("Mai leggere tabelle larghe grezze in Carnets: la tabella lunga \u00E8 il motore, i grafici e l\u2019Excel sono la faccia.")]));

// ---------- 22. RISULTATI ----------
children.push(H1("22.  Risultati verificati"));
children.push(P([R("Una sintesi di ci\u00F2 che i dati, una volta scaricati, hanno gi\u00E0 mostrato. Non \u00E8 il fine del progetto, ma la prova che l\u2019impianto regge.")]));
children.push(H2("22.1  La prova del nove"));
children.push(P([R("I nati italiani toccano il "), B("massimo nel 2008 (576.659)"), R(" e calano senza interruzioni dal 2009 fino a "), B("355.435 nel 2025"), R(": circa "), B("\u221238%"), R(". L\u2019unico anno in calo prima del picco \u00E8 il 2005. \u00C8 la conferma che far partire la base dal 2007 coglie l\u2019inizio vero della discesa.")]));
children.push(H2("22.2  Il crollo \u00E8 territoriale"));
children.push(P([R("Sui nati, il calo peggiore \u00E8 "), B("Cagliari \u221256,5%"), R(" (la Sardegna occupa le prime cinque posizioni). Sui residenti, il peggiore \u00E8 "), B("Enna \u221213,3%"), R(" (Sud interno e Sardegna). I nati crollano circa "), B("quattro volte pi\u00F9 ripidamente"), R(" dei residenti: i nati guidano, la popolazione segue. Dove arriva l\u2019immigrazione il legame si spezza (Prato, Rimini: nati persi, popolazione tenuta).")]));
children.push(H2("22.3  L\u2019invecchiamento, da vicino"));
children.push(P([R("Test su Nuoro ("), M("ITG26"), R("), 2019\u21922026:")]));
children.push(table([
  ["Indicatore", "2019", "2026"],
  ["over-66 (quota)", "23,0%", "27,1%"],
  ["femmine fertili (14\u201345)", "\u2014", "\u221216%"],
  ["centenari", "61", "123"],
], [4000, 2535, 2535]));
children.push(SP());
children.push(P([R("In sette anni i centenari raddoppiano (63,4 ogni 100.000), mentre la base fertile si assottiglia: la doppia morsa del declino.")]));
children.push(H2("22.4  La fecondit\u00E0 converge"));
children.push(P([R("Il TFR straniero scende da "), B("2,84 (2004)"), R(" a "), B("1,81 (2024)"), R("; quello italiano resta intorno a 1,1\u20131,3. Il divario si \u00E8 dimezzato e la fecondit\u00E0 straniera \u00E8 ormai "), I("sotto"), R(" la soglia di sostituzione: adattamento, ricomposizione delle provenienze, naturalizzazioni.")]));
children.push(H2("22.5  Chi sono gli stranieri"));
children.push(P([R("5,14 milioni, Romania al 21%. Il rapporto fra i sessi fotografa il modello migratorio: a lavoro maschile (Senegal, Pakistan, Bangladesh, Egitto: 12\u201334% donne), di cura femminile (Ucraina, Moldavia, Polonia, Per\u00F9: 67\u201383%), di famiglia stabile (Cina, Albania, Marocco: ~46\u201349%). La "), B("Sardegna"), R(" \u00E8 la regione a minore immigrazione (~3,4%), con un "), I("sorting"), R(" etnico particolare (Senegal secondo gruppo) e concentrazione nei grandi centri: l\u2019immigrazione non raggiunge l\u2019interno che si spopola.")]));
children.push(H2("22.6  La Sardegna, bomba a orologeria"));
children.push(P([R("TFR sardo "), B("0,85\u20130,91"), R(": il pi\u00F9 basso d\u2019"), B("Europa"), R(" (non del mondo \u2014 la Corea del Sud, ~0,72\u20130,75, sta sotto). Sommato alla longevit\u00E0 da "), I("Blue Zone"), R(" (la terra dei centenari) e alla minore immigrazione d\u2019Italia, \u00E8 il caso limite del fenomeno che il progetto studia.")]));

// ---------- 23. STATO ----------
// ---------- 23. ARCHITETTURA OPERATIVA ----------
children.push(H1("23.  L\u2019architettura operativa del Progetto"));
children.push(P([R("Per molto tempo il progetto \u00E8 stato una serie di accorgimenti. Da una certa sessione in poi ha una "), B("forma"), R(": un disegno che regge ai guasti invece di sperare che non capitino. Questo capitolo la fissa.")]));

children.push(H2("23.1  Gli asset"));
children.push(BULLET([B("Laboratorio / telefono"), R(" (l\u2019iPhone madre). Dove si concorda la strategia con gli azionisti e si fanno a mano le operazioni critiche, fantasiose o misteriose. "), I("Non"), R(" \u00E8 la fabbrica.")]));
children.push(BULLET([B("Fabbrica"), R(" (PC con script, o Claude Code). Produzione di massa "), I("unattended"), R("; un esecutore che fa solo ci\u00F2 che il CEO gli chiede.")]));
children.push(BULLET([B("Fabbrichetta"), R(" (iPhone muletto, Carnets in primo piano). Produzione "), I("unattended"), R(" leggera "), B("ovunque, anche senza PC"), R("; e backup del laboratorio e del telefono.")]));
children.push(BULLET([B("Due iPhone, sempre con s\u00E9"), R(" (mai entrambi in tasca). Non un comfort: \u00E8 l\u2019architettura. Uno macina in primo piano, l\u2019altro opera \u2014 e i ruoli si scambiano.")]));

children.push(H2("23.2  Il CEO unico"));
children.push(P([R("Nel progetto, Capo, Architetto, Ingegnere, Geometra e Informatico "), B("coincidono"), R(" in una sola testa (Claude). Vantaggio reale: zero riunioni, zero compromessi fra funzioni, zero politica \u2014 il Board si fa da soli. Gli "), B("azionisti"), R(" (la persona) danno la rotta; il CEO esegue e ne risponde.")]));

children.push(H2("23.3  Sicurezza per topologia, non per diligenza"));
children.push(P([R("Il presidio non \u00E8 comportamentale (\u00ABstai attento\u00BB) ma "), B("strutturale"), R(": chi produce "), B("non pu\u00F2 scrivere nei dati buoni"), R(". Chiunque pu\u00F2 lavorare facendo anche ci\u00F2 che vuole, tanto "), I("non pu\u00F2 modificare nulla"), R(". La sicurezza sta nella topologia \u2014 chi-scrive-dove \u2014 non nella bravura di chi opera.")]));

children.push(H2("23.4  Il Limbo, e la valvola di non ritorno"));
children.push(P([R("Il "), B("Limbo"), R(" (area di "), I("staging"), R(") \u00E8 la terra di mezzo dove l\u2019output "), I("esiste"), R(" ma non \u00E8 ancora "), I("verit\u00E0 del progetto"), R(".")]));
children.push(BULLET([R("Fabbrica e Claude Code scrivono "), B("solo nel Limbo"), R(". Mai nei dati buoni.")]));
children.push(BULLET([R("Dal Limbo non esce nulla da solo: il CEO legge, "), B("riscontra"), R(" (numeri, coerenze, saldature, le due sonde Esino/Lipari) e "), B("solo dopo"), R(" promuove a dato certificato.")]));
children.push(BULLET([M("test"), R(" \u2260 "), M("Limbo"), R(". In "), M("test"), R(" sta l\u2019output di processi "), I("non ancora certificati \u00Abin produzione\u00BB"), R(" (recinto chiuso, non comunica coi dati buoni). Nel "), M("Limbo"), R(" sta l\u2019output di processi "), I("gi\u00E0 in produzione"), R(", in attesa del riscontro. Un processo \u00ABpromuove\u00BB da collaudo a produzione una volta; i suoi output passano poi dal Limbo a ogni giro.")]));
children.push(P([B("Conseguenza logica. "), R("Se la fabbrica scrive solo nel Limbo, e dal Limbo si esce solo col riscontro, allora "), B("nessun guasto della fabbrica pu\u00F2 corrompere il progetto"), R(": il peggio \u00E8 uno staging da rifare. I dati buoni sono al sicuro "), I("per forma dell\u2019architettura"), R(", non per bravura dello script.")]));
children.push(warn([new Paragraph({ children: [B("Ci\u00F2 che il Limbo non protegge. "), R("Il "), I("giudizio"), R(". Il CEO pu\u00F2 certificare male (approvare un "), M("64"), R(" per distrazione). Il Limbo non salva da s\u00E9 stessi: d\u00E0 solo il posto e il tempo per "), I("guardare davvero"), R(" prima di promuovere.")] })]));

children.push(H2("23.5  Script unattended: innocui prima che perfetti"));
children.push(P([R("Lo script-unattended-perfetto che arriva in fondo perfetto "), B("non esiste in informatica"), R(". Esiste la costruzione intelligente di script che, "), I("se"), R(" arrivano, arrivano "), B("senza danni"), R(" e portano pi\u00F9 task possibile a casa. La gerarchia, nel nostro caso (tempo abbondante, consumo trascurabile):")]));
children.push(BULLET([B("Innocuo"), R(" \u2014 obbligatorio, non negoziabile (scrive solo nel Limbo).")]));
children.push(BULLET([B("Capitalizzante"), R(" \u2014 gradito: salva i task riusciti anche se il resto va a rotoli (salvataggio progressivo).")]));
children.push(BULLET([B("Ripartibile"), R(" \u2014 "), I("facoltativo"), R(": riprendere senza rifare \u00E8 un lusso, perch\u00E9 rilanciare da capo non \u00E8 un costo (di tempo ne abbiamo).")]));

children.push(H2("23.6  La regola di iOS (fabbrichetta su iPhone)"));
children.push(P([R("Misurato col cronometro (uno script che scrive l\u2019ora su file a intervalli fissi), il comportamento di iOS ha tre regimi netti:")]));
children.push(BULLET([B("Foreground"), R(" (Carnets davanti, schermo acceso): "), B("vivo"), R(" \u2014 360 battiti su 360, regolare al millisecondo.")]));
children.push(BULLET([B("Background"), R(" (un\u2019altra app davanti, "), I("anche a schermo acceso"), R("): "), B("congelato"), R(" dopo ~50 secondi. Non muore: si ferma, e riprende quando lo si riporta davanti.")]));
children.push(BULLET([B("Assenza lunga"), R(": iOS "), B("termina"), R(" l\u2019app (il kernel collassa). Ma il file su disco resta intatto.")]));
children.push(P([R("La linea di confine "), B("non \u00E8 la luce dello schermo"), R(", \u00E8 "), B("chi sta in primo piano"), R(". In una frase: \u00AB"), I("sei il problema quando cambi app, non quando sbirci"), R("\u00BB. Due corollari, dimostrati sul campo: il file su disco \u00E8 "), B("la sola verit\u00E0"), R(" (il video di Jupyter si perde dopo una sospensione); e il "), B("muletto"), R(" \u00E8 un iPhone tenuto con Carnets in foreground mentre si opera su un altro dispositivo.")]));
children.push(P([B("Niente Fort Knox. "), R("Contro il rischio (a bassa probabilit\u00E0) di cancellare i file per sbaglio non si costruisce un bunker: "), B("GitHub fa da copia gratuita"), R(" \u2014 effetto collaterale dell\u2019architettura (la fabbrica scrive sul repo, Claude legge clonando), non un muro costruito apposta.")]));

children.push(H2("23.7  La fabbrichetta (collaudata)"));
children.push(P([R("Lo scheletro certificato di uno script di produzione leggera: fa lavoro utile e incassa i capricci del server senza scomporsi.")]));
children.push(BULLET([B("Lista embedded"), R(" \u2014 i compiti scritti nel codice, mai "), M("input()"), R(" (l\u2019underscore rompe Carnets).")]));
children.push(BULLET([B("Throttle"), R(" \u2014 una pausa di cortesia fra una chiamata e l\u2019altra (~15 s: sotto le 5/minuto).")]));
children.push(BULLET([B("Retry automatico"), R(" \u2014 sul fallimento ritenta "), I("k"), R(" volte con pause crescenti; se non ce la fa, "), B("annota \u00ABfallito\u00BB e prosegue"), R(" col successivo (non si pianta).")]));
children.push(BULLET([B("Salvataggio progressivo"), R(" \u2014 il CSV si riscrive "), I("dopo ogni task"), R(": se iOS congela o il kernel muore, su disco c\u2019\u00E8 il fatto-finora.")]));
children.push(BULLET([B("Sentinella di fine"), R(" \u2014 ultima riga "), M("=== FATTO ==="), R(" con i conteggi (ok / falliti): \u00E8 l\u2019\u00ABalert\u00BB in versione su-disco (un file non si perde, una notifica s\u00EC).")]));
children.push(warn([new Paragraph({ children: [B("Lettura blindata: mai "), M(".sum()"), R(" a valle. "), R("Una dimensione lasciata vuota "), I("non sparisce: esplode in tutte le sue voci"), R(", totali compresi. Sommare prende dentro sia il totale sia i dettagli \u2014 \u00E8 cos\u00EC che Esino \u00E8 diventato "), M("64"), R(" invece di "), M("32"), R(" (il 32 del totale-et\u00E0 + i 32 dei singoli anni). Regola: chiedere "), B("sempre i totali in modo esplicito"), R(" (es. "), M("SEX=9"), R(", "), M("AGE=TOTAL"), R(") e prendere la "), B("singola cella"), R(", con una guardia \u00Abattesa 1 riga\u00BB che segnala se ne arrivano di pi\u00F9.")] })]));
children.push(P([R("Collaudo superato: 4 comuni veri scaricati ("), M("POPSTRRES1"), R(", stock straniero) pi\u00F9 un comune-esca fasullo correttamente "), B("FALLITO"), R(", col retry visto finalmente lavorare in un processo "), I("unattended"), R(".")]));

children.push(H1("24.  Stato del progetto e cantieri"));
children.push(H2("24.1  Cosa c\u2019\u00E8, oggi"));
children.push(BULLET([R("Metodo API certificato: le 4 fasi, i codici, i dataflow verificati (cap. 1\u201317).")]));
children.push(BULLET([R("Magazzino popolato a livello provinciale: popolazione "), B("2007\u20132026"), R(", nati "), B("2002\u20132025"), R(", nella tabella "), M("fatti"), R(".")]));
children.push(BULLET([R("Anagrafica dei territori e viste alberate per Excel; tutto rigenerabile dalle ricevute.")]));
children.push(BULLET([B("Cubi eventi vitali e fecondit\u00E0 certificati: "), R("nati per sesso/cittadinanza ("), M("NATI2_2"), R("), nati per paese ("), M("NATI2_5"), R("), e il "), B("TFR per cittadinanza della madre"), R(" ("), M("FECONDITA1_5"), R(", in "), M("DATA_TYPE=TOTFERR"), R("); il file "), M("Fecondita_.xlsx"), R(" dell\u2019autore \u00E8 esso stesso un mattone certificato (TFR provinciale 1999-2025).")]));
children.push(BULLET([R("Questo manuale operativo; e i documenti del "), B("Centro Studi Demografici"), R(": \u00ABLa Storia\u00BB (n.0, inaugurazione) e il "), B("Documento di lavoro n.1"), R(" (primo raccolto analitico: sorpasso, convergenza, Sardegna, il mucchio).")]));
children.push(H2("24.2  Cantieri aperti (to-do), ordinati per dipendenza"));
children.push(P([R("La lista è tenuta in ordine di "), B("priorità secondo la catena di dipendenze"), R(", non di interesse. Criterio: il "), I("fine"), R(" del progetto (scoprire qualcosa) sta in cima per interesse ma in fondo per fattibilità, perché ha bisogno che prima esista la base dati. L’ordine «intelligente» è quasi l’inverso di quello «emotivo»: prima si "), B("affila l’ascia"), R(" (gli abilitatori), poi si taglia l’albero. Ogni item porta sopra di sé le proprie dipendenze.")]));
children.push(BULLET([B("1. Abilitatore — nodi di produzione. "), R("Promuovere la "), B("fabbrichetta"), R(" da collaudo ("), M("test"), R(") a processo in produzione (→ scrive nel Limbo) quando ce ne fidiamo. "), I("Il 2° nodo è già pronto: l’ 11 Pro Max è certificato (vedi 6.5)."), R(" Costo basso, leva altissima: sblocca le maratone di download. Primo passo logico.")]));
children.push(BULLET([B("2. Base — pavimento dei comuni 2007→2026. "), R("Il dato che abilita ogni analisi territoriale (la tesi vive qui). "), M("POPRES1_24"), R(" (2019→) + "), M("RICPOPRES2011_24"), R(" (2007–2018), ~20 query annuali, da officina; entrambe reggono la query a tappeto. Dipende dal #1. Sotto-task: "), B("giuntura comuni 2018|2019"), R(" (codici che combaciano fra i due cubi); aggiungere i "), B("nati"), R(" ("), M("POPORESBIL1_24"), R(") e la "), B("piramide d’età"), R(" (anni singoli) — da PC: il multi-comune impianta il nuovo endpoint, vedi 24.3; la cittadinanza «dormiente» 2001–2019.")]));
children.push(BULLET([B("3. Il fine — la prova vera. "), R("Usare il magazzino per scoprire qualcosa di "), B("genuinamente ignoto"), R(" (§ 24.4): "), I("il"), R(" punto del progetto, mai fatto. Massimo interesse, ma prematuro finché manca il #2.")]));
children.push(BULLET([B("4. In parallelo — schedario stranieri. "), R("20 cubi da aprire (~2/sessione). Indipendente dagli altri, buon «riempitivo» tra task pesanti; rendimento però calato (resta forze-lavoro DCCV, "), M("CARS_PARK"), R(" probabili gusci, cubi >20k ab.). La famiglia ricca MIGR_BACKG è chiusa.")]));
children.push(BULLET([B("5. Verità a terra — verifica sul campo. "), R("Chiedere alla famiglia rumena di Esino com’è costituito ufficialmente il nucleo: l’unico modo di mettere un nucleo reale sopra lo sfondo statistico (i 7 naturalizzati, i 3 nati qui). Bassa urgenza, alto valore.")]));
children.push(BULLET([B("Rifiniture sparse. "), R("Il "), M(".0"), R(" nelle viste (già tolto in resa Excel); le province sarde IT108–IT111 (codice a tre cifre dopo «IT») da classificare come provincia; certificare la mappa codice → nome.")]));
children.push(H2("24.3  Diario di bordo (in progress)"));
children.push(info([new Paragraph({ children: [B("Nota.  "), R("Annotazioni recenti, "), I("non ancora consolidate"), R(": restano qui finch\u00E9 non diventano fatti stabili, poi migrano nei capitoli veri.")] })]));
children.push(P([B("Il canale dati: GitHub.  "), R("Repo pubblico "), M("github.com/Marrimac/LIFOstack"), R(". Modello: "), B("la fabbrica scrive, l\u2019officina legge"), R(". Claude lo clona via bash (GitHub \u00E8 raggiungibile dalla sandbox), quindi il link, una volta salvato, non va reincollato. Claude "), I("non"), R(" ci scrive (push richiede un token, escluso). Provato: letti dal repo un CSV e un notebook.")]));
children.push(P([B("Officina e fabbrica.  "), R("Due esecutori dello stesso Manuale. "), B("Officina"), R(" = Claude in chat + Carnets: esplorazione, giudizio, analisi; poche chiamate; da iPhone. "), B("Fabbrica"), R(" = Claude Code sul PC: caricamenti di massa, temporizzati, non sorvegliati. Confine: la fabbrica esegue, non interpreta \u2014 \u00ABse salta l\u2019imprevisto, fermati e scrivi nello stato\u00BB. Segnale di consegna: \u00ABc\u2019\u00E8 posta per te\u00BB \u2192 Claude ritira da GitHub. Regola: la fabbrica "), B("non resta mai zitta"), R(" (l\u2019output, pi\u00F9 un file di stato: ultimo fatto, righe, esito).")]));
children.push(P([B("Piano Comuni \u2014 sonde.  "), R("Cubi validati al livello comune: popolazione "), M("POPRES1_24"), R(" (dal 2019, chiave "), M("A.<com>.JAN.9.TOTAL.99"), R("); storico "), M("RICPOPRES2011_24"), R(" (ordine "), M("FREQ\u00B7REF_AREA\u00B7DATA_TYPE\u00B7AGE\u00B7SEX\u00B7CITIZENSHIP"), R(", chiave "), M("A.<com>.JAN.TOTAL.9.TOTAL"), R("); nati "), M("POPORESBIL1_24"), R(" (ordine "), M("FREQ\u00B7REF_AREA\u00B7DATA_TYPE\u00B7SEX"), R(", chiave "), M("A.<com>.LBIRTH.9"), R("). "), B("Entrambe le sorgenti reggono la query a tappeto"), R(" (~8.000 territori in un colpo) \u2192 il Piano Comuni \u00E8 "), B("officina, non fabbrica"), R(". Sonda Esino (097035): pop 771\u2192755\u2192747 (2019/2024/2025); 50enni 13 (2024); nati 10 (2019). (Il tappeto regge per il TOTALE d\u2019et\u00E0; la piramide per et\u00E0 \u00E8 l\u2019eccezione \u2014 vedi sotto.)")]));
children.push(P([B("Eventi vitali e fecondit\u00E0 \u2014 cubi aperti.  "), R("Tre cubi nuovi, provinciali/regionali. "), B("Nati"), R(" per sesso e cittadinanza: "), M("NATI2_2"), R(" \u2014 sesso e cittadinanza non sono dimensioni, stanno nei suffissi di "), M("DATA_TYPE"), R(" ("), M("LBIRTH"), R(", "), M("LBIRTH_FOREIGN"), R(", ecc.). "), B("Nati per paese"), R(" estero: "), M("NATI2_5"), R(", il paese in "), M("CITIZEN_FOREIN_OFBIRTH"), R(" (ISO-2). "), B("TFR per cittadinanza"), R(" della madre: "), M("FECONDITA1_5"), R(", chiave "), M("A.<terr>.TOTFERR.<ITL|FRG|TOTAL>.TOTAL"), R(" \u2014 il tasso sta in "), M("DATA_TYPE=TOTFERR"), R(", lo split italiane/straniere parte dal 2002. Il file "), M("Fecondita_.xlsx"), R(" dell\u2019autore, sondato, \u00E8 dato ISTAT autentico: \u00E8 il mattone, non si riscarica.")]));
children.push(P([B("Piramide comunale per et\u00E0 \u2014 la verit\u00E0 (corregge il \u00ABgratis\u00BB).  "), R("Lo stock per et\u00E0 si chiede a "), M("POPRES1_24"), R(" con "), M("DATA_TYPE=JAN"), R(": "), M("A.<com>.JAN.9.<et\u00E0>.99"), R(". Il cubo tiene solo le "), B("et\u00E0 singole"), R(" (Y0\u2026Y_GE100), non gli aggregati 0-14/65+: le fasce si sommano. Sonda Esino 2024 certificata \u2014 "), B("indice di vecchiaia 244"), R(" contro ~193 nazionale. "), B("Ma"), R(" la piramide di tutti i comuni "), B("non \u00E8 \u00ABgratis\u00BB su mobile"), R(": sul nuovo endpoint il "), M("+"), R(" non espande la gerarchia ("), M("ITC1+"), R(" rende solo la regione) e la selezione "), B("multi-comune"), R(" lo fa impiantare (12 comuni in stallo, due volte). Resta o un territorio per molte et\u00E0, o "), M("REF_AREA"), R(" vuoto a una et\u00E0 per volta (~50 mini-chiamate): fragile su Carnets, quindi "), B("lavoro da PC"), R(".")]));
children.push(P([B("Il primo dossier del CSD.  "), R("Prodotto il "), B("Documento di lavoro n.1"), R(" del Centro Studi Demografici ("), M("Dossier_CSD_n1"), R("): sorpasso, convergenza del TFR straniero verso l\u2019italiano, la Sardegna fuori gara, il \u00ABmucchio\u00BB dei comuni (90% in deficit naturale, piatto per taglia), taglia-contro-et\u00E0 (il deficit dei piccoli \u00E8 invecchiamento: +6,3\u2030 morti contro +1,9\u2030 nati). Sempre correlazioni, non prove. Il CSD \u00E8 inaugurato; \u00ABLa Storia\u00BB \u00E8 il n.0.")]));

children.push(H2("24.4  La prova vera"));
children.push(P([R("Tutto, finora, ha "), I("ri-verificato"), R(" numeri in gran parte gi\u00E0 noti: \u00E8 il collaudo dell\u2019impianto. La validazione del progetto sar\u00E0 il giorno in cui questo magazzino servir\u00E0 a scoprire qualcosa di "), B("genuinamente ignoto"), R(" \u2014 un comune, una soglia, un incrocio che nessuno aveva guardato. Da \u00ABstrumento che funziona\u00BB a \u00ABstrumento che ha detto qualcosa di nuovo\u00BB: \u00E8 quello il traguardo.")]));


// ---------- 25. NASCITE, GENERATORI, RICOSTRUZIONE, COLLAUDO (v19) ----------
children.push(H1("25.  Le nascite nel magazzino, i generatori, la ricostruzione e il collaudo"));
children.push(P([R("Il magazzino ha "), B("cinque tabelle"), R(" (erano tre): alle "), M("popolazione"), R(", "), M("flussi"), R(" e "), M("territori_anagrafica"), R(" si aggiungono le due delle nascite. Tutto ci\u00F2 che segue \u00E8 "), B("certificato"), R(": i builder rifanno il magazzino dai soli semi al numero esatto, i generatori ne rendono i tre workbook, il collaudo verifica le firme.")]));

children.push(H2("25.1  Le due tabelle delle nascite"));
children.push(P([B("nascite"), R(" \u2014 dal cubo "), M("NATI2_2"), R(", arco 1999\u20132024, livelli Italia/ripartizione/regione/provincia. Colonne "), M("codice\u00B7nome\u00B7livello\u00B7anno\u00B7sesso\u00B7gruppo\u00B7valore"), R(". Sei "), M("DATA_TYPE"), R(" alla fonte mappano gruppo\u00D7sesso:")]));
children.push(BULLET([M("LBIRTH"), R(" / "), M("LBIRTH_MALE"), R(" / "), M("LBIRTH_FEMALE"), R("  \u2192  gruppo "), B("tutti"), R(" (totale/maschi/femmine).")]));
children.push(BULLET([M("LBIRTH_FOREIGN"), R(" / "), M("LBIRTH_MALE_FOREIGN"), R(" / "), M("LBIRTH_FEMALE_FOREIGN"), R("  \u2192  gruppo "), B("stranieri"), R(".")]));
children.push(BULLET([B("italiani"), R(" = "), M("tutti \u2212 stranieri"), R(", per sesso (non c\u2019\u00E8 un DATA_TYPE proprio).")]));
children.push(P([B("nascite_paese"), R(" \u2014 dal cubo "), M("NATI2_5"), R(" (nati per "), I("paese di cittadinanza"), R("), arco 1999\u20132024, livelli Italia/ripartizione/regione. Colonne "), M("codice\u00B7nome\u00B7livello\u00B7anno\u00B7paese_cod\u00B7paese\u00B7valore"), R(". La dimensione paese ha tre piani sovrapposti: "), M("WORLD"), R(" (=Mondo, coincide con "), M("LBIRTH_FOREIGN"), R(" della tabella nascite), 5 continenti ("), M("AFR/AME/ASI/EUR/OCE"), R("), e i paesi singoli. Si tengono "), B("solo i paesi singoli"), R(": 210 codici \u2212 6 aggregati = "), B("204 paesi"), R(" (dentro restano 999 apolidi, UNK ignoti, Kosovo, Sud Sudan).")]));
children.push(warn([new Paragraph({ children: [B("\u26A0  Namibia.  "), R("Il codice paese della Namibia \u00E8 "), M("NA"), R(": i dizionari dei nomi vanno letti con "), M("keep_default_na=False, na_values=[]"), R(", altrimenti pandas lo legge come nullo (stessa trappola del comune "), M("None"), R(").")] })]));

children.push(H2("25.2  I tre generatori workbook (lo stampo CSD)"));
children.push(P([R("Un generatore per workbook \u2014 "), M("genera_excel_popolazione.py"), R(", "), M("genera_excel_flussi.py"), R(", "), M("genera_excel_nascite.py"), R(" \u2014 leggono il magazzino e scrivono il "), M(".xlsx"), R(" in "), M("workbooks/"), R(". I workbook sono "), B("render del magazzino"), R(": nessuna modifica a mano da salvare, la verit\u00E0 \u00E8 nel "), M(".db"), R(". Lo stampo: fogli \u00ABlarghi\u00BB con "), B("terzina"), R(" per anno (intestazione a due righe, l\u2019anno scavalca la terzina, colonne-id fuse a sinistra, freeze sulla prima colonna-dato) + un foglio "), M("Lungo_per_pivot"), R(". Le terzine:")]));
children.push(BULLET([B("popolazione"), R(": "), M("M / F / T"), R(" (i tre sessi). Fogli Provincia, Regione, Ita_Ripart, Comuni, Lungo.")]));
children.push(BULLET([B("flussi"), R(": "), M("nat. / migr. / tot."), R(" dove "), M("nat.=NTGROW_REGOF"), R(", "), M("migr.=INTNETMIGR_REGOF+INTERTNMIG_REGOF"), R(" (interno+estero), "), M("tot.=TOTAL_BAL"), R(". Fogli Comuni, Province, Lungo (i 7 componenti, nomi italiani).")]));
children.push(BULLET([B("nascite"), R(": "), M("italiani / stranieri / tutti"), R(". Fogli Province, Regione, Ita_Ripart, Lungo, + due fogli nazionalit\u00E0 (foglio largo regione\u00D7paese e relativo lungo).")]));

children.push(H2("25.3  La ricostruzione dai semi (i quattro builder)"));
children.push(P([R("I builder "), M("build_popolazione.py"), R(", "), M("build_flussi.py"), R(", "), M("build_nascite.py"), R(", "), M("build_nascite_paese.py"), R(" rifanno le tabelle dai soli "), B("semi"), R(" (le ricevute), senza toccare ISTAT. Provati: ricostruito il magazzino in un db di test, le quattro tabelle escono "), B("identiche al certificato, riga per riga"), R(" (627.861 / 377.866 / 31.950 / 158.790, \u0394 0, zero righe "), M("altro"), R("). Override "), M("CSD_DB"), R(" per scrivere altrove.")]));
children.push(info([new Paragraph({ children: [B("Regola d\u2019oro nei builder.  "), R("Il "), M("livello"), R(" si deriva "), B("dal ponte"), R(" ("), M("territori_istat"), R(", profondit\u00E0 della catena parent: 1=ripartizione, 2=regione, 3=provincia, 4=comune), "), B("mai dalla forma del codice"), R(". \u00C8 questo che corregge a monte le tre province a suffisso-lettera "), M("ITC4A"), R(" Cremona, "), M("ITC4B"), R(" Mantova, "), M("ITE1A"), R(" Grosseto \u2014 nei pavimenti grezzi marcate "), M("altro"), R(" (il difetto da \u2212975.769 su \u03A3province), nel ponte tornano province.")] })]));

children.push(H2("25.4  Il collaudo (le quattro fasi)"));
children.push(P([M("collaudo.py"), R(" certifica il magazzino (legge "), M("CSD_DB"), R(" o "), M("../istat.db"), R(") \u2014 verde su tutto, sul magazzino ricostruito:")]));
children.push(BULLET([B("1 \u00B7 popolazione"), R(": \u03A3province = Italia "), I("e"), R(" \u03A3comuni = Italia (2024, scarto 0); M+F = T ovunque.")]));
children.push(BULLET([B("2 \u00B7 flussi"), R(": terzina di Esino 2019 = 2 / \u221210 / \u221214; identit\u00E0 contabile tot = naturale+migratorio+rettifiche dove i componenti sono completi (il 2025 ne \u00E8 privo \u2014 ISTAT non pubblica rettifiche/saldo-totale per l\u2019ultimo anno).")]));
children.push(BULLET([B("3 \u00B7 nascite"), R(": \u03A3province = Italia (tutti, totale); M+F = T; italiani = tutti \u2212 stranieri.")]));
children.push(BULLET([B("4 \u00B7 nascite_paese + sentinelle"), R(": \u03A3paesi = nascite-stranieri (= WORLD); 204 paesi; Namibia presente e nominata; Esino 097035, Lipari 083041, Lecco ITC43 2026 = 334.211.")]));
children.push(P([B("Arco.  "), R("Le nascite si fermano al "), B("2024"), R(" perch\u00E9 i cubi "), M("NATI2"), R(" sono fermi al 2024 (non un troncamento nostro); popolazione e stranieri "), M("JAN"), R(" arrivano al 2026 (stock a data, orologio diverso).")]));



// ---------- 26. L'ESTINTORE: PRINCIPIO DUPLICE BACK-UP & RESTORE (metodologia, v20) ----------
children.push(H1("26.  L\u2019Estintore: il principio duplice back-up & restore"));
children.push(P([R("L\u2019Estintore \u00E8 il kit che fa ripartire il progetto quando un thread collassa. La sua forza non \u00E8 un file, ma un "), B("principio duplice"), R(": ogni kit porta due cose "), B("ridondanti"), R(", e \u2014 punto cruciale \u2014 "), B("equivalenti per costruzione"), R(". \u00C8 la pulizia a renderlo affidabile, non l\u2019estetica.")]));

children.push(H2("26.1  I due lati"));
children.push(BULLET([B("Back-up \u2014 il magazzino pronto a partire."), R("  Lo snapshot "), M("istat.db.gz"), R(": "), M("gunzip"), R(" e si parte. Non \u00E8 un dump a fiducia: \u00E8 la fotografia di un magazzino che "), B("ha passato il collaudo"), R(".")]));
children.push(BULLET([B("Restore da zero \u2014 semi + ricette."), R("  I "), B("semi"), R(" (le ricevute: il dato grezzo certificato) e le "), B("ricette"), R(" (i builder, i generatori, il collaudo). Se il back-up basta, si riparte subito; se si deve ricostruire, verificare o estendere, le ricette rifanno il magazzino dai semi, "), B("in locale, senza ISTAT"), R(".")]));

children.push(H2("26.2  La disciplina che rende fidato il back-up"));
children.push(P([R("Niente entra nel magazzino a fiducia. Fabbrica e Fabbrichetta scrivono "), B("solo nel Limbo"), R("; l\u2019unico varco Limbo\u2192magazzino \u00E8 la "), B("certificazione"), R(" con saldature esplicite. Da qui, tre regole non negoziabili:")]));
children.push(BULLET([B("Regola d\u2019oro \u2014 il livello dal ponte."), R("  Il "), M("livello"), R(" si deriva dalla catena parent ("), M("territori_istat"), R("), "), B("mai dalla forma del codice"), R(". \u00C8 il fix che chiude \u03A3province = Italia e disinnesca la trappola "), M("ITC4A"), R("/"), M("ITC4B"), R("/"), M("ITE1A"), R(" ereditata da Claude Due (il difetto da \u2212975.769).")]));
children.push(BULLET([B("I workbook sono render del magazzino."), R("  Una sola fonte di verit\u00E0 (il "), M(".db"), R("): gli Excel si "), B("rigenerano"), R(", non si correggono a mano. Niente modifiche da salvare, niente derive.")]));
children.push(BULLET([B("Autoportanza e path relativi."), R("  Ogni ricetta si regge da sola, con "), M("ROOT"), R(" relativa al kit e override "), M("CSD_DB"), R(": gira ovunque si spacchetti il kit, senza stato implicito.")]));

children.push(H2("26.3  La prova che i due lati coincidono"));
children.push(P([R("Il restore non \u00E8 un\u2019approssimazione del back-up. I quattro builder, lanciati sui "), B("soli semi"), R(" in un database vergine, hanno riprodotto il magazzino "), B("al numero esatto"), R(": "), M("627.861 / 377.866 / 31.950 / 158.790"), R(", "), B("\u0394 0"), R(", zero righe "), M("altro"), R(". Semi + ricette "), B("\u2261"), R(" snapshot. \u00C8 questa equivalenza "), I("dimostrata"), R(" che autorizza a fidarsi del back-up: se domani lo snapshot mancasse o fosse sospetto, le ricette lo rifanno identico.")]));

children.push(H2("26.4  Il collaudo: saldature, non fiducia"));
children.push(P([M("collaudo.py"), R(" \u00E8 il cancello, in quattro fasi (dettaglio dei controlli al cap. 25). La filosofia: ogni firma \u00E8 una "), B("saldatura indipendente"), R(" \u2014 \u03A3province e \u03A3comuni = Italia, M+F = T, italiani = tutti\u2212stranieri, \u03A3paesi = WORLD \u2014 e le "), B("sentinelle"), R(" (Esino 097035, Lipari 083041, Lecco ITC43 = 334.211) validano il dato contro la realt\u00E0 nota. Si certifica solo se \u00E8 tutto verde.")]));

children.push(H2("26.5  Il confezionamento e la prova finale"));
children.push(P([R("Si assembla il kit \u2014 snapshot + ricevute + ricette + i due "), B("gemelli"), R(" KB e Manuale alla "), B("stessa versione"), R(" \u2014 e poi si fa la "), B("prova finale"), R(": spacchettare da zero in una cartella vergine, "), M("gunzip"), R(", lanciare il collaudo e un generatore. "), B("Si consegna solo se \u00E8 verde da spacchettato"), R(". Il kit \u00E8 versionato (N.1, N.2, N.3\u2026); KB e Manuale viaggiano dentro come gemelli.")]));
children.push(info([new Paragraph({ children: [B("In una riga.  "), R("L\u2019Estintore tiene insieme un "), B("back-up certificato"), R(" e un "), B("restore dimostrato-equivalente"), R(". La disciplina non \u00E8 forma: \u00E8 ci\u00F2 che rende la ripartenza affidabile.")] })]));



children.push(H2("26.6  Il vincolo di trasferimento e l\u2019architettura incrementale"));
children.push(P([R("L\u2019Estintore monolitico dei \u00A7\u00A7 precedenti aveva un presupposto implicito: che il kit intero potesse "), B("viaggiare"), R(". Crescendo il Magazzino, quel presupposto cade. Misurato sul campo: "), M("istat.db"), R(" vivo \u00E8 ~1.855 MB, compresso ~310 MB \u2014 e il canale chat verso l\u2019autore ha un tetto reale di "), B("~60 MB"), R(" (via app iPhone; il browser web regge "), I("meno"), R(", non di pi\u00F9). Il pezzo pi\u00F9 pesante \u00E8 esattamente quello che l\u2019autore non pu\u00F2 ricevere.")]));
children.push(info([new Paragraph({ children: [B("L\u2019asimmetria del canale.  "), R("Claude "), B("non pu\u00F2"), R(" fare push su GitHub (niente token); l\u2019autore "), B("s\u00EC"), R(", e da GitHub Claude clona senza limiti di peso. Ma dalla chat verso l\u2019autore i file pesanti non passano. Conseguenza: il DB \u2014 pesante \u2014 "), B("non viaggia mai in nessuna direzione"), R(". Rinasce dai builder applicati alle ricevute.")] })]));
children.push(P([B("Le ricevute viaggiano in xz, non gzip.  "), R("I dati demografici sono molto ripetitivi (per l\u2019et\u00E0: 102 et\u00E0 \u00D7 3 sessi \u00D7 8 anni per comune, con "), M("stato_civile"), R(" e "), M("tipo_dato"), R(" costanti). "), M("xz"), R(" sfrutta la ridondanza assai meglio di gzip: la ricevuta et\u00E0 passa da 67,6 MB (gzip) a ~19\u201349 MB (xz, secondo il preset). Con xz "), B("ogni singola ricevuta sta sotto i 60 MB"), R(" e viaggia intera. Nessun file va spezzato.")]));
children.push(P([B("La coppia gemella: vivo e congelato.  "), R("Il sistema si regge sull\u2019"), B("integrit\u00E0 delle ricevute in mano all\u2019autore"), R(". Perch\u00E9 quell\u2019integrit\u00E0 sia "), I("provata"), R(" e non solo sperata, l\u2019autore tiene "), B("due copie distinte"), R(" del Magazzino:")]));
children.push(BULLET([B("Il gemello vivo"), R(" \u2014 copia di lavoro allineata a quella di Claude. Quando arriva una ricevuta, la si applica "), B("qui"), R(" col builder e si verificano le sentinelle (Esino 747, M+F=T). \u00C8 la pietra di paragone: senza un Magazzino funzionante dell\u2019autore non si pu\u00F2 "), I("provare"), R(" che una ricevuta \u00E8 sana.")]));
children.push(BULLET([B("Il congelato"), R(" \u2014 lo snapshot immutabile da cui ripartire se il vivo si corrompe. Non si tocca, non gli si applica nulla sopra.")]));
children.push(info([new Paragraph({ children: [B("La regola del back-up provato.  "), R("Un back-up mai ripristinato non \u00E8 un back-up: \u00E8 una speranza. La prova di ogni ricevuta va fatta "), B("al momento della ricezione"), R(", non al momento del bisogno. Per questo ogni ricevuta che Claude consegna arriva "), B("accompagnata dal suo builder e dalla sua prova"), R(" (lo script che la applica e stampa le sentinelle) \u2014 mai un CSV nudo.")] })]));
children.push(P([B("Il modello incrementale.  "), R("Una volta sola si congela un "), M("istat.db"), R(" base \u2014 la versione pi\u00F9 pesante che passa il canale, o pi\u00F9 semplicemente l\u2019Estintore esistente pi\u00F9 le ricevute mancanti ricostruite in locale. Da l\u00EC in poi quel file non viaggia pi\u00F9: ogni nuova tabella arriva come "), B("ricevuta xz"), R(". Se tutto salta: l\u2019autore parte dalla base + applica le ricevute accumulate, e in ~15 minuti (sono gi\u00E0 consolidate, niente ISTAT) il Magazzino \u00E8 di nuovo allineato. Il pezzo pesante viaggia "), B("una volta"), R("; tutto ci\u00F2 che cresce dopo viaggia come ricevuta \u2014 sempre pi\u00F9 leggera del DB che aiuta a costruire.")]));
children.push(P([B("Conseguenza sull\u2019Estintore versionato.  "), R("Il kit si "), B("scompone per provenienza e tasso di crescita"), R(": le "), B("ricevute"), R(" (pesanti, in crescita, prodotte da Claude e versionate dall\u2019autore su GitHub) da un lato; le "), B("ricette"), R(" (leggere, quasi statiche: builder, generatori Excel, collaudo, Manuale, KB) consegnabili in chat per sempre dall\u2019altro. Il DB non sta n\u00E9 di qua n\u00E9 di l\u00E0: \u00E8 il prodotto dei builder sulle ricevute.")]));

// ---------- 27. GLI STRANIERI: STOCK E STRUTTURA PER ETA' (v21) ----------
children.push(H1("27.  Gli stranieri: stock e struttura per et\u00E0"));
children.push(P([R("Due tabelle nuove dal cubo "), M("POPSTRRES1"), R(": lo "), B("stock"), R(" dei residenti stranieri al 1\u00B0 gennaio e la loro "), B("struttura per et\u00E0"), R(". Il magazzino sale a "), B("sette tabelle"), R(". Entrambe certificate, rese in Excel.")]));

children.push(H2("27.1  Il cubo POPSTRRES1 e le sue 23 varianti"));
children.push(P([R("Stock al 1\u00B0 gennaio. Dimensioni: "), M("FREQ"), R(", "), M("REF_AREA"), R(" ("), M("CL_ITTER107"), R("), "), M("DATA_TYPE"), R(" ("), M("CL_TIPO_DATO15"), R("), "), M("SEX"), R(", "), M("AGE"), R(" ("), M("CL_ETA1"), R("), "), M("TIME_PERIOD"), R(". "), B("Niente cittadinanza"), R(" qui ("), M("CL_CITTADINANZA"), R(" collassato a "), M("TOTAL"), R("): per la nazionalit\u00E0 serve un cubo gemello (a memoria "), M("POPSTRCIT1"), R(", da verificare). "), M("DATA_TYPE"), R(": l\u2019unico popolato \u00E8 "), M("JAN"), R(" ("), M("RESFOR"), R("/"), M("FJAN"), R("/"), M("FDEC"), R(" danno 404).")]));
children.push(BULLET([B("La famiglia \u00E8 spaccata per regione."), R("  "), M("_1"), R(" = i soli aggregati (Italia + ripartizioni + regioni + province, 137). "), M("_2"), R("\u2026"), M("_22"), R(" = una regione ciascuna (totale + province + comuni). "), M("_23"), R(" = "), B("tutta Italia"), R(" (8.128 territori, comuni + aggregati). Per lo stock nazionale si usa "), M("_23"), R(": una variante sola, niente da ricucire.")]));
children.push(warn([new Paragraph({ children: [B("\u26A0  Vecchi NUTS.  "), R("In questo cubo ISTAT codifica Nord-Est e Centro coi "), B("vecchi NUTS"), R(" ("), M("ITDA"), R(" Trentino, "), M("ITD3"), R(" Veneto, "), M("ITD4"), R(" Friuli, "), M("ITD5"), R(" Emilia-R., "), M("ITE1"), R(" Toscana, "), M("ITE2"), R(" Umbria, "), M("ITE3"), R(" Marche, "), M("ITE4"), R(" Lazio), non coi nuovi ("), M("ITH*"), R("/"), M("ITI*"), R("). Il ponte "), M("territori_istat"), R(" li contiene gi\u00E0 \u2014 0 codici ignoti. Non assumere i nuovi NUTS: leggere il codice dal cubo.")] })]));
children.push(info([new Paragraph({ children: [B("Trentino.  "), R("ITDA \u00E8 la regione-cappello; le due autonome Bolzano e Trento sono contate "), B("a livello regione"), R(" \u2014 fra le 22 \u00ABregioni\u00BB il Trentino compare tre volte (ITDA + Bolzano + Trento), e \u03A3regioni \u2212 Italia = ITDA. Ai livelli provincia e comune nessun doppio conteggio (\u03A3province = \u03A3comuni = Italia, \u0394 0). \u00C8 la stessa struttura di "), M("popolazione"), R(".")] })]));

children.push(H2("27.2  La sesta tabella: stranieri (stock)"));
children.push(P([B("stranieri"), R(" \u2014 da "), M("POPSTRRES1_23"), R(", "), M("DATA_TYPE=JAN"), R(", "), M("AGE=TOTAL"), R(", "), M("REF_AREA"), R(" e "), M("SEX"), R(" aperti \u2192 tutti i territori, M/F/T, arco 2019-2026. Colonne "), M("codice\u00B7nome\u00B7livello\u00B7anno\u00B7sesso\u00B7valore\u00B7fonte"), R(" ("), M("fonte=POPSTRRES1"), R("). 193.155 righe, livelli 1/7/22/107/7991 identici a popolazione; stesso stampo Excel (terzina M/F/T).")]));
children.push(BULLET([B("Dato: "), R("stranieri 4,996 mln (2019) \u2192 5,560 mln (2026), +11%; quota femminile 51,7% \u2192 49,3% (mascolinizzazione anno su anno).")]));

children.push(H2("27.3  La settima tabella: stranieri_eta (struttura per et\u00E0)"));
children.push(P([B("stranieri_eta"), R(" \u2014 stesso cubo "), M("_23"), R(", ma "), M("AGE"), R(" "), B("aperto"), R(" \u2192 et\u00E0 singole "), M("Y0"), R("\u2026"), M("Y_GE100"), R(" (normalizzate a "), M("eta 0..100"), R(", "), M("Y_GE100"), R("=100). "), B("Solo a livello provincia"), R(": et\u00E0 singole \u00D7 comuni \u2248 20 milioni di righe (esplosione), a provincia \u2248 260k (leggero). Colonne "), M("codice\u00B7nome\u00B7livello\u00B7anno\u00B7sesso\u00B7eta\u00B7valore\u00B7fonte"), R(". 259.368 righe.")]));
children.push(BULLET([B("Strategia di scarico: "), R("niente wildcard sui territori (senn\u00F2 arrivano i comuni) \u2192 si interroga per i "), B("107 codici-provincia espliciti"), R(", presi dalla tabella "), M("stranieri"), R(" (vintage giusta del cubo). Batch ~14 province con sintassi multi-codice "), M("A+B+C"), R(", arco intero per batch; "), B("ripiego automatico per singola provincia"), R(" se il server non gradisce; ripartibile per batch.")]));
children.push(BULLET([B("Le fasce non standard"), R(" (0-17 / 18-30 / 31-50 / 51-67 / 68+) si ricavano "), B("binnando"), R(" le et\u00E0 singole: si tiene il grezzo, le soglie si cambiano quando si vuole senza riscaricare.")]));

children.push(H2("27.4  Le saldature di certificazione"));
children.push(BULLET([B("Stock: "), R("\u03A3province = \u03A3comuni = Italia (\u0394 0 ogni anno); M+F=T (0 eccezioni); Esino "), M("_23"), R(" = "), M("_5"), R(" (50/30/\u2026/38); Lombardia 2024 = 1.203.138.")]));
children.push(BULLET([B("Et\u00E0: "), R("M+F=T (0 ecc.); "), B("\u03A3(et\u00E0 singole) = TOTAL"), R(" (0 ecc. su 2.568) \u2014 la saldatura che chiude; aggancio allo stock: \u03A3province(TOTAL) = Italia in "), M("stranieri"), R(" (\u0394 0), Lecco 27.035 combacia.")]));

children.push(H2("27.5  Il dato: la piramide degli stranieri"));
children.push(P([R("Italia 2024 \u2014 0-17: 19,6% ; 18-30: 17,0% ; "), B("31-50: 40,4%"), R(" ; 51-67: 18,9% ; 68+: 4,1%. Et\u00E0 mediana "), B("~37 anni"), R(". \u00C8 una popolazione da immigrazione: gobba in et\u00E0 lavorativa, "), B("appena il 4% over-68"), R(" (contro ~24% di over-65 sui residenti totali). \u00C8 la ragione strutturale per cui l\u2019immigrazione sostiene la popolazione \u2014 arrivi giovani in et\u00E0 da lavoro, non fertilit\u00E0; lega al dato nascite-stranieri (cap. 18 / diario).")]));
children.push(P([I("Restano fuori da questo cubo (fetch separati, cubi gemelli): la "), B("nazionalit\u00E0 / paese di provenienza"), I(" e le "), B("acquisizioni di cittadinanza"), I(". Prossimi capitoli.")]));


// ---------- 28. IL MAGLIO (v22) ----------
children.push(H1("28.  Il Maglio: il catalogo interrogabile dei dataflow ISTAT"));
children.push(P([R("Il Maglio è il cantiere più strategico del progetto: la macchina che trasforma l'intero ISTAT — i circa 4.000 dataflow — in un "), B("catalogo di copertura interrogabile"), R(". La domanda d'arrivo è una sola: «che cosa esiste per Esino Lario nel 2021?» — e la risposta è una "), M("SELECT"), R(", non una caccia. È l'industrializzazione del metodo delle 4 fasi (cap. 12): il gesto con cui si apre e si certifica un cubo, ripetuto da un programma che gira da solo. Se arriveremo a mapparli tutti, avremo prodotto un'opera unica.")]));
children.push(info([new Paragraph({ children: [B("Missione e strategia.  "), R("La "), B("missione"), R(" è popolare il Magazzino per studiare la crisi demografica; la "), B("strategia"), R(" è aprire e catalogare i cubi. Il Maglio è la strategia fatta industria — il braccio che riempie la dispensa da cui la missione cucina.")] })]));

children.push(H2("28.1  L'idea: dall'indice rovesciato a «Esino 2021?»"));
children.push(P([R("Il seme è un "), B("indice rovesciato"), R(": non più "), I("cubo → cosa copre"), R(", ma "), I("copertura richiesta → quali cubi"), R(". Portato su scala piena diventa un indice "), B("dataflow × territorio × anno"), R(", interrogabile per cella: «Esino, 2021» → la lista dei dataflow che rispondono, ciascuno con cosa offre. Costruirlo è il lavoro grosso (una-tantum); "), B("usarlo è istantaneo per sempre"), R(" — la stessa filosofia del «pavimento» dei comuni, ma sull'intero catalogo.")]));
children.push(P([R("Il "), B("prototipo in scala 1:40"), R(" esiste già: lo "), B("Schedario stranieri"), R(" (i 41 cubi stranieri × comuni, aperti a mano — vedi il generatore "), M("genera_schedario"), R("). Quei 41 hanno insegnato "), I("come"), R(" si apre e si certifica un cubo; il Maglio è quel gesto ripetuto da una macchina su migliaia.")]));

children.push(H2("28.2  Il cambio di mondo: dal POSTINO alla Fabbrica"));
children.push(P([R("I 41 li abbiamo aperti col "), B("POSTINO"), R(" — Claude scrive lo script, l'autore lo esegue su Carnets, niente persiste. Il Maglio è l'opposto: vive sul PC della "), B("Fabbrica"), R(", "), B("gira da solo e ricorda"), R(" — filesystem che sopravvive, fetch fatte da lui, 24×7. La proprietà numero uno, da progettare per prima, è «"), B("non fermarsi mai"), R("».")]));
children.push(P([R("Oggi la Fabbrica (il PC) non è ancora operativa; il Maglio è "), B("in fase di test sulla Fabbrichetta"), R(" (l'iPhone 11). Vale il "), B("principio del superset"), R(": se l'unattended gira nel posto angusto — un telefono, con Carnets in primo piano e iOS che può sospendere — il posto largo (il PC) eredita con margine. La Fabbrichetta è il banco a "), B("condizioni note"), R(" (le fetch dei 41 le ha fatte lei, col trucco SSL-legacy del cap. 5). L'unica cosa che lì non si può provare è la "), B("durata reale"), R(" a macchina sola: quella la garantirà solo il PC.")]));
children.push(warn([new Paragraph({ children: [B("SSL sul PC.  "), R("Il trucco SSL-legacy serviva su iOS; su un PC OpenSSL può comportarsi diversamente. Una delle primissime prove in Fabbrica sarà "), I("vedere se il PC fetcha pulito"), R(" o se serve anche lì.")] })]));

children.push(H2("28.3  I tre verbi: scarta, sonda, mappa"));
children.push(P([R("L'architettura sono le 4 fasi diventate macchina, in tre lame:")]));
children.push(table([
  ["Lama", "Cosa fa", "Costo"],
  ["Scarta", "Una lettura di struttura per cubo (fase «trova dimensioni»): legge la codelist del territorio e decide se il cubo sa indirizzare un comune.", "leggerissimo"],
  ["Sonda", "Sui candidati, guidata a lotti dal fiuto dell'autore: forza bruta su anni e territori — prova, guarda cosa risponde, registra.", "il vero costo ISTAT"],
  ["Mappa", "Ogni esito → una riga nell'indice di copertura (dataflow · livello · anni · misura · note), tabella SQLite. «Esino 2021?» → SELECT.", "nullo (locale)"],
], [1400, 6170, 1500]));
children.push(info([new Paragraph({ children: [B("La nota da incorniciare.  "), R("Il Maglio "), B("cataloga, non interpreta"), R(". Riempie la matrice di fatti grezzi («cubo X · 2019 · comune · 30 righe»); ma «TV_4 vive solo nel 2019», «7.152 auto su 1.000 stranieri è impossibile», «BL è "), I("bachelor"), R(" non "), I("basic"), R("» — quelle "), I("letture"), R(" le mette l'occhio, dopo. La macchina suda, l'intelligenza resta a mano.")] })]));

children.push(H2("28.4  Il banco-oracolo: i 41 a verità nota"));
children.push(P([R("Il metodo di collaudo che ha fatto la differenza: usare i 41 come "), B("oracolo etichettato"), R(". Per ognuno lo Schedario, costruito a mano, dichiara già il verdetto (scende al comune o no). Quando una lama sentenzia, non le si crede: si "), B("confronta riga per riga"), R(" col verdetto noto. Una divergenza è un bug "), I("con la risposta in mano"), R(" — un test contro un oracolo vale dieci volte un test al buio.")]));
children.push(P([B("Il caveat, fondamentale: i 41 sono un campione drogato."), R(" Scelti a soggetto, scendono "), I("tutti"), R(" al comune — quindi collaudano solo il «sì» della lama, mai il «no». Per provare il «no» (la Scarta che scarta davvero) serve un secondo set "), B("a spettro"), R(": cubi che dal nome "), I("devono"), R(" scendere (altre famiglie — sanità, economia, edifici), cubi che "), I("non"), R(" devono (regioni, dato nazionale, conti economici), e "), B("trappole"), R(" (sospetti over-dichiaratori). Lì l'oracolo è il "), I("nome"), R(" (la colonna "), M("nome_it"), R("): una previsione, non un certificato — le divergenze sono il dato, non «bug».")]));

children.push(H2("28.5  La scoperta che ridisegna il Maglio: l'over-dichiarazione"));
children.push(P([R("La prima corsa sui 41 ha segnalato «16 BUG». "), B("Non erano bug."), R(" Verde, guscio e campionaria dichiarano "), B("tutti"), R(" la codelist "), M("CL_ITTER107"), R(" (12.471 comuni) — anche le 16 indagini campionarie "), M("DCCV"), R(", che poi vivono solo a livello di regione. È l'"), B("over-dichiarazione"), R(" del DSD: ISTAT attacca la codelist completa dei comuni alla dimensione territoriale "), I("anche"), R(" di un cubo che i comuni non li ha. È «il dichiarato mente», in carne e ossa.")]));
children.push(P([B("Conseguenza che cambia il disegno: la lettura-struttura non discrimina."), R(" Sul catalogo pieno la Scarta dice «comune» a quasi tutto ciò che ha un "), M("REF_AREA"), R("; taglia davvero solo i "), B("dump senza territorio"), R(" (i circa 356 "), M("BULK"), R("). È un "), B("primo taglio a basso costo"), R(", non il discriminatore. Il discriminatore vero può venire solo dalla "), B("Sonda"), R(": solo il "), I("dato"), R(" non mente.")]));

children.push(H2("28.6  La Sonda validata: il probe-Esino"));
children.push(P([R("Il grimaldello in uso (chiamiamolo "), B("probe-Esino"), R(") chiede al cubo il dato di Esino ("), M("REF_AREA=097035"), R(") e conta i valori "), B("non-nulli"), R(". Tre esiti, validati sui tre casi-verità del «41»:")]));
children.push(BULLET([B("verde"), R(" ("), M("POPRES1"), R(") → "), B("si accende"), R(": 2.448 osservazioni vere.")]));
children.push(BULLET([B("guscio"), R(" ("), M("CARS_1"), R(") → "), B("buio"), R(": righe con valori "), M("NaN"), R(" (la serie esiste, il valore è vuoto) — per questo si contano i "), I("non-nulli"), R(", non le righe.")]));
children.push(BULLET([B("campionaria"), R(" ("), M("DCCV"), R(") → "), M("404"), R(": il comune è assente dai dati — è "), B("buio"), R(", non un guasto.")]));
children.push(P([B("Quale comune: Esino"), R(", ed è la scelta giusta — è il caso più duro, il più piccolo; un cubo che arriva a Esino arriva ovunque, e uno che non ci arriva è inutile alla tesi territorio-centrica. "), B("Quale anno: nessuno in particolare"), R(" — TV_4 insegna che un cubo può avere solo il 2019; sondare «l'ultimo anno» lo mancherebbe. "), B("Cosa conta come coperto:"), R(" una sola osservazione comunale non-nulla. È una mappa di "), I("copertura"), R(", non di completezza.")]));
children.push(warn([new Paragraph({ children: [B("Due trappole pagate.  "), R("(1) Il codice di Esino "), B("non si indovina, si pesca dalla codelist"), R(" con match "), B("esatto"), R(" «Esino Lario»: il match largo «esino» pesca Caronno Var"), I("esino"), R(", San Genesio At"), I("esino"), R(", ecc. (2) «Esino Lario» compare "), B("due volte"), R(" in "), M("CL_ITTER107"), R(" — il vecchio codice (Como, pre-1992) e l'attuale (Lecco, "), M("097035"), R("): si preferisce 097035.")] })]));
children.push(P([R("Esiste un grimaldello migliore in teoria — "), M("detail=serieskeysonly"), R(": farsi elencare le serie che "), I("hanno"), R(" un dato senza scaricarne i valori, cioè la copertura territoriale vera in un colpo (ciò che "), M("availableconstraint"), R(", ormai morto, avrebbe dovuto dare). Ma su "), M("esploradati.istat.it"), R(" fa "), M("404"), R(": per ora resta il probe-Esino.")]));

children.push(H2("28.7  Come non si ferma mai: le proprietà dell'unattended"));
children.push(P([R("Le proprietà stanno nel ciclo, esplicite — perché lo script-unattended-perfetto «non esiste in informatica»: esiste lo script costruito perché, comunque vada, porti a casa più lavoro possibile.")]));
children.push(BULLET([B("Ripartibile"), R(": commit dopo ogni cubo; allo start salta i già-fatti.")]));
children.push(BULLET([B("A prova di guasto"), R(": ogni cubo in "), M("try/except"), R(" che annota l'errore e prosegue.")]));
children.push(BULLET([B("A ritmo"), R(": un freno a "), B("intervallo fisso"), R(" (~12,5s fra una fetch e l'altra, ~4,8/minuto) — mai raffiche, sempre sotto il muro dei 5/minuto.")]));
children.push(BULLET([B("Idempotente"), R(": rilanciarlo non rifà il lavoro già fatto.")]));
children.push(BULLET([B("Zero "), M("input()"), R(": un "), M("input()"), R(" in uno script non sorvegliato resta appeso per sempre in attesa di nessuno. È una "), B("regola del Maglio"), R(", non un dettaglio.")]));
children.push(P([B("Output e disciplina.  "), R("Niente "), M(".db"), R(" (i binari non passano in chat): scrive "), B("CSV leggibili"), R(" — "), M("scarta_esiti.csv"), R(", "), M("scarta_log.txt"), R(", una piccola cache. In collaudo scrive "), B("solo in "), M("ISTAT/test"), R(" — mai nella root di Carnets, mai nei dati buoni; in produzione i CSV-ricevuta andranno nel "), B("Limbo"), R(" (cap. 23). La codelist "), M("CL_ITTER107"), R(" (12.471 codici) si scarica "), B("una volta sola"), R(" e si riusa, non si ri-pompa per ogni cubo.")]));

children.push(H2("28.8  I costi, misurati (non a sensazione)"));
children.push(P([R("Il cronometro spacca i tempi: "), B("struttura ~0,6s · dato fino a ~400s"), R(" — e l'eternità è tutta nella query del "), I("dato"), R(", e "), B("solo sui giganti «per età»"), R(" (milioni di chiavi). I cubi comunali normali rendono il dato in meno di un secondo: i "), B("giganti lenti sono pochi"), R(".")]));
children.push(P([R("Sui 4.000, a una fetch per cubo e 5/minuto: circa "), B("13 ore"), R(" — una notte, ma adesso "), I("contata"), R(". Due affilature: il muro dei 5/minuto era pensato per le query di "), I("dato"), R(" — se la lettura di "), I("struttura"), R(" non fosse limitata allo stesso modo, la Scarta volerebbe ("), B("da verificare"), R("); e «mappare 4.000» non è l'obiettivo. Il telaio è "), B("forza bruta guidata sui pochi giusti"), R(": dei 4.871 cubi del catalogo, circa "), B("700 hanno un nome parlante"), R(", gli altri ~4.150 sono «muti» — si parte dai parlanti, a lotti scelti dal fiuto. Qualche centinaio di cubi, un paio di notti, non i dodici giorni dello spauracchio.")]));

children.push(H2("28.9  Dove sfocia: l'Archiviatore e le viste"));
children.push(P([R("Il Maglio "), I("trova"), R(" dove esiste il dato; non lo porta a casa. Quel passo è dell'"), B("Archiviatore"), R(" (un notebook), che fonde le ricevute "), M("fetch_full_*.csv"), R(" nel magazzino, e delle "), B("viste consolidate"), R(" (es. "), M("vista_regioni"), R(", pivot anno × sesso coi territori in riga) che sono il formato d'arrivo. Maglio e Archiviatore sono i due capi della stessa catena: mappa-e-sonda da un lato, consolida dall'altro.")]));

children.push(H2("28.10  Gli ingredienti e lo stato (a oggi)"));
children.push(P([B("Ingredienti (tutti disponibili).  "), R("Il catalogo dei ~4.000 — "), M("catalogo_dataflow.csv"), R(", 4.871 righe ("), M("id"), R(" · "), M("nome_it"), R(", con righe doppie id-nudo/"), M("DF_"), R("); le quattro "), B("codelist"), R(" (età, sesso, stato civile, tipo-dato); e gli script "), M("Scarta v05"), R(" e "), M("Sonda v02"), R(". Il taglio a freddo del catalogo, ricontato: "), M("DCCV"), R(" 1.375, "), M("DCIS"), R(" 775 + "), M("DCSS"), R(" 95 = 870 (la corsia comune-probabile), "), M("BULK"), R(" 356 (i dump senza territorio).")]));
children.push(P([B("Stato (in test sulla Fabbrichetta).  "), R("La "), B("Scarta"), R(" è collaudata (sui 41 drogati e su un set a spettro) e si è rivelata un "), B("filtro debole"), R(" — taglia solo i dump senza territorio. La "), B("Sonda"), R(" (probe-Esino) è "), B("validata"), R(" sui tre casi-verità ed è il discriminatore vero. La "), B("Mappa"), R(" è ancora da costruire come tabella che cresce. Restano "), B("due nodi aperti"), R(": se la lettura-struttura sia limitata come il dato (se no, la Scarta vola), e il "), M("serieskeysonly"), R(" morto su esploradati.")]));
children.push(info([new Paragraph({ children: [B("I progressi delle corse.  "), R("Il diario delle prossime corse di test del Maglio — versioni, lotti, esiti — sarà tenuto a parte, in un capitolo dedicato «Progressi del Maglio», da aprire quando i test ripartono. Qui sta "), I("cos'è e come funziona"), R("; lì starà "), I("come sta andando"), R(".")] })]));


// ---------- 29. IL MULETTO, LA DISPENSA, LO SCHEDULATORE (v23) ----------
children.push(H1("29.  Il muletto, la Dispensa e lo Schedulatore: la filosofia del lavoro incustodito"));
children.push(P([R("Il cap. 28 ha industrializzato la "), I("strategia"), R(" (aprire e catalogare i cubi). Questo capitolo descrive "), B("come si fanno girare i lavori lunghi"), R(": la filosofia del lavoro incustodito, nata sul campo durante lo scarico del bilancio degli stranieri. L'infrastruttura — le macchine, il Limbo, il trucco SSL — sta nel cap. 23; qui sta il "), I("pensiero"), R(" che la governa. Il principio in una riga: la macchina sa macinare da sola, ma siamo noi a scegliere "), B("cosa"), R(" e "), B("quando"), R(", in base alla finestra.")]));

children.push(H2("29.1  Il muletto leale (la Fabbrichetta)"));
children.push(P([R("La Fabbrichetta (l'iPhone 11) "), B("non è un PC mancato"), R(": è una macchina con un suo profilo. La sola differenza con la Fabbrica (il PC) è la "), B("funzionalità"), R(", non la "), B("durata"), R(": il telefono può trottare per ore senza che sia un problema. Il PC serve solo per ciò che il telefono "), I("non può proprio fare"), R(" — se mai emergerà. Questo affina la distinzione Fabbrica/Fabbrichetta del cap. 23.")]));
children.push(P([R("Quando il PC non serve, il muletto ha vantaggi propri: "), B("sta sempre con te"), R(" (niente accessi remoti da allestire — la prossimità è un pregio, non un ripiego); "), B("non costa nulla"), R(" (è il telefono precedente, già nello zaino per il back-up, di norma spento; tenerlo attivo fa perfino bene alla batteria); e — non secondario — "), B("ti fa compagnia"), R(" mentre trotta.")]));

children.push(H2("29.2  L'asse vero: sorvegliato o incustodito, e la regola dello spreco"));
children.push(P([R("L'asse non è giorno/notte: è "), B("sorvegliato o incustodito"), R(".")]));
children.push(BULLET([B("Sorvegliato"), R(" (la Fabbrichetta è con te, le dai un'occhiata): i lavori "), B("nuovi, incerti, da primo giro"), R(" — dove può saltar fuori un 404, un tetto, un codice che non torna. La tua presenza "), I("è"), R(" la rete di sicurezza. Lavori corti e rischiosi.")]));
children.push(BULLET([B("Incustodito"), R(" (la posi dove ha rete e corrente e nessuno la tocca — di notte mentre russi, o in un angolo di giorno): i lavori "), B("lunghi, già collaudati, che si fidano di sé"), R(" — si auto-spezzano, ritentano, ripartono dai file. Non serve il tuo occhio perché il lavoro "), I("ha l'occhio dentro"), R(".")]));
children.push(P([R("La notte è solo il caso-limite più ghiotto (~8 ore di trotto incustodito garantito: lei trotta e tu russi). Un angolo diurno con rete e presa è una notte più corta — stessa logica.")]));
children.push(warn([new Paragraph({ children: [B("La regola dello spreco.  "), R("Spreco "), B("non"), R(" è far girare la Fabbrichetta: un'ora di lavoro vero è gratis e perfino salutare. Spreco è una "), B("finestra di trotto incustodito senza un lavoro lungo dentro"), R(" (andare a letto senza la macinata grossa), o un "), B("lavoro lungo che muore"), R(" perché non era pronto a star solo, o "), B("lanciare di sera un lavoro che finisce in fretta"), R(" (una notte sprecata). Il discrimine non è «quanto gira», ma «se quel che fa serve, e se sta nella finestra».")] })]));

children.push(H2("29.3  Si battezza di giorno, si macina di notte"));
children.push(P([R("Un lavoro destinato all'incustodito "), B("deve aver già fatto il suo primo giro sorvegliato"), R(". Il bilancio l'abbiamo imparato a fatica (le varianti regionali che fanno 404, il tetto a ~10.000 osservazioni per query, i timeout di rete): "), I("adesso"), R(" sa star da solo. Un cubo nuovo no — prima lo si guarda trottare su un pezzetto, poi lo si manda a dormire da solo. In breve: "), B("si battezza di giorno, si macina di notte"), R(".")]));

children.push(H2("29.4  Dimensionare il lavoro alla finestra: due cibi in dispensa"));
children.push(P([R("Da qui una conseguenza pratica: tenere sempre "), B("due cibi pronti"), R(" —")]));
children.push(BULLET([R("un "), B("boccone breve sorvegliato"), R(" (una sonda, un cubo leggero) → da darle quando sei lì e hai dieci minuti;")]));
children.push(BULLET([R("una "), B("macinata lunga incustodita"), R(" (l'età degli italiani, migliaia di query) → da lanciare prima di andare a letto, o quando la lasci in un angolo.")]));
children.push(P([R("È la stessa intuizione del Maglio («forza bruta guidata»): il telaio sa macinare da solo, ma il fiuto sceglie cosa e quando. Non è un lusso: è "), B("dimensionare il lavoro alla finestra"), R(".")]));

children.push(H2("29.5  La Dispensa CaB (Cucinato alla Bisogna)"));
children.push(P([R("La "), B("Dispensa"), R(" è la credenza degli script pronti: "), B("testati"), R(" (battezzati), "), B("descritti bene"), R(", pronti da lanciare. A seconda della situazione sai quale — o "), I("quali"), R(", al plurale — lanciare. Non è uno stack "), M("LIFO"), R(" né "), M("FIFO"), R(": è "), B("CaB, «Cucinato alla Bisogna»"), R(" — l'ordine lo decidi alla bisogna, non per disciplina fissa.")]));
children.push(P([R("Perché un piatto stia in Dispensa deve rispettare alcune "), B("regole d'oro"), R(":")]));
children.push(BULLET([B("autonomo"), R(": zero "), M("input()"), R(".")]));
children.push(BULLET([B("ripartibile dai propri file"), R(": se rilanciato, riprende da dove era — non ricomincia.")]));
children.push(BULLET([B("ordinato nel Limbo"), R(": ognuno scrive nella sua cartella, non pesta i piedi agli altri.")]));
children.push(BULLET([B("con i milestone"), R(": stampa l'avanzamento (es. «127/342 lotti · ~3.700/9.380 comuni · ~38 min»). Un contatore è un "), B("requisito, non un lusso"), R(".")]));
children.push(BULLET([B("a terminazione garantita"), R(": finisce "), B("sempre"), R(", comunque vada — mai appeso; se la rete cade, si ferma pulito invece di pendere all'infinito.")]));

children.push(H2("29.6  Lo Schedulatore: il battito cieco, e la separazione dei mestieri"));
children.push(P([R("Se la finestra incustodita è lunga e un piatto solo non la riempie, vuoi infilarne "), B("più d'uno in fila"), R(". Serve uno "), B("Schedulatore"), R(": la sera scrivi una "), I("lista della spesa"), R(" (stasera questi, in quest'ordine), lanci lui, e vai a dormire; lui pesca dalla Dispensa e tira giù un piatto dopo l'altro.")]));
children.push(P([R("Lo Schedulatore è "), B("cieco per progetto"), R(": non sa nulla dei cubi, nulla dell'output, e "), B("nemmeno se un run è finito bene o male"), R(". Sa fare una cosa sola: «il run in corso è finito? allora parto col prossimo». È un "), B("battito, non un giudice"), R(". L'output di ogni run finisce comunque nel Limbo; più tardi il "), B("Postino"), R(" lo raccoglie e lo porta al "), B("CEO"), R(", che valida il contenuto (e può rimandare indietro: una saldatura che non torna = ri-scarico). Allo Schedulatore tutto questo è "), I("trasparente"), R(".")]));
children.push(info([new Paragraph({ children: [B("Perché «terminazione garantita» è la regola-madre.  "), R("Un direttore cieco che aspetta solo «è finito?» può essere battuto da "), B("un solo nemico"), R(": un piatto che "), I("non finisce mai"), R(". Per questo la robustezza non sta nello Schedulatore — sta in "), B("ogni piatto"), R(", che deve sempre fermarsi. Lo Schedulatore concatena; ogni script si arrangia da solo.")] })]));
children.push(P([B("La separazione dei mestieri"), R(" (la stessa pulizia del Maglio): lo "), B("Schedulatore"), R(" garantisce che la fila "), I("scorra"), R("; ogni "), B("script"), R(" garantisce che il proprio lavoro sia "), I("giusto"), R("; il "), B("Postino"), R(" porta l'output dal Limbo al "), B("CEO"), R(", che "), I("valida"), R(". Conseguenza: uno scarico "), B("non è «fatto» quando finisce di scaricare"), R(", ma quando il CEO l'ha validato — perciò il lavoro successivo gira "), I("in parallelo"), R(" alla validazione, non al suo posto.")]));


children.push(H2("29.7  Il hung dell\u2019AP/SIM e il wrapper di rilancio"));
children.push(P([R("Nello scarico reale del progetto \u2014 prima POPSTRCIT1, poi POPRES1_24 \u2014 la Fabbrichetta si \u00e8 fermata una volta per scarico: a 90 minuti nel primo, a 120 nel secondo. Ogni volta la ripartenza manuale ha funzionato e lo scarico \u00e8 proseguito senza altri intoppi. La diagnosi iniziale indicava iOS come colpevole; l\u2019indagine successiva ha spostato il colpevole pi\u00f9 a monte.")]));
children.push(info([new Paragraph({ children: [B("Il vero colpevole: l\u2019AP con SIM.  "), R("L\u2019architettura di rete usata in entrambi gli scarichi era: Fabbrichetta \u2192 WiFi \u2192 Access Point con scheda SIM dati \u2192 carrier mobile \u2192 ISTAT. I carrier mobili applicano un "), B("timeout NAT"), R(" sulle connessioni TCP prolungate: dopo 60\u2013120 minuti di sessione HTTP aperta il carrier chiude silenziosamente la connessione, e lo script \u2014 che sta aspettando la risposta \u2014 rimane appeso. iOS non \u00e8 l\u2019imputato; \u00e8 uno spettatore innocente.")] })]));
children.push(P([B("L\u2019architettura di Bardonecchia \u00e8 la stessa.  "), R("Il PC della Fabbrica gira a Bardonecchia con la stessa topologia: PC \u2192 AP con SIM (carrier diverso, struttura identica) \u2192 ISTAT. Cambia la SIM, non la vulnerabilit\u00e0. Senza contromisure il PC si comporter\u00e0 come la Fabbrichetta: un hung ogni 60\u2013120 minuti, ripartenza manuale necessaria.")]));
children.push(P([B("La soluzione su iOS \u2014 pausa programmata.  "), R("Su Carnets il bash non \u00e8 disponibile, quindi la contromisura vive "), I("dentro"), R(" lo script: un check wall-clock all\u2019inizio di ogni iterazione del loop. Quando il tempo di sessione supera la soglia (25 minuti, conservativa rispetto ai 90\u2013120 osservati), lo script stampa un messaggio chiaro, dorme 15 minuti e riparte. La soglia e la durata sono parametri regolabili in cima allo script ("), M("SOGLIA_PAUSA"), R(", "), M("DURATA_PAUSA"), R("). L\u2019incognita aperta: iOS \u00e8 pi\u00f9 clemente col processo dormiente o meno? La risposta \u00e8 empirica; il worst case \u00e8 identico al comportamento precedente.")]));
children.push(P([B("La soluzione su PC \u2014 wrapper bash di rilancio.  "), R("Sul PC il bash \u00e8 disponibile e la soluzione \u00e8 esterna allo script \u2014 pi\u00f9 pulita: un wrapper che rilancia automaticamente dopo ogni hung.")]));
children.push(codeBox("# wrapper bash — lancia e rilancia finché lo script non esce con 0\nwhile ! python3 scarico.py; do\n    echo \"hung o errore — riavvio in 60s...\"\n    sleep 60\ndone\necho \"completato\""));
children.push(P([R("Il wrapper non sa nulla del cubo, non legge l\u2019output, non valida niente: sa solo che se il processo esce con codice non-zero deve rilanciarlo. \u00c8 lo stesso principio dello Schedulatore cieco del \u00a7 29.6 \u2014 ma al livello del singolo script invece che della fila.")]));
children.push(info([new Paragraph({ children: [B("La lezione trasversale.  "), R("La "), B("ripartibilit\u00e0 dai file"), R(" \u2014 gi\u00e0 regola d\u2019oro della Dispensa (ogni script riprende da dove era, salta i lotti gi\u00e0 fatti) \u2014 era stata progettata per iOS. Si rivela "), B("la stessa fondamenta"), R(" che rende funzionante il wrapper bash sul PC. Il mattone \u00e8 uno solo; regge entrambe le architetture senza modificare gli script. Inciampando si impara a camminare.")] })]));
children.push(P([B("Nota operativa per Bardonecchia.  "), R("Prima di lanciare qualsiasi macinata lunga: (a) verificare che il carrier della SIM non abbia un timeout NAT inferiore a 60 minuti (alcune SIM machine-to-machine hanno soglie pi\u00f9 basse); (b) avvolgere ogni script col wrapper bash; (c) verificare che "), M("_done.txt"), R(" e i CSV del Limbo siano su un percorso che sopravvive al riavvio del processo (sono su filesystem, quindi s\u00ec). Fatto questo, il hung diventa un evento invisibile: lo script si ferma, il wrapper lo rialza, lo script riprende dal lotto successivo.")]));

// ---------- 30. I CUBI SONDATI (v24) ----------
children.push(H1("30.  I cubi sondati: stranieri, cittadinanza, età e stato civile"));
children.push(P([R("In questa tornata abbiamo aperto un intero sottosistema di cubi attorno alla popolazione straniera — il bilancio, la cittadinanza, lo stato civile — più i cubi-complemento sulla popolazione totale per età. Il cap. 27 aveva lo stock e la piramide; qui c'è la mappa di tutto il resto: cosa dà ciascun cubo, a che livello, con quali trappole. La regola del cap. 12 («ogni cubo nuovo va sondato e poi documentato, sennò è come non averlo fatto») è il motivo per cui questo capitolo esiste.")]));
children.push(warn([new Paragraph({ children: [B("Due fatti validi per tutti questi cubi.  "), R("(1) "), B("I comuni stanno solo nelle varianti «_23» (stranieri) o «_24/_25/_26» (POPRES1)"), R(": le varianti regionali _2.._22 rispondono "), M("404"), R(" se chiedi un comune. (2) C'è un "), B("tetto a ~10.000–15.500 osservazioni per query"), R(": oltre, "), M("HTTP 400"), R(". Si aggira con REF_AREA multi-valore (gruppi di comuni «cod+cod+…») e il filtro d'anno "), M("startPeriod/endPeriod"), R(". Il «come» del lavoro lungo e resiliente sta nel cap. 29.")] })]));

children.push(H2("30.1  Mappa dei cubi"));
children.push(table([
  ["Cubo", "Livello", "Cosa dà (oltre il sesso)", "Limite chiave"],
  ["29_316_…POPSTRBIL1_23", "comune", "bilancio: 20 eventi, le tre porte", "solo _23 per i comuni"],
  ["29_317_…POPSTRCIT1_23", "comune", "cittadinanza (660 paesi, tot. WORLD)", "niente età"],
  ["22_289_…POPRES1_24/_25/_26", "comune", "età e/o stato civile (pop. totale)", "_26 pesantissimo; no cittadinanza"],
  ["…DCSS_FORPOP_1_GC", "prov./gr. città", "età × stato civile × cittadinanza", "cittadinanza solo macro-area"],
  ["…POPSTRRES1 (web I.Stat)", "naz. / comune", "marginali: età, paese, comune", "sono marginali, non il congiunto"],
], [2750, 1450, 2900, 1970]));
children.push(SP());

children.push(H2("30.2  POPSTRBIL1 — il bilancio degli stranieri: le tre porte"));
children.push(P([R("Cubo comune "), M("29_316_DF_DCIS_POPSTRBIL1_23"), R(" («All municipalities»). Cinque variabili: "), M("FREQ·REF_AREA·DATA_TYPE·SEX·TIME"), R("; "), M("SEX"), R("=1/2/9 (maschi/femmine/totale); anni 2019–2025. La ricchezza sta nei "), B("20 codici DATA_TYPE"), R(", che sono la contabilità completa della popolazione straniera di un comune: stock a inizio e fine anno, saldo naturale, entrate e uscite (interne ed estere), acquisizioni di cittadinanza.")]));
children.push(BULLET([B("Stock: "), M("FJAN"), R(" (1° gennaio), "), M("FDEC_CP"), R(" (31 dicembre).")]));
children.push(BULLET([B("Saldo naturale: "), M("FLBIRTH"), R(" (nati), "), M("FDEATH"), R(" (morti), "), M("FNATGR"), R(" (saldo).")]));
children.push(BULLET([B("Entrate: "), M("FREGOTHC"), R(" (dall'estero), "), M("FREGM"), R(" (da altro comune), "), M("FREGOTHR"), R(" (altro).")]));
children.push(BULLET([B("Uscite: "), M("FDERGOTHC"), R(" (per l'estero), "), M("FDEREGM"), R(" (per altro comune), "), M("FDEROTHR"), R(" (altro).")]));
children.push(BULLET([B("Saldi migratori: "), M("FINTNMIG"), R(" (con l'estero), "), M("FINTRNMIGR"), R(" (interno).")]));
children.push(BULLET([B("La terza porta: "), M("ACQCITIZ"), R(" (acquisizioni di cittadinanza). Più "), M("FIDECTR"), R(", "), M("FSTAT_ADJUST"), R(", "), M("FTOTAL_BAL"), R(" (saldo totale).")]));
children.push(warn([new Paragraph({ children: [B("La trappola del nome OTHC.  "), R("Il suffisso "), M("OTHC"), R(" significa "), B("estero"), R("; il codice nudo significa "), B("altro comune"), R(". Quindi la porta «trampolino» — uscire dall'Italia — è "), M("FDERGOTHC"), R(", "), B("non"), R(" "), M("FDEREGM"), R(" (che è un trasloco interno). Scambiarli falsa in silenzio tutta l'analisi: è la differenza tra «se ne va dall'Italia» e «cambia paese qui dentro».")] })]));
children.push(P([B("Le tre porte d'uscita"), R(" dal conteggio degli stranieri di un comune sono dunque misurate tutte e tre da questo cubo: "), B("emigrazione all'estero"), R(" ("), M("FDERGOTHC"), R("), "), B("naturalizzazione"), R(" ("), M("ACQCITIZ"), R(": diventa italiano ed esce dal conteggio senza muoversi) e "), B("morte"), R(" ("), M("FDEATH"), R("). È lo scheletro contabile del Dossier n. 2.")]));
children.push(P([B("Come l'abbiamo certificato.  "), R("Tutte le identità chiudono a zero falliti, comune per comune: "), M("M+F=T"), R("; "), M("FNATGR=FLBIRTH-FDEATH"), R("; "), M("FINTNMIG=FREGOTHC-FDERGOTHC"), R("; "), M("FINTRNMIGR=FREGM-FDEREGM"), R("; e il saldo totale "), M("FTOTAL_BAL=FDEC_CP-FJAN"), R(" e insieme "), M("=FNATGR+FINTNMIG+FINTRNMIGR+(FREGOTHR-FDEROTHR)+FIDECTR+FSTAT_ADJUST-ACQCITIZ"), R(". Quel "), M("-ACQCITIZ"), R(" è la prova contabile che la naturalizzazione è un'uscita.")]));
children.push(info([new Paragraph({ children: [B("Insidia di controllo.  "), R("Le verifiche vanno fatte filtrando "), M("present_col.notna()"), R(": gli eventi sparsi assenti valgono 0, ma senza il filtro pandas li legge come mancanti e produce falsi positivi.")] })]));
children.push(P([R("In magazzino: tabella "), M("bilancio_stranieri"), R(", "), B("2.773.791 righe"), R(", 7.926 comuni, 2019–2025 — scaricata e montata in questa tornata (cap. 22 per i risultati).")]));

children.push(H2("30.3  POPSTRCIT1 — gli stranieri per cittadinanza"));
children.push(P([R("Cubo comune "), M("29_317_DF_DCIS_POPSTRCIT1_23"), R(". Sei variabili: "), M("FREQ·REF_AREA·DATA_TYPE·SEX·CITIZENSHIP·TIME"), R("; misura "), M("DATA_TYPE=FJAN"), R(" (stock al 1° gennaio); "), M("CITIZENSHIP"), R(" è la "), M("CL_ISO"), R(" — 660 codici-paese col totale "), M("WORLD"), R(". "), B("Niente età"), R(". È il cubo che dà il "), B("paese × comune"), R(": i romeni di Esino per sesso, dato vero comune per comune (~390 righe per comune). È il ponte verso la storia dell'immigrazione al comune (cap. 31), in scarico sulla Fabbrichetta.")]));

children.push(H2("30.4  POPRES1 — popolazione totale per età e stato civile"));
children.push(P([R("Qui la popolazione è "), B("totale"), R(" (italiani + stranieri insieme): nessun taglio per cittadinanza. Tre varianti comunali: "), M("22_289_DF_DCIS_POPRES1_24"), R(" (per età), "), M("_25"), R(" (per stato civile), "), M("_26"), R(" (per età "), I("e"), R(" stato civile insieme — il mostro). Sette variabili: "), M("FREQ·REF_AREA·DATA_TYPE·SEX·AGE·MARITAL_STATUS·TIME"), R("; "), M("DATA_TYPE=JAN"), R(".")]));
children.push(BULLET([M("AGE"), R(" = "), M("CL_ETA1"), R(": "), M("Y0..Y99"), R(", "), M("Y_GE100"), R(", e "), M("TOTAL"), R(" "), B("da escludere"), R(" (sennò raddoppi).")]));
children.push(BULLET([M("MARITAL_STATUS"), R(" = "), M("CL_STATCIV2"), R(": in "), M("_24"), R(" torna collassato a 99=totale; contiene "), M("1·never married"), R(" e gli alias "), M("SIN/SINB·single"), R(" = i celibi.")]));
children.push(P([B("Il peso.  "), R("Esino da sola fa 2.448 righe nella "), M("_24"), R(" → ~6 comuni per lotto → ~1.564 lotti solo per la "), M("_24"), R("; la "), M("_26"), R(" è ~5 volte tanto, migliaia di query. Per questo i "), B("maschi celibi per età al comune"), R(" (la "), M("_26"), R(") sono materiale da "), B("PC di Bardonecchia"), R(", non da telefono (cap. 29). E attenzione: la POPRES1 dà solo la piramide "), B("totale"), R("; gli «italiani per sottrazione» al comune richiederebbero anche gli stranieri-per-età "), I("al comune"), R(", che però abbiamo solo a provincia.")]));

children.push(H2("30.5  FORPOP_1_GC — stranieri per stato civile (ma solo macro-area)"));
children.push(P([R("Cubo "), M("DF_DCSS_FORPOP_1_GC"), R(" («Foreign population by legal marital status – provinces and large cities»), famiglia "), B("DCSS"), R(" (censimento permanente). Nove variabili: "), M("FREQ·REF_AREA·INDICATOR·GENDER·AGE_CLASS·CITIZENSHIP·MARITAL_STATUS·POS_FAM_NUCL·TIME"), R(". "), B("Ha tutto insieme"), R(" — sesso × cittadinanza × stato civile × età — e "), M("MARITAL_STATUS"), R(" contiene "), M("SIN/SINB"), R(" (celibi). "), B("Ma"), R(" "), M("CITIZENSHIP"), R(" è la "), M("CL_CITTADINANZA"), R(": "), B("solo 8 codici macro-area"), R(" ("), M("ITL/FRG/EU27/EXTEU27…"), R("), non per singolo paese.")]));
children.push(BULLET([B("Territori"), R(": le grandi città per codice comune (Roma 058091, Milano 015146, Torino 001272, Napoli 063049); le province come NUTS (Lecco = "), M("ITC43"), R("). Suffissi: "), M("_GC"), R(" = province + grandi città; "), M("_COM"), R(" = comuni.")]));
children.push(warn([new Paragraph({ children: [B("Warning benigno all'avvio.  "), R("Il cubo emette "), M("Could not resolve … Concept=POS_FAM_NUCL / CS_CENSPOP"), R(": manca l'"), I("etichetta"), R(" del concetto, non il dato. È ignorabile.")] })]));
children.push(info([new Paragraph({ children: [B("Il limite strutturale (la scoperta).  "), R("Al comune puoi avere lo "), B("stato civile"), R(" "), I("oppure"), R(" la "), B("cittadinanza"), R(", "), B("mai insieme"), R(". I «maschi celibi per nazionalità» esistono solo per "), B("macro-area"), R(" (UE / extra-UE) con età e stato civile a provincia/grande città; per "), B("singolo paese"), R(" incrociato con lo stato civile "), B("non esistono a nessun livello"), R(".")] })]));

children.push(H2("30.6  POPSTRRES1 (vista web I.Stat) e la lezione dei marginali"));
children.push(P([R("Distinto dai cubi SDMX: questa è la vista web di "), M("dati.istat.it"), R(" ("), M("DCIS_POPSTRRES1"), R(", «Stranieri residenti al 1° gennaio»), scaricabile da chiunque in Excel. Le sue fette sono "), B("marginali"), R(": età (nazionale), paese (nazionale, variante «Cittadinanza»), comune (età = totale). Dimensioni: "), M("ITTER107·TIPO_DATO15·SEXISTAT1·ETA1·TIME"), R(" (+ cittadinanza nella variante per paese).")]));
children.push(warn([new Paragraph({ children: [B("Marginali ≠ congiunto.  "), R("Incrociare questi marginali "), B("non recupera il dato congiunto"), R(": da «paesi nazionali» + «età nazionale» + «totali per comune» non ottieni i romeni trentenni di un comune. Una stima per indipendenza imporrebbe il "), I("mix Italia"), R(" su ogni comune, cancellando proprio la varianza tra comuni che il progetto studia (è l'inferenza ecologica). I congiunti veri esistono già, separati: "), B("paese × comune"), R(" = POPSTRCIT1; "), B("età × comune"), R(" = POPSTRRES1 per età al comune. La tripla paese × età × comune "), B("non è pubblicata"), R(".")] })]));
children.push(info([new Paragraph({ children: [B("Lettura dell'export I.Stat.  "), R("Riga 0 = intestazione XML; seguono righe di metadati; i dati-paese partono da riga 7, con i valori in colonne "), I("sfalsate"), R(" (M/F/T spesso in col. 2/3/4, con la col. 1 vuota). Forzare sempre "), M("pd.to_numeric(errors='coerce')"), R(": le celle arrivano come stringhe.")] })]));
children.push(P([B("La famiglia censuaria DCSS, in breve.  "), R("Per chi cercasse i pezzi mancanti al comune: "), M("DF_DCSS_HCUE_COM_1_COM"), R(" (popolazione × stato civile, comuni, "), I("senza"), R(" cittadinanza); "), M("DF_DCSS_POP_DEMCITMIG_SETA_1"), R(" (residenti per età × sesso × cittadinanza, comuni, "), I("senza"), R(" stato civile — il pezzo che servirebbe per gli «italiani per sottrazione» al comune); "), M("DF_DCSS_POP_DEMCITMIG_TV_4"), R(" (per paese, comuni > 20.000 ab.); "), M("29_348_DF_DCIS_PERMSOGG1_9"), R(" (permessi di soggiorno).")]));

// ---------- 31. LA STORIA DELL'IMMIGRAZIONE RECENTE (v24) ----------
children.push(H1("31.  Come stiamo costruendo la storia dell'immigrazione recente in Italia"));
children.push(P([R("I cubi del cap. 30 sono i mattoni; questo capitolo è il "), B("progetto della casa"), R(": come da quei mattoni nasce una storia, e — più importante — "), B("che tipo di verità"), R(" quella storia può rivendicare. Il filo è l'immigrazione recente in Italia letta "), B("territorio-centricamente"), R(": non il totale nazionale, che mente per media, ma la varianza tra i comuni.")]));

children.push(H2("31.1  Le tre porte"));
children.push(P([R("Uno straniero entra ed esce dal conteggio di un comune attraverso delle porte. Le uscite sono tre: "), B("emigrazione all'estero"), R(", "), B("naturalizzazione"), R(", "), B("morte"), R(". Il bilancio (cap. 30.2) le misura tutte e tre. È lo scheletro contabile della storia: prima di chiedersi "), I("perché"), R(" una comunità cresce o si svuota, si guarda da quale porta entra ed esce.")]));

children.push(H2("31.2  Il sex-ratio come firma e come orologio"));
children.push(P([R("La vista nazionale per cittadinanza, che chiunque può scaricare, al primo sguardo dice 49% maschile: «stabile, in equilibrio, niente da vedere». È una "), B("bugia per compensazione"), R(": quel 49% è la somma di due migrazioni opposte che si annullano. La varianza è il fenomeno — le comunità grandi vanno dal 15% maschile (Georgia) al 96% (Gambia).")]));
children.push(BULLET([B("Polo femminile"), R(" (Georgia, Russia, Ucraina, Moldova, Romania, Perù): est europeo e America latina, l'"), B("economia della cura"), R(" — la badante, la colf, la donna che parte spesso sola e spesso per prima.")]));
children.push(BULLET([B("Polo maschile"), R(" (Gambia, Mali, Senegal, Pakistan, Bangladesh, Egitto): Africa subsahariana e occidentale, subcontinente, Nordafrica, la "), B("migrazione di braccia"), R(" — l'uomo solo e giovane. Gambia e Mali sono quasi solo uomini (M/F oltre 17 a uno): non c'è famiglia, c'è un avamposto.")]));
children.push(BULLET([B("Centro riequilibrato"), R(" (Marocco ~54%, Cina ~50%): comunità "), B("mature"), R(", arrivate in famiglia o ricongiunte nei decenni.")]));
children.push(P([R("Così il rapporto M/F smette di essere solo sesso e diventa un "), B("orologio"), R(": misura "), I("a che punto è"), R(" una migrazione. Più è schiacciata sul maschile estremo, più è fresca e senza radici; più scivola verso il 50/50, più si è «fatta casa». E — punto chiave per il progetto — "), B("in assenza dello stato civile al comune, il sex-ratio è il miglior surrogato dei «maschi single»"), R(": una comunità in età da lavoro al 90% maschile "), I("è"), R(", in pratica, uomini soli. Non lo prova: lo grida.")]));

children.push(H2("31.3  Dalla firma alla struttura: la discesa ai comuni"));
children.push(P([R("Da quassù, dal nazionale, è una catena di «probabilmente»: le rumene "), I("probabilmente"), R(" badanti, "), I("probabilmente"), R(" nei comuni vecchi. La discesa ai ~7.900 comuni "), B("non trasforma la congettura in prova"), R(": trasforma l'"), B("impressione in struttura misurata"), R(". Sovrapponendo la quota femminile rumena alla struttura per età su settemilanovecento territori, la correlazione o c'è — disegnata e camminabile — o non c'è. La congettura diventa un "), B("fatto della mappa"), R(". Resta correlazione (il «perché», la cura, rimane inferenza), ma la geografia smette di essere un'ipotesi.")]));
children.push(P([B("Da dove viene il peso.  "), R("Da due posti. Dal "), B("numero"), R(": settemilanovecento comuni non sono l'aneddoto su tre paesi, sono una regolarità che nessuna media scioglie e nessun contro-esempio scalfisce. E dall'"), B("indirizzo"), R(": l'astrazione prende un nome — ecco Esino, ecco Lipari, ecco i comuni dove la badante dell'Est è l'unica under-50. E pesano "), I("proprio perché"), R(" non le gonfiamo: anche pesanti restano correlazioni, provano il disegno e non il movente — il «trampolino» è una lettura della struttura, non una confessione di chi parte.")]));

children.push(H2("31.4  Il salto: dalle teste ai gesti"));
children.push(P([R("ISTAT conta le "), B("teste"), R(": chi c'è, dove, di che età, sesso, cittadinanza. Struttura. Ma è muto su cosa quelle persone "), I("fanno"), R(" — ed è lì che abitano i «perché». Il salto verso altre fonti non è «ISTAT fatto meglio»: è un "), B("altro tipo di sguardo"), R(", che non conta teste ma registra "), B("gesti"), R(".")]));
children.push(BULLET([B("INPS"), R(": le iscrizioni al lavoro domestico — non più «probabilmente badanti», ma quasi la misura diretta.")]));
children.push(BULLET([B("Registro delle imprese"), R(": chi ha aperto bottega — il titolare d'impresa è il segnale di radicamento, la «casa».")]));
children.push(BULLET([B("Permessi di soggiorno per motivo"), R(" (lavoro / asilo / famiglia): il meccanismo del trampolino senza doverlo inferire dal sex-ratio.")]));
children.push(P([R("È il passaggio dalla "), B("firma"), R(" alla "), B("funzione"), R(": da «chi e dove» a «che cosa fanno». E quando due fonti raccolte da istituzioni diverse, per scopi diversi, con metodi diversi, indicano la "), B("stessa"), R(" struttura — ISTAT dice «donne dell'Est nei comuni vecchi», l'INPS dice «lavoro domestico, stesse nazionalità, stessi territori» — la conclusione fa un salto di solidità che nessuna vista singola può dare. È la "), B("convergenza"), R(": la cosa più robusta che questo tipo di evidenza sappia produrre.")]));

children.push(H2("31.5  La sequenza e il limite"));
children.push(P([B("L'ordine non è casuale.  "), R("Prima il dettaglio comunale "), B("ISTAT"), R(" (lo scheletro: il sistema di coordinate su cui si appende tutto), "), B("poi"), R(" il salto alle altre fonti (la carne). Senza scheletro la carne non sta in piedi. Per questo POPSTRCIT1 al comune — in scarico adesso — non è un passo come gli altri: è la "), B("testa di ponte"), R(" da cui parte il salto.")]));
children.push(P([B("E due limiti, da dire ad alta voce.  "), R("Primo: anche la fonte più diretta ha la sua zona buia — l'INPS vede le badanti "), I("registrate"), R(", e il sommerso (enorme, in quel settore) è invisibile, proprio dove il fenomeno si nasconde. È misura con un'ombra, non certezza assoluta. Secondo, più duro: la difficoltà non sarà "), I("prendere"), R(" i dati, sarà "), B("cucirli"), R(" — residente (ISTAT), soggiornante (Interno), lavoratore iscritto (INPS), titolare d'impresa (Camere) sono quattro universi su quattro chiavi territoriali diverse (su NUTS-contro-ITTER107 abbiamo già sanguinato), e parecchi si fermano alla provincia.")]));
children.push(info([new Paragraph({ children: [B("La spina dorsale del capitolo.  "), R("«Correlazioni, non prove». La discesa ai comuni rende le correlazioni "), B("pesanti"), R(" — geografiche, nominative, irriducibili alla media — ma "), B("correlazioni restano"), R(". È questa misura nel rivendicare che le rende affidabili.")] })]));

// ---------- 32. GLI EXCEL DEL CSD (v25) ----------
children.push(H1("32.  Gli Excel del CSD \u2014 standard di produzione e navigazione"));
children.push(P([R("Ogni tavola dati che usciamo dal magazzino diventa un workbook Excel con "), B("almeno tre fogli"), R(". Due sono sempre presenti: la "), B("lista lunga"), R(" (per pivot) e il foglio "), B("Note"), R(". Le "), B("viste larghe"), R(" (da guardare) sono "), B("almeno una"), R(", e tante quante i livelli geografici disponibili nel dataset: se i dati sono a piramide sul territorio, servono sempre i fogli "), B("Regioni"), R(", "), B("Province"), R(" e "), B("Comuni"), R(" \u2014 ovviamente solo quelli che esistono nel dato. Questo capitolo fissa lo standard: come si chiama ogni foglio, come \u00E8 fatto, perch\u00E9 \u00E8 fatto cos\u00EC, e cosa va sempre scritto in chiaro.")]));

children.push(H2("32.1  Perch\u00E9 almeno tre fogli, e i fogli per livello territoriale"));
children.push(P([R("Un Excel demografico serve a fare due cose incompatibili con un\u2019unica struttura: "), B("guardare"), R(" (capire d\u2019un colpo come va un territorio nel tempo) e "), B("analizzare"), R(" (pivot, filtri, calcoli derivati). La vista larga \u2014 anni in colonne, M/F/T affiancati \u2014 \u00E8 ottima da guardare ma impossibile da pivottare. La tavola lunga \u2014 un record per riga \u2014 \u00E8 perfetta per pivot ma illeggibile a occhio. Soluzione: le due forme "), I("coesistono"), R(", pi\u00F9 un foglio di metadati che spiega cosa \u00E8 stato tagliato e perch\u00E9.")]));
children.push(info([new Paragraph({ children: [B("La regola d\u2019oro.  "), R("Ogni taglio va dichiarato. Se una variabile esiste nel magazzino ma non \u00E8 nel foglio Excel, il foglio Note deve dirlo: quale variabile, quale codice ISTAT, perch\u00E9 \u00E8 stata esclusa. Chi apre il file due anni dopo \u2014 incluso Merry \u2014 pu\u00F2 risalire alla scelta senza riaprire il codice.")] })]));
children.push(P([B("Una vista per livello territoriale.  "), R("Quando il dato \u00e8 a piramide sul territorio, lo standard CSD prevede "), B("tre fogli Vista distinti"), R(": "), B("Regioni"), R(" (una riga per regione\u00d7variabile), "), B("Province"), R(" (una riga per provincia\u00d7variabile), "), B("Comuni"), R(" (una riga per comune\u00d7variabile). Ciascuno con la stessa struttura larga. Ordine: dal pi\u00f9 aggregato al pi\u00f9 granulare. La lista lunga e il foglio Note restano invece "), B("unici"), R(": la lunga contiene tutti i livelli insieme e da l\u00ec si pivota su qualunque livello.")]));
children.push(warn([new Paragraph({ children: [B("\u26a0  Il foglio mancante \u00e8 un errore, non una scelta.  "), R("Anche quando il cubo scarica solo i comuni (come TV_3), le viste Regioni e Province si "), B("derivano per aggregazione"), R(": si sommano i valori dei comuni raggruppando per regione e per provincia. Non si rinuncia ai tre fogli solo perch\u00e9 il dato grezzo \u00e8 comunale: pandas li calcola in una riga con groupby. Un workbook con un solo foglio Comuni per dati comunali \u00e8 "), I("non conforme"), R(" allo standard CSD.")] })]));

children.push(H2("32.2  Foglio 1: Vista (largo, per guardare)"));
children.push(P([B("Struttura header \u2014 tre righe.  "), R("Riga 1: titolo merged su tutte le colonne, sfondo blu scuro (#1F3864), testo bianco. Il titolo include: nome del dataset, fonte, anni coperti, e la legenda di qualsiasi simbolo speciale (es. \u2605 = porte demografiche). Riga 2: etichette delle colonne dimensione (merged anche sulla riga 3) e le etichette degli anni, ciascun anno merged sulle tre sotto-colonne M/F/T. Riga 3: M / F / T ripetuti per ogni anno. Dati da riga 4.")]));
children.push(P([B("Struttura righe.  "), R("Una riga per ogni combinazione di entit\u00E0 analitica principale \u00D7 variabile. Esempio per il bilancio stranieri: una riga per ogni coppia (comune, evento). Le colonne valore sono gli anni \u00D7 i tre sessi, affiancati: per ogni anno, prima M, poi F, poi T.")]));
children.push(P([B("Colonne di contesto nel foglio Comuni.  "), R("Quando la Vista \u00e8 a livello comunale, le colonne dimensione includono anche "), B("Regione"), R(" e "), B("Provincia"), R(" di appartenenza. Non sono variabili analitiche: sono coordinate geografiche della riga. Ordine consigliato: Cod.Comune \u00b7 Comune \u00b7 Regione \u00b7 Provincia \u00b7 variabili analitiche \u00b7 anni\u00d7sessi.")]));
children.push(P([B("Colori degli header.  "), R("Colonne dimensione (codice, nome, evento, ...): sfondo blu scuro #003366, testo bianco. Colonne valore standard: blu medio #336699, testo bianco. Colonne speciali (le tre porte demografiche, o qualsiasi variabile di rilievo): rosso scuro #7B241C, testo bianco, marcatore \u2605 nel nome. Testo sempre bianco su tutti gli header.")]));
children.push(P([B("Navigazione \u2014 niente freeze panes.  "), R("Auto-filter sulla riga 3 per filtrare per entit\u00e0 o variabile. Larghezze suggerite: 10 per codice, 28 per nome, 20 per variabile, 8-9 per ogni colonna anno. "), B("Non si mette il freeze panes"), R(": d\u00e0 fastidio e va tolto a mano ogni volta. Le viste restano scorrevoli liberamente.")]));
children.push(info([new Paragraph({ children: [B("\u26a0  Gli umani vogliono l'anno scritto sopra le terzine.  "), R("La fila di M/F/T ripetuta sette volte \u00e8 illeggibile per un occhio umano: senza l'anno marcato sopra ogni terzina, Merry non sa se la colonna che guarda \u00e8 il 2018 o il 2024. La riga 2 deve quindi portare "), B("l'etichetta dell'anno merged sulle tre sotto-colonne M/F/T"), R(" (2018 sopra le prime tre, 2019 sopra le successive tre, e cos\u00ec via). Questo \u00e8 il default CSD per le viste larghe destinate a Merry. \u00c8 il punto su cui ci siamo allineati a giugno 2026: una vista larga senza intestazioni d'anno \u00e8 tecnicamente corretta ma "), I("inservibile da guardare"), R(" \u2014 e le viste larghe esistono apposta per essere guardate.")] })]));
children.push(P([B("Soffitto 300k righe.  "), R("La Vista non supera 300.000 righe. Se il prodotto cartesiano entit\u00E0 \u00D7 variabili lo eccede, si taglia: si privilegiano le variabili analiticamente pi\u00F9 ricche e si documentano i tagli nel foglio Note.")]));

children.push(H2("32.3  Foglio 2: Bilancio / Dati (lungo, per analizzare)"));
children.push(P([R("Flat table con una riga per ogni combinazione completa di dimensioni (es. comune \u00D7 anno \u00D7 sesso). Le variabili sono in colonne. Header su riga 1 sola, auto-filter su riga 1, "), B("niente freeze panes"), R(". Stessi colori della Vista. Da qui si costruisce qualsiasi pivot con Excel nativo o con pandas.")]));
children.push(P([R("Questo foglio "), B("non"), R(" ha soffitto righe: pu\u00F2 arrivare a 165k o pi\u00F9. Il soffitto 300k vale solo per la Vista.")]));

children.push(H2("32.4  Foglio 3: Note (legenda e caveat)"));
children.push(P([R("Contiene almeno: fonte ISTAT (codice dataflow, variante), anni coperti, numero comuni e righe del workbook, data di generazione. Poi due tabelle: "), B("variabili incluse"), R(" (colonna Excel, codice ISTAT, descrizione) e "), B("variabili escluse"), R(" (codice ISTAT, motivo del taglio). Qualsiasi altro caveat rilevante (es. \u00ABsaldo_totale assente per ~14% dei comuni\u00BB).")]));
children.push(info([new Paragraph({ children: [B("Il foglio Note \u00E8 la memoria del workbook.  "), R("Chiunque apra il file \u2014 incluso Claude in un thread futuro \u2014 deve poter capire, senza accedere al codice Python n\u00E9 al magazzino SQLite, cosa c\u2019\u00E8, cosa manca e perch\u00E9.")] })]));

children.push(H2("32.5  Ordine dei fogli e nome dei file"));
children.push(P([R("Ordine: le "), B("viste larghe per livello"), R(" prima (Regioni \u2192 Province \u2192 Comuni, dal pi\u00F9 aggregato al pi\u00F9 fine, solo i livelli presenti), poi la "), B("lista lunga"), R(" per pivot, infine il foglio "), B("Note"), R(". Le viste vengono per prime perch\u00E9 sono quelle che si aprono per \u00ABguardare\u00BB. Il nome del file: "), M("nome_dataset.xlsx"), R(", minuscolo, underscore come separatori: "), M("bilancio_stranieri.xlsx"), R(", "), M("cittadinanza_stranieri.xlsx"), R(", "), M("eta_popolazione.xlsx"), R(".")]));

children.push(H2("32.6  Sequenza di costruzione"));
children.push(BULLET([R("Query SQL pivot per la Vista (anni\u00D7sessi in colonne) \u2014 max 300k righe.")]));
children.push(BULLET([R("Query SQL pivot per il Bilancio (flat table, tutti gli anni e sessi come righe).")]));
children.push(BULLET([R("wb = Workbook(); wb.remove(wb.active) \u2014 parte da workbook vuoto.")]));
children.push(BULLET([R("create_sheet nelle viste per livello presenti (\u00ABRegioni\u00BB, \u00ABProvince\u00BB, \u00ABComuni\u00BB \u2014 solo quelli che esistono) \u2192 \u00ABLungo\u00BB (lista per pivot) \u2192 \u00ABNote\u00BB.")]));
children.push(BULLET([R("Vista: header 3 righe (titolo merged, anni merged, M/F/T). auto_filter riga 3. NIENTE freeze panes.")]));
children.push(BULLET([R("Bilancio: header 1 riga colorata per categoria. auto_filter riga 1. NIENTE freeze panes.")]));
children.push(BULLET([R("Note: fonte, anni, comuni, righe, tabelle inclusi/esclusi, data generazione.")]));
children.push(BULLET([R("Dati scritti con ws.append() su array numpy \u2014 mai cell write individuale su > 10k righe.")]));
children.push(BULLET([R("Su file con > 500k righe usare "), B("xlsxwriter"), R(" (streaming su disco) invece di openpyxl (tiene tutto in RAM \u2014 OOM su questa sandbox). xlsxwriter supporta merge, autofilter, formati: \u00e8 il motore giusto per i file grandi del CSD.")]));

children.push(H2("32.7  Regola di leggibilit\u00e0: tutti i codici risolti in nomi"));
children.push(P([R("Ogni colonna che contiene un codice \u2014 ISTAT, ISO, interno \u2014 deve avere la colonna-nome affiancata. Un Excel del CSD "), B("non lascia codici nudi"), R(": chi apre il file deve poter leggere senza dizionari esterni. Il codice non sparisce: resta come colonna separata (serve ai VLOOKUP e ai JOIN), ma il nome \u00e8 sempre presente.")]));
children.push(table([
  ["Codice", "Nome da risolvere", "Fonte del dizionario"],
  ["Cod.Comune (6 cifre)", "Comune (nome per esteso)", "tabella \u2018popolazione\u2019 del Magazzino \u2014 colonna \u2018nome\u2019"],
  ["Cod.Regione (NUTS IT*)", "Regione (nome per esteso)", "tabella \u2018popolazione\u2019 del Magazzino"],
  ["Cod.Provincia (NUTS IT***)", "Provincia (nome per esteso)", "tabella \u2018popolazione\u2019 del Magazzino"],
  ["Cod.Paese (ISO alpha-2)", "Paese (nome in italiano o inglese)", "dizionario ISO 3166-1 \u2014 file Country_code_and_name.xlsx"],
  ["Cod.Citt. ISTAT (es. FRGAPO)", "Descrizione (es. \u2018Stranieri + apolidi\u2019)", "codelist ISTAT o nota manuale"],
], [2800, 2800, 4370]));
children.push(SP());
children.push(warn([new Paragraph({ children: [B("\u26A0  Namibia e None.  "), R("Quando si carica un dizionario codice\u2192nome con pandas, usare sempre "), M("keep_default_na=False, na_values=[]"), R(": il codice paese della Namibia \u00e8 "), M("NA"), R(" e il comune di Torino ha codice "), M("001168"), R(" di nome \u2018None\u2019 \u2014 senza questo parametro pandas li legge entrambi come NaN e silenziosamente cancella la riga dal dizionario.")] })]));
children.push(P([B("Nota tecnica \u2014 Regione e Provincia dal Magazzino.  "), R("Per i dataset a livello comunale, le colonne Regione e Provincia si ricavano dalla tabella "), M("popolazione"), R(" (o "), M("territori_anagrafica"), R(" se disponibile) con un dizionario "), M("codice_comune \u2192 (nome_regione, nome_provincia)"), R(". La tabella "), M("popolazione"), R(" ha gi\u00e0 le colonne "), M("codice \u00b7 nome \u00b7 livello"), R(": per risalire a regione e provincia di un comune servono i livelli padre nella catena territoriale ISTAT (il ponte). In assenza del ponte completo, usare la tabella "), M("bilancio_stranieri"), R(" che espone la gerarchia piena tramite le colonne "), M("cod_reg \u00b7 nome_reg \u00b7 cod_prov \u00b7 nome_prov"), R(".")]));

// ---------- APPENDICE ----------
children.push(H1("Appendice \u2014 gli script di lavoro"));
children.push(P([R("Gli script che popolano e usano il magazzino (le 4 fasi sono nel cap. 12). Girano su Carnets, con i dati "), B("scritti dentro il codice"), R(" \u2014 mai "), M("input()"), R(". Vanno lanciati uno alla volta, rispettando i 5/minuto.")]));

children.push(H2("S1 \u2014 Fetch popolazione corrente (2019\u2192)"));
children.push(P([R("Scarica gli stock dal dataflow moderno e salva la ricevuta. Imposta "), M("DA_ANNO/A_ANNO"), R(".")]));
children.push(codeBox(S1_FETCH));
children.push(H2("S2 \u2014 Fetch popolazione storica, a bocconi (2007\u20132018)"));
children.push(P([R("Il dataflow storico, in blocchi da tre anni (il server crolla sulle risposte grandi). I bocconi gi\u00E0 presi vengono saltati.")]));
children.push(codeBox(S2_STORICO));
children.push(H2("S3 \u2014 Ricostruzione consolidante (il magazzino)"));
children.push(P([R("Fonde tutte le ricevute in un magazzino unico, gestendo schemi misti. Idempotente.")]));
children.push(codeBox(S3_RICOSTR));
children.push(H2("S4 \u2014 Anagrafica dei territori + viste alberate"));
children.push(P([R("Schema a stella dei territori (con i padri) e viste larghe per Excel. Legge il magazzino, non riscarica.")]));
children.push(codeBox(S4_ANAGRAFICA));
children.push(H2("S5 \u2014 Fetch nati (LBIRTH), storico + moderno"));
children.push(P([R("I nati dai due bilanci, con i due ordini di variabili, giuntati a 2018|2019.")]));
children.push(codeBox(S5_NATI));
children.push(H2("S6 \u2014 Integrazione: la tabella unica \u00ABfatti\u00BB"));
children.push(P([R("Unisce popolazione e nati in una sola tabella lunga con la colonna "), M("misura"), R(".")]));
children.push(codeBox(S6_INTEGRA));
children.push(H2("S7 \u2014 Piramide: fasce d\u2019et\u00E0 dagli anni singoli"));
children.push(P([R("Compone le fasce sommando gli anni singoli (escluso "), M("TOTAL"), R("). Esempio: Nuoro, anziani e fertili femminili.")]));
children.push(codeBox(S7_ETA));
children.push(H2("S8 \u2014 Convergenza: TFR italiane vs straniere"));
children.push(P([R("Il TFR per cittadinanza, come somma dei tassi ASFR diviso mille.")]));
children.push(codeBox(S8_CONV));

// ---------- APPENDICE: PASSAGGIO TRA THREAD ----------
children.push(H1("Appendice \u2014 Passaggio di documenti/materiale tra thread"));
children.push(P([R("Quando un thread diventa troppo lungo se ne apre uno nuovo, e la copia di lavoro nella sandbox viene azzerata. La rinascita è affidata a "), B("tre zip versionati"), R(" — descritti qui sotto in «Confezionamento di rinascita» — che l'autore custodisce e consegna in sequenza all'apertura del nuovo thread. "), B("I «files» del Progetto non si usano"), R(": è una decisione presa. Tutto ciò che serve a ripartire sta nei tre zip, e nient'altro.")]));
children.push(P([R("Due cose restano "), B("fuori dagli zip"), R(", perché non servono a Claude per ripartire: i "), M(".docx"), R(" (Manuale e Schedario) "), B("restano all'autore"), R(" — se serve il Manuale lo si rigenera dal "), M(".js"), R(". E il "), M("istat.db"), R(" stesso "), B("non viaggia"), R(": è binario, non c'è modo di consegnarlo, e tra un thread e l'altro "), B("si rigenera dalle ricevute"), R(" (vedi «Protocollo di rinascita»).")]));
children.push(P([B("Versioni gemelle.  "), R("Questo Manuale e il KB condividono la "), B("stessa versione"), R(" e avanzano "), B("insieme"), R(": non se ne aggiorna uno senza l\u2019altro. Se ci si trova un KB e un Manuale con numeri diversi, qualcosa \u00E8 rimasto indietro.")]));

children.push(H2("Inventario di rinascita e controllo all\u2019apertura"));
children.push(info([new Paragraph({ children: [B("Obbligo di consegna (di Claude).  "), R("Le ricevute nascono e muoiono nella sandbox; l\u2019autore non le vede se Claude non gliele d\u00E0. Perci\u00F2: ogni volta che "), M("istat.db"), R(" cambia, nello stesso messaggio Claude rigenera le ricevute e le consegna "), B("non sollecitate"), R(", dicendo per ciascuna nome esatto, contenuto e dove metterla \u2014 in "), B("CSV"), R(" per archiviare e in "), B("XLS"), R(" per consultare. Le ricevute sono di Claude da generare, dell\u2019autore da custodire.")] })]));
children.push(P([R("All\u2019apertura di un thread nuovo, prima di fidarsi, Claude confronta i file consegnati con l\u2019inventario reale qui sotto \u2014 "), B("nomi esatti, righe attese, arco"), R(". Il "), B("magazzino"), R(" sono le tre ricevute pi\u00F9 l\u2019anagrafica; lo "), B("sgabuzzino"), R(" (se serve) sono nati, paese, dizionario dei paesi e il TFR "), M("Fecondita_.xlsx"), R(" (dell\u2019autore).")]));
children.push(P([R("Due trappole viste sul campo: i file caricati arrivano in "), M("/mnt/user-data/uploads"), R(", "), B("non"), R(" nella cartella di lavoro; e il controllo confronta il "), B("contenuto"), R(" (righe e arco), non un nome immaginato. Un mismatch \u00E8 "), B("bloccante"), R(": meglio fermarsi che ricostruire un magazzino monco. Dopo la ricostruzione, le firme d\u2019integrit\u00E0: Lecco 2026 totale = 334.211, M+F=T ovunque, somma province = Italia.")]));
const REBIRTH_CHECK = `
import pandas as pd, os
UP = "/mnt/user-data/uploads"          # i file caricati arrivano QUI, non nella cartella di lavoro
ATTESI = {
  # --- magazzino (ricostruisce istat.db) ---
  "pavimento_RICPOPRES2011_2001-2018.csv": dict(righe=434754, arco=(2001, 2018)),
  "pavimento_POPRES1_2019-2026.csv":       dict(righe=193107, arco=(2019, 2026)),
  "pavimento_FLUSSI_2019-2025.csv":        dict(righe=377866, arco=(2019, 2025)),
  "territori_anagrafica.csv":              dict(righe=137),
  # --- sgabuzzino (mattoni provinciali, se servono) ---
  "pavimento_NATI_1999-2024.csv":          dict(righe=21300,  arco=(1999, 2024)),
  "pavimento_NATI_NAZ_1999-2024.csv":      dict(righe=163470, arco=(1999, 2024)),
  "paesi_cittadinanza.csv":                dict(righe=660),
}
ok = True
for f, exp in ATTESI.items():
    p = os.path.join(UP, f)
    if not os.path.exists(p):
        print("MANCA:", f); ok = False; continue
    d = pd.read_csv(p, dtype=str); n = len(d); good = (n == exp["righe"])
    msg = ("OK " if good else "NO ") + f + ": " + str(n) + " righe (atteso " + str(exp["righe"]) + ")"
    if "arco" in exp and "anno" in d.columns:
        a = (int(d.anno.astype(int).min()), int(d.anno.astype(int).max()))
        good = good and (a == tuple(exp["arco"])); msg += " | arco " + str(a[0]) + "-" + str(a[1])
    print(msg); ok = ok and good
print("ESITO:", "tutto coincide, rigenero il magazzino" if ok else "MISMATCH BLOCCANTE: fermarsi, file mancante o versione diversa")
`;
children.push(codeBox(REBIRTH_CHECK));

children.push(H2("Confezionamento di rinascita: i tre zip"));
children.push(P([R("La rinascita viaggia in "), B("tre zip versionati"), R(", che l\u2019autore custodisce e Claude rigenera. Contengono "), B("solo ci\u00F2 che serve a Claude"), R(" per ripartire (niente "), M(".docx"), R(", che \u00E8 per l\u2019autore). All\u2019apertura l\u2019autore consegna lo zip 1; Claude lavora e "), B("chiede"), R(" lo zip 2, poi il 3.")]));
children.push(BULLET([B("zip x Claude n.1"), R(" \u2014 testa: "), M("kb_istat_vNN.md"), R(" + "), M("genera_manuale_vNN.js"), R(".")]));
children.push(BULLET([B("zip x Claude n.2"), R(" \u2014 dato (Magazzino + Ripostiglio): le tre ricevute "), M("pavimento_RICPOPRES2011_2001-2018.csv"), R(", "), M("pavimento_POPRES1_2019-2026.csv"), R(", "), M("pavimento_FLUSSI_2019-2025.csv"), R("; i due dizionari che servono al rebuild dei nomi "), M("territori_anagrafica.csv"), R(" e "), M("territori_istat.csv"), R("; e il Ripostiglio "), M("pavimento_NATI_1999-2024.csv"), R(", "), M("pavimento_NATI_NAZ_1999-2024.csv"), R(", "), M("paesi_cittadinanza.csv"), R(", "), M("Fecondita_.xlsx"), R(".")]));
children.push(BULLET([B("zip x Claude n.3"), R(" \u2014 il resto (metodo/analisi, non serve al rebuild): "), M("genera_schedario_v8.js"), R(", "), M("catalogo_dataflow.csv"), R(", e i quattro "), M("codelist_*.csv"), R(".")]));
children.push(info([new Paragraph({ children: [B("Regola di versionamento (vitale).  "), R("L\u2019autore vede solo "), B("nome + versione dello zip"), R(" (es. \u00ABzip x Claude n.1, v01\u00BB); delle versioni interne (KB, Manuale\u2026) si occupa Claude. Quando cambia il "), B("contenuto"), R(" di uno zip, Claude rigenera "), B("quello"), R(", ne alza la versione (v02\u2026), lo riconsegna e avvisa "), B("chiaramente"), R(": \u00ABsostituisci e cancella il precedente\u00BB. Custodire gli zip aggiornati \u00E8 dell\u2019autore; fare \u00ABtutto il giro\u00BB quando si tocca qualcosa \u00E8 di Claude.")] })]));
children.push(P([B("Test di operativit\u00E0 (a fine ripartenza).  "), R("Dopo aver aperto lo zip 2 e ricostruito "), M("istat.db"), R(", Claude verifica: (1) "), B("inventario"), R(" \u2014 i file attesi ci sono, righe e arco coincidono (script della sezione precedente); (2) "), B("firme d\u2019integrit\u00E0"), R(" \u2014 Lecco 2026 totale = 334.211, M+F = T, somma province = Italia. Se tutto torna, il thread \u00E8 operativo; un mismatch \u00E8 bloccante.")]));
const OPER_SIGN = `
import sqlite3, pandas as pd
con = sqlite3.connect("istat.db")
lecco = pd.read_sql("SELECT valore FROM popolazione WHERE codice='ITC43' AND anno=2026 AND sesso='totale'", con).valore
print("Lecco 2026 =", int(lecco.iloc[0]), "(atteso 334211)")
mf = pd.read_sql("SELECT SUM(CASE WHEN sesso='maschi'  THEN valore END) m, "
                 "SUM(CASE WHEN sesso='femmine' THEN valore END) f, "
                 "SUM(CASE WHEN sesso='totale'  THEN valore END) t "
                 "FROM popolazione WHERE anno=2024", con)
print("2024  M+F == T :", int(mf.m.iloc[0]) + int(mf.f.iloc[0]) == int(mf.t.iloc[0]))
prov = pd.read_sql("SELECT SUM(valore) s FROM popolazione WHERE livello='provincia' AND anno=2024 AND sesso='totale'", con).s.iloc[0]
ita  = pd.read_sql("SELECT valore FROM popolazione WHERE codice='IT' AND anno=2024 AND sesso='totale'", con).valore.iloc[0]
print("2024  somma province == Italia :", int(prov) == int(ita))
con.close()
`;
children.push(codeBox(OPER_SIGN));

// ===== Collaudo di risveglio: le quattro fasi (sigillate, provate) =====
const FASE1_SRC = `
import os, glob, pandas as pd
DIR = "rinascita"   # la cartella dove ho scompattato i tre zip
ok = True
def ne(p): return os.path.exists(p) and os.path.getsize(p) > 0
print("[testa]")
for lab, pat in [("KB","kb_istat_*.md"),("Manuale JS","genera_manuale_*.js"),("Schedario JS","genera_schedario_*.js")]:
    f = glob.glob(os.path.join(DIR, pat)); g = bool(f) and ne(f[0]); ok &= g
    print(("OK " if g else "NO ") + lab + ": " + (os.path.basename(f[0]) if f else "MANCA"))
print("[dato + dizionari]")
ATT = {"pavimento_RICPOPRES2011_2001-2018.csv":(434754,(2001,2018)),
 "pavimento_POPRES1_2019-2026.csv":(193107,(2019,2026)),
 "pavimento_FLUSSI_2019-2025.csv":(377866,(2019,2025)),
 "territori_anagrafica.csv":(137,None),
 "pavimento_NATI_1999-2024.csv":(21300,(1999,2024)),
 "pavimento_NATI_NAZ_1999-2024.csv":(163470,(1999,2024)),
 "paesi_cittadinanza.csv":(660,None),
 "catalogo_dataflow.csv":(4871,None),
 "codelist_eta.csv":(343,None),"codelist_sex.csv":(8,None),
 "codelist_statciv.csv":(50,None),"codelist_tipo_dato.csv":(471,None)}
for f,(rr,arc) in ATT.items():
    p = os.path.join(DIR, f)
    if not ne(p): print("NO  MANCA " + f); ok = False; continue
    d = pd.read_csv(p, dtype=str); n = len(d); g = (n == rr); s = ("OK " if g else "NO ") + f + ": " + str(n) + " (atteso " + str(rr) + ")"
    if arc and "anno" in d.columns:
        a = (int(d.anno.astype(int).min()), int(d.anno.astype(int).max())); g &= (a == arc); s += " arco " + str(a[0]) + "-" + str(a[1])
    print(s); ok &= g
for f in ["territori_istat.csv","Fecondita_.xlsx"]:
    e = ne(os.path.join(DIR, f)); print(("OK " if e else "NO ") + f + ": " + ("presente" if e else "MANCA")); ok &= e
print("FASE 1:", "OK" if ok else "FALLITA")
`;
const FASE2_SRC = `
import pandas as pd, sqlite3, os
DIR = "rinascita"
RD = dict(dtype=str, keep_default_na=False, na_values=[])   # FIX None: "None" resta una stringa
ter = pd.read_csv(os.path.join(DIR,"territori_istat.csv"), **RD); cc, nn = "codice", "nome_it"
ana = pd.read_csv(os.path.join(DIR,"territori_anagrafica.csv"), **RD)
tn = dict(zip(ter[cc], ter[nn])); an = dict(zip(ana.codice, ana.nome)); al = dict(zip(ana.codice, ana.livello))
def nome(c):
    v = tn.get(c)
    return v if isinstance(v, str) and v.strip() else an.get(c)
def refine(c, l): return l if l in ("comune","provincia") else al.get(c, "altro")
def stk(f, fonte):
    d = pd.read_csv(os.path.join(DIR, f), dtype={"cod":str}); d["fonte"] = fonte
    d["sesso"] = d["sex"].astype(int).map({1:"maschi",2:"femmine",9:"totale"})
    d["livello"] = [refine(c,l) for c,l in zip(d.cod, d.livello)]; d["nome"] = d.cod.map(nome)
    d["codice"] = d.cod; d["valore"] = d.valore.astype(float).round().astype(int); d["anno"] = d.anno.astype(int)
    return d[["codice","nome","livello","anno","sesso","valore","fonte"]]
pop = pd.concat([stk("pavimento_RICPOPRES2011_2001-2018.csv","RICPOPRES2011"),
                 stk("pavimento_POPRES1_2019-2026.csv","POPRES1")], ignore_index=True)
fl = pd.read_csv(os.path.join(DIR,"pavimento_FLUSSI_2019-2025.csv"), dtype={"cod":str}); fl["fonte"] = "POPORESBIL1"
fl["livello"] = [refine(c,l) for c,l in zip(fl.cod, fl.livello)]; fl["nome"] = fl.cod.map(nome)
fl["codice"] = fl.cod; fl["valore"] = fl.valore.astype(float).round().astype(int); fl["anno"] = fl.anno.astype(int)
fl = fl[["codice","nome","livello","anno","tipo","valore","fonte"]]
con = sqlite3.connect(os.path.join(DIR,"istat.db"))
pop.to_sql("popolazione", con, index=False, if_exists="replace")
fl.to_sql("flussi", con, index=False, if_exists="replace")
ana.to_sql("territori_anagrafica", con, index=False, if_exists="replace")
ok = True
def chk(lab, v, a):
    global ok; g = (v == a); ok &= g; print(("OK " if g else "NO ") + lab + ": " + str(v) + " (atteso " + str(a) + ")")
chk("popolazione righe", len(pop), 627861); chk("flussi righe", len(fl), 377866)
chk("None 001168 salvato", nome("001168"), "None")
chk("comuni senza nome", pop[(pop.livello=='comune') & (pop.nome.isna())].codice.nunique(), 0)
chk("ultimo anno RICPOPRES2011", int(pop[pop.fonte=='RICPOPRES2011'].anno.max()), 2018)
chk("primo anno POPRES1", int(pop[pop.fonte=='POPRES1'].anno.min()), 2019)
chk("Lecco 2026", int(pd.read_sql("SELECT valore FROM popolazione WHERE codice='ITC43' AND anno=2026 AND sesso='totale'", con).valore.iloc[0]), 334211)
mf = pd.read_sql("SELECT SUM(CASE WHEN sesso='maschi' THEN valore END) m, SUM(CASE WHEN sesso='femmine' THEN valore END) f, SUM(CASE WHEN sesso='totale' THEN valore END) t FROM popolazione WHERE anno=2024", con)
g = int(mf.m.iloc[0])+int(mf.f.iloc[0]) == int(mf.t.iloc[0]); ok &= g; print(("OK " if g else "NO ") + "2024 M+F==T")
prov = int(pd.read_sql("SELECT SUM(valore) s FROM popolazione WHERE livello='provincia' AND anno=2024 AND sesso='totale'", con).s.iloc[0]); ita = int(pd.read_sql("SELECT valore FROM popolazione WHERE codice='IT' AND anno=2024 AND sesso='totale'", con).valore.iloc[0])
g = (prov == ita); ok &= g; print(("OK " if g else "NO ") + "2024 province==Italia (" + str(prov) + " vs " + str(ita) + ")")
con.close()
print("FASE 2:", "OK" if ok else "FALLITA")
`;
const FASE34_SRC = `
import sdmx, time
istat = sdmx.Client("ISTAT", timeout=120)
t0 = time.time()
# cubo comunale popolazione 22_289_DF_DCIS_POPRES1_24
# Esino Lario (097035), totale sessi, eta' totale, tutti gli stati civili
r = istat.data("22_289_DF_DCIS_POPRES1_24", key="A.097035.JAN.9.TOTAL.99",
               params={"startPeriod": "2024", "endPeriod": "2024"})
d = sdmx.to_pandas(r).reset_index(); d["TIME_PERIOD"] = d["TIME_PERIOD"].astype(int)
print(d[["TIME_PERIOD", "value"]].to_string(index=False))
print(f"  ({time.time()-t0:.1f}s)")
`;
children.push(H2("Collaudo di risveglio: le quattro fasi"));
children.push(P([R("A ogni risveglio, prima di dire \u00ABoperativo\u00BB, si gira il collaudo: "), B("quattro fasi separate"), R(", ognuna su un argomento, lanciabile da sola, con l\u2019output atteso accanto. "), B("Non"), R(" un test unico \u2014 si romperebbe a ogni modifica e proverebbe sempre lo stesso scenario verde; qui si fanno "), I("balzi al buio, mai nelle stesse condizioni"), R(". Se cambia un pezzo, si ritocca solo la fase toccata.")]));
children.push(P([B("Fasi 1\u20132"), R(": nella sandbox, sui file dei tre zip scompattati in una cartella "), M("DIR"), R(". "), B("Fasi 3\u20134"), R(": "), B("sul reale"), R(" \u2014 Carnets sul 15 e sull\u2019 11, cartella \u00ABtest\u00BB \u2014 perch\u00E9 non si d\u00E0 per scontato che sia cambiata solo la parte di Claude.")]));

children.push(H3("Fase 1 \u2014 controllo materiali"));
children.push(P([R("I tre zip arrivati interi: file attesi, righe e arco giusti, codice sano. "), B("Atteso"), R(": ogni riga "), M("OK"), R(", chiusura "), M("FASE 1: OK"), R(".")]));
children.push(codeBox(FASE1_SRC));

children.push(H3("Fase 2 \u2014 funzionamento Fabbrica"));
children.push(P([R("Dai materiali si ricostruisce "), M("istat.db"), R(" e si "), B("certifica"), R(" cosa contiene: conti (627.861 / 377.866), giuntura fonti 2018|2019, zero comuni senza nome, firme (Lecco 2026 = 334.211, M+F = T, province = Italia). \u00C8 anche la "), B("rete di sicurezza"), R(": si fa col thread vivo, cos\u00EC uno zip marcio si scopre prima del trasloco. "), B("Atteso"), R(": tutte "), M("OK"), R(", chiusura "), M("FASE 2: OK"), R(".")]));
children.push(warn([new Paragraph({ children: [B("\u26A0  Il comune di None.  "), R("Il comune "), M("001168"), R(" (provincia di Torino) si chiama davvero \u00ABNone\u00BB, e pandas di default legge la stringa "), M("None"), R(" come valore nullo. Per questo i dizionari dei nomi si leggono con "), M("keep_default_na=False, na_values=[]"), R(" \u2014 sia qui sia nella ricetta di ricostruzione (S3). \u00C8 l\u2019unico comune italiano che cade in questa trappola.")] })]));
children.push(codeBox(FASE2_SRC));

children.push(H3("Fasi 3 e 4 \u2014 giro reale (iPhone 15, poi 11)"));
children.push(P([R("Stesso script, sui due telefoni, in Carnets, cartella \u00ABtest\u00BB: prova l\u2019intera catena reale \u2014 la libreria "), M("sdmx"), R(", l\u2019endpoint "), M("esploradati"), R(", il cubo comunale, il parse. Sentinella Esino (valore noto a memoria), autoportante, niente "), M("input()"), R(", cronometro. "), B("Atteso"), R(": "), M("2024 \u2192 755"), R(", "), M("2025 \u2192 747"), R(" (il bug "), M("+1"), R("), in pochi secondi. Server lunatico \u2192 rilanciare identico.")]));
children.push(codeBox(FASE34_SRC));
children.push(P([R("Quattro fasi verdi \u2192 il thread \u00E8 tornato operativo.")]));

children.push(new Paragraph({ spacing: { before: 300 }, alignment: AlignmentType.CENTER,
  children: [new TextRun({ text: "\u2014 fine del manuale \u2014", italics: true, size: 20, color: "888888" })] }));

// ============================================================
//  DOCUMENTO
// ============================================================
const doc = new Document({
  features: { updateFields: true },
  styles: {
    default: { document: { run: { font: "Arial", size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 30, bold: true, font: "Arial", color: "1F3864" },
        paragraph: { spacing: { before: 320, after: 160 }, outlineLevel: 0,
          border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: "B4C6E7", space: 6 } } } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 25, bold: true, font: "Arial", color: "2E5496" },
        paragraph: { spacing: { before: 220, after: 110 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 22, bold: true, font: "Arial", color: "44546A" },
        paragraph: { spacing: { before: 160, after: 80 }, outlineLevel: 2 } },
    ],
  },
  numbering: { config: [
    { reference: "bul", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 600, hanging: 280 } } } }] },
  ] },
  sections: [{
    properties: {
      titlePage: true,
      page: { size: { width: PW, height: PH }, margin: { top: MARG, right: MARG, bottom: MARG, left: MARG } },
    },
    footers: {
      first: new Footer({ children: [new Paragraph({ children: [new TextRun("")] })] }),
      default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER,
        children: [new TextRun({ text: "Manuale API ISTAT \u00B7 Progetto Popolazione \u00B7 v24    \u00B7    pag. ", size: 16, color: "888888" }),
          new TextRun({ children: [PageNumber.CURRENT], size: 16, color: "888888" })] })] }),
    },
    children,
  }],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync("Manuale_API_ISTAT_Popolazione_v31.docx", buf);
  console.log("scritto Manuale_API_ISTAT_Popolazione_v31.docx", buf.length, "byte");
});
