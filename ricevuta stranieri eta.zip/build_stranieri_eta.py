#!/usr/bin/env python3
# ============================================================================
#  build_stranieri_eta.py — RICETTA (Ricevuta CSD, 09/07/2026)
#  Prodotta DAL Magazzino certificato. Ricarica e RIVERIFICA.
#
#  Set PULITO: solo province, nessun aggregato territoriale, nessuna
#  soppressione. E' un CUBO PIENO: 101 eta x 8 anni x 3 sessi x 107 province.
#  Non ha le trappole [F3] (fusioni) ne' [F7] (Trentino): non ha comuni
#  ne' regioni.
#
#  ⚠ NON ha una riga TOTAL per l'eta. Il totale e' `stranieri`.
#
#  [K9] · [P3.B] dtype+indici · [T15] chiave TEXT · [T30] anno INTEGER
#  USO:   python3 build_stranieri_eta.py
#  Prova: ISTAT_DB=/tmp/test.db python3 build_stranieri_eta.py
#  Exit:  0 = verde · 1 = rosso
# ============================================================================
import sqlite3, pandas as pd, os, sys

RECEIPT = os.environ.get("RECEIPT", "stranieri_eta.csv.gz")
DB      = os.environ.get("ISTAT_DB", "istat.db")
RIGHE, PROVINCE, ETA = 259_368, 107, 101
ANNI    = list(range(2019, 2027))
G_MF    = 86_456       # celle codice x anno x eta
G_EXT   = 2_568        # gruppi codice x anno x sesso (per la saldatura esterna)
# ancore: Sigma(province, eta) == stranieri Italia
ANCORE  = {2019: 4_996_158, 2024: 5_253_658, 2026: 5_559_527}

print(f"RECEIPT: {RECEIPT}\nDB:      {DB}\n")
if not os.path.exists(RECEIPT): print(f"MANCA {RECEIPT}"); sys.exit(1)

df = pd.read_csv(RECEIPT, dtype={"codice":str,"nome":str,"livello":str,
                                 "sesso":str,"fonte":str},
                 keep_default_na=False, na_values=[])
df["anno"]   = df.anno.astype(int)
df["eta"]    = df.eta.astype(int)
df["valore"] = df.valore.astype("int64")

con = sqlite3.connect(DB)
con.execute("DROP TABLE IF EXISTS stranieri_eta")
con.execute("""CREATE TABLE stranieri_eta(
  codice TEXT, nome TEXT, livello TEXT, anno INTEGER,
  sesso TEXT, eta INTEGER, valore INTEGER, fonte TEXT)""")
df.to_sql("stranieri_eta", con, if_exists="append", index=False)
con.execute("CREATE INDEX idx_se_cod ON stranieri_eta(codice)")
con.execute("CREATE INDEX idx_se_key ON stranieri_eta(codice,anno,sesso,eta)")
con.commit()
print(f"caricate {len(df):,} righe · indici creati\n")

ok=True
def prova(nome, cond, det=""):
    global ok; ok &= bool(cond)
    print(f"  [{'VERDE' if cond else 'ROSSO'}] {nome}{' — '+det if det else ''}")

print("PROVE")
r=con.execute("SELECT COUNT(*) FROM stranieri_eta").fetchone()[0]
prova("righe", r==RIGHE, f"{r:,}")
c=con.execute("SELECT COUNT(DISTINCT codice) FROM stranieri_eta").fetchone()[0]
prova("province", c==PROVINCE, f"{c} (MAI comuni, MAI regioni)")
lv=[x[0] for x in con.execute("SELECT DISTINCT livello FROM stranieri_eta")]
prova("livello unico 'provincia'", lv==["provincia"], str(lv))
a=[x[0] for x in con.execute("SELECT DISTINCT anno FROM stranieri_eta ORDER BY anno")]
prova("anni 2019-2026", a==ANNI, f"{len(a)} anni")
e=con.execute("SELECT COUNT(DISTINCT eta) FROM stranieri_eta").fetchone()[0]
mn,mx=con.execute("SELECT MIN(eta), MAX(eta) FROM stranieri_eta").fetchone()
prova("101 eta singole 0-100", e==ETA and mn==0 and mx==100, f"{e} valori, {mn}-{mx}")
f=[x[0] for x in con.execute("SELECT DISTINCT fonte FROM stranieri_eta")]
prova("fonte unica POPSTRRES1", f==["POPSTRRES1"], str(f))

# CUBO PIENO: nessuna cella mancante
atteso = ETA * len(ANNI) * 3 * PROVINCE
prova(f"CUBO PIENO: {ETA} x {len(ANNI)} x 3 x {PROVINCE} = {atteso:,}", r==atteso,
      f"{r:,} — nessuna soppressione, nessuna cella assente")

prova("typeof(codice)='text' [T15]",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(codice) FROM stranieri_eta")]==["text"])
prova("typeof(anno)='integer' [T30]",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(anno) FROM stranieri_eta")]==["integer"])
prova("typeof(eta)='integer' (non stringa)",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(eta) FROM stranieri_eta")]==["integer"])
prova("typeof(valore)='integer'",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(valore) FROM stranieri_eta")]==["integer"])
prova("Lecco ITC43 presente (chiave NUTS)",
      con.execute("SELECT COUNT(*) FROM stranieri_eta WHERE codice='ITC43'").fetchone()[0]>0)

# SALDATURA: M+F=T per OGNI eta
q="""SELECT COUNT(*), SUM(ABS(d)>0) FROM (
  SELECT codice,anno,eta,
    SUM(CASE sesso WHEN 'maschi'  THEN valore
                   WHEN 'femmine' THEN valore
                   WHEN 'totale'  THEN -valore END) AS d
  FROM stranieri_eta GROUP BY codice,anno,eta HAVING COUNT(DISTINCT sesso)=3)"""
n,b = con.execute(q).fetchone()
prova("saldatura M + F = T (per ogni eta)", n==G_MF and (b or 0)==0,
      f"{n:,} celle, {b or 0} eccezioni")

# ANCORE: Sigma(province, eta) == stranieri Italia
print("  ancore — Sigma(province x 101 eta) == stranieri Italia:")
for anno, att in ANCORE.items():
    v=con.execute("""SELECT SUM(valore) FROM stranieri_eta
      WHERE sesso='totale' AND anno=?""",(anno,)).fetchone()[0]
    prova(f"  {anno} = {att:,}", v==att, f"{v:,}")

# SALDATURA ESTERNA: Sigma 101 eta == stranieri, per provincia
if con.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='stranieri'").fetchone()[0]:
    q2="""SELECT COUNT(*), SUM(ABS(d)>0) FROM (
      SELECT se.codice, se.anno, se.sesso, SUM(se.valore) - MAX(s.valore) AS d
      FROM stranieri_eta se JOIN stranieri s
        ON s.codice=se.codice AND s.anno=se.anno AND s.sesso=se.sesso
      GROUP BY se.codice, se.anno, se.sesso)"""
    n2,b2 = con.execute(q2).fetchone()
    prova("SALDATURA ESTERNA: Sigma 101 eta == `stranieri` (NON c'e' TOTAL interno)",
          n2==G_EXT and (b2 or 0)==0, f"{n2:,} gruppi, {b2 or 0} eccezioni")
else:
    print("  [nota] `stranieri` assente: saldatura esterna non verificabile.")
    print("         Il totale NON e' nel set: Sigma 101 eta == stranieri.")
    print("         Ancore verificate: vedi sopra.")

con.close()
print("\nESITO:", "VERDE — stranieri_eta certificato" if ok else "ROSSO — NON usare")
sys.exit(0 if ok else 1)
