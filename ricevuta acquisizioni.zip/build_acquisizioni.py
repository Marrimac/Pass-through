#!/usr/bin/env python3
# ============================================================================
#  build_acquisizioni.py — RICETTA (Ricevuta CSD, 09/07/2026)
#  Prodotta DAL Magazzino certificato. Ricarica e RIVERIFICA.
#
#  ⚠ UNA FONTE, DUE TABELLE. [P4] corretto il 09/07: l'unita' della Ricevuta
#    e' la FONTE, non la tabella. `ACQ` (DEMO, gemello SDMX 29_849 DCIS_ACQCITIZ)
#    era 4 CSV; e' diventato 2 tabelle perche' 3 dei 4 hanno la STESSA chiave
#    (territorio, anno, sesso) e lo STESSO Totale. Vedi [F18].
#
#  ⚠ TRAPPOLE (tutte accertate, tutte verificate qui):
#    · 'Italia' e' fra i 112 territori: Sigma tutti = 434.896 vs Italia 217.448.
#      IL DOPPIO. Escludere codice='IT'. [F12b]
#    · le celle VUOTE del CSV originale valgono ZERO, non "dato assente".
#    · 4 province sarde soppresse (2012-2017) con codici PROVVISORI CSD
#      (IT_CI, IT_VS, IT_OG, IT_OT): NON sono codici ISTAT.
#
#  [K9] · [P3.B] dtype+indici · [T15] chiave TEXT · [T30] anno INTEGER
#  USO:   python3 build_acquisizioni.py
#  Prova: ISTAT_DB=/tmp/test.db python3 build_acquisizioni.py
#  Exit:  0 = verde · 1 = rosso
# ============================================================================
import sqlite3, pandas as pd, os, sys

R_TER = os.environ.get("RECEIPT_TER", "acquisizioni_territorio.csv.gz")
R_CIT = os.environ.get("RECEIPT_CIT", "acquisizioni_cittadinanza.csv.gz")
DB    = os.environ.get("ISTAT_DB", "istat.db")

RIGHE_TER, RIGHE_CIT = 88_164, 5_382
TERRITORI, CITTADINANZE = 112, 23
ANNI = list(range(2012, 2025))
DIMENSIONI = ['eta','motivo','paese']
SESSI = ['Femmine','Maschi','Maschi e femmine']
CATEG = {"paese":23, "motivo":6, "eta":7}       # incl. 'Totale'
G_MOT_ETA, G_MOT_PAE = 4_266, 1_422
ANCORE = {2012: 65_383, 2024: 217_448}          # Italia, motivo/Totale/M+F
SIGMA_TUTTI_2024 = 434_896                      # prova negativa: il doppio
SARDE = ['IT_CI','IT_OG','IT_OT','IT_VS']

print(f"RECEIPT: {R_TER}\n         {R_CIT}\nDB:      {DB}\n")
for f in (R_TER, R_CIT):
    if not os.path.exists(f): print(f"MANCA {f}"); sys.exit(1)

# [K9] su tutte le colonne testo
T = pd.read_csv(R_TER, dtype={"codice":str,"nome":str,"sesso":str,
                              "dimensione":str,"categoria":str},
                keep_default_na=False, na_values=[])
K = pd.read_csv(R_CIT, dtype={"cittadinanza":str,"sesso":str,"motivo":str},
                keep_default_na=False, na_values=[])
T["anno"] = T.anno.astype(int); T["valore"] = T.valore.astype(float)
K["anno"] = K.anno.astype(int); K["valore"] = K.valore.astype(float)

con = sqlite3.connect(DB)
con.execute("DROP TABLE IF EXISTS acquisizioni_territorio")
con.execute("""CREATE TABLE acquisizioni_territorio(
  codice TEXT, nome TEXT, anno INTEGER, sesso TEXT,
  dimensione TEXT, categoria TEXT, valore REAL)""")
T.to_sql("acquisizioni_territorio", con, if_exists="append", index=False)
con.execute("CREATE INDEX idx_acqt_cod ON acquisizioni_territorio(codice)")
con.execute("CREATE INDEX idx_acqt_key ON acquisizioni_territorio(codice,anno,sesso,dimensione,categoria)")

con.execute("DROP TABLE IF EXISTS acquisizioni_cittadinanza")
con.execute("""CREATE TABLE acquisizioni_cittadinanza(
  cittadinanza TEXT, anno INTEGER, sesso TEXT, motivo TEXT, valore REAL)""")
K.to_sql("acquisizioni_cittadinanza", con, if_exists="append", index=False)
con.execute("CREATE INDEX idx_acqc_key ON acquisizioni_cittadinanza(cittadinanza,anno,sesso)")
con.commit()
print(f"caricate {len(T):,} + {len(K):,} righe · indici creati\n")

ok=True
def prova(nome, cond, det=""):
    global ok; ok &= bool(cond)
    print(f"  [{'VERDE' if cond else 'ROSSO'}] {nome}{' — '+det if det else ''}")

print("PROVE — tabella 1: acquisizioni_territorio")
r=con.execute("SELECT COUNT(*) FROM acquisizioni_territorio").fetchone()[0]
prova("righe", r==RIGHE_TER, f"{r:,}")
c=con.execute("SELECT COUNT(DISTINCT codice) FROM acquisizioni_territorio").fetchone()[0]
prova("112 territori (107 province + Italia + 4 sarde soppresse)", c==TERRITORI, f"{c}")
a=[x[0] for x in con.execute("SELECT DISTINCT anno FROM acquisizioni_territorio ORDER BY anno")]
prova("anni 2012-2024", a==ANNI, f"{len(a)} anni")
d=sorted(x[0] for x in con.execute("SELECT DISTINCT dimensione FROM acquisizioni_territorio"))
prova("3 dimensioni", d==DIMENSIONI, str(d))
s=sorted(x[0] for x in con.execute("SELECT DISTINCT sesso FROM acquisizioni_territorio"))
prova("3 sessi", s==SESSI, str(s))
for dim, n in CATEG.items():
    v=con.execute("SELECT COUNT(DISTINCT categoria) FROM acquisizioni_territorio WHERE dimensione=?",(dim,)).fetchone()[0]
    prova(f"  categorie '{dim}'", v==n, f"{v} (incl. Totale)")

prova("typeof(codice)='text' [T15]",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(codice) FROM acquisizioni_territorio")]==["text"])
prova("typeof(anno)='integer' [T30]",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(anno) FROM acquisizioni_territorio")]==["integer"])
prova("nessun codice NULL",
      con.execute("SELECT COUNT(*) FROM acquisizioni_territorio WHERE codice IS NULL").fetchone()[0]==0)

# ⚠ LA PROVA CHE GIUSTIFICA LA CONDENSAZIONE
print("\n  la CONDENSAZIONE: il Totale coincide fra le tre dimensioni?")
q="""SELECT COUNT(*), SUM(ABS(m-e)>0.5) FROM (
  SELECT codice,anno,sesso,
    MAX(CASE WHEN dimensione='motivo' AND categoria='Totale' THEN valore END) m,
    MAX(CASE WHEN dimensione='eta'    AND categoria='Totale' THEN valore END) e
  FROM acquisizioni_territorio GROUP BY codice,anno,sesso)"""
n1,b1 = con.execute(q).fetchone()
prova("  Totale(motivo) == Totale(eta)", n1==G_MOT_ETA and (b1 or 0)==0, f"{n1:,} gruppi, {b1 or 0} ecc.")
q2="""SELECT COUNT(*), SUM(ABS(m-p)>0.5) FROM (
  SELECT codice,anno,
    MAX(CASE WHEN dimensione='motivo' AND categoria='Totale' AND sesso='Maschi e femmine' THEN valore END) m,
    MAX(CASE WHEN dimensione='paese'  AND categoria='Totale' THEN valore END) p
  FROM acquisizioni_territorio GROUP BY codice,anno HAVING m IS NOT NULL AND p IS NOT NULL)"""
n2,b2 = con.execute(q2).fetchone()
prova("  Totale(motivo) == Totale(paese)", n2==G_MOT_PAE and (b2 or 0)==0, f"{n2:,} gruppi, {b2 or 0} ecc.")
print("       (e' la prova che i 3 CSV erano UN dato tagliato in tre modi. [F18])")

print("\n  le componenti sommano al Totale, dentro ogni dimensione?")
for dim in DIMENSIONI:
    q3=f"""SELECT COUNT(*), SUM(ABS(d)>0.5) FROM (
      SELECT codice,anno,sesso,
        SUM(CASE WHEN categoria<>'Totale' THEN valore ELSE 0 END)
      - SUM(CASE WHEN categoria='Totale' THEN valore ELSE 0 END) d
      FROM acquisizioni_territorio WHERE dimensione='{dim}' GROUP BY codice,anno,sesso)"""
    n3,b3 = con.execute(q3).fetchone()
    prova(f"  {dim}", (b3 or 0)==0, f"{n3:,} gruppi, {b3 or 0} ecc.")

mf=con.execute("""SELECT COUNT(*) FROM (SELECT codice,anno,dimensione,categoria,
  SUM(CASE sesso WHEN 'Maschi' THEN valore WHEN 'Femmine' THEN valore
                 WHEN 'Maschi e femmine' THEN -valore END) d
  FROM acquisizioni_territorio WHERE dimensione IN ('motivo','eta')
  GROUP BY codice,anno,dimensione,categoria HAVING ABS(d)>0.5)""").fetchone()[0]
prova("M + F = 'Maschi e femmine'", mf==0, f"{mf} eccezioni")

# ⚠ PROVA NEGATIVA: 'Italia' e' un aggregato. Sommare tutto DEVE dare il doppio.
print("\n  prova NEGATIVA [P4.2] — 'Italia' e' un AGGREGATO fra i 112:")
tutti=con.execute("""SELECT SUM(valore) FROM acquisizioni_territorio WHERE anno=2024
  AND dimensione='motivo' AND categoria='Totale' AND sesso='Maschi e femmine'""").fetchone()[0]
prova(f"  Sigma TUTTI i 112 nel 2024 = {SIGMA_TUTTI_2024:,} (il DOPPIO)",
      abs(tutti-SIGMA_TUTTI_2024)<0.5, f"{tutti:,.0f}")
print("       (se un domani non fosse il doppio, 'Italia' non e' piu' l'unico aggregato)")

print("\n  ancore — Italia (motivo/Totale/Maschi e femmine):")
for anno, att in ANCORE.items():
    v=con.execute("""SELECT valore FROM acquisizioni_territorio WHERE codice='IT' AND anno=?
      AND dimensione='motivo' AND categoria='Totale' AND sesso='Maschi e femmine'""",(anno,)).fetchone()
    prova(f"  Italia {anno} = {att:,}", v and abs(v[0]-att)<0.5, f"{v[0]:,.0f}" if v else "assente")
sp=con.execute("""SELECT SUM(valore) FROM acquisizioni_territorio WHERE codice<>'IT' AND anno=2024
  AND dimensione='motivo' AND categoria='Totale' AND sesso='Maschi e femmine'""").fetchone()[0]
prova("  Sigma province (senza Italia) == Italia", abs(sp-ANCORE[2024])<0.5, f"{sp:,.0f}")

print("\n  le 4 province sarde soppresse (codici PROVVISORI CSD, non ISTAT):")
sd=sorted(x[0] for x in con.execute("SELECT DISTINCT codice FROM acquisizioni_territorio WHERE codice LIKE 'IT!_%' ESCAPE '!'"))
prova("  presenti", sd==SARDE, str(sd))
for cod in SARDE:
    r=con.execute("SELECT MIN(anno),MAX(anno) FROM acquisizioni_territorio WHERE codice=?",(cod,)).fetchone()
    prova(f"  {cod}: 2012-2017 (soppressa nel 2016)", r==(2012,2017), f"{r[0]}-{r[1]}")
r=con.execute("SELECT MIN(anno),MAX(anno) FROM acquisizioni_territorio WHERE codice='IT111'").fetchone()
prova("  IT111 Sud Sardegna: 2018-2024 (nata nel 2018)", r==(2018,2024), f"{r[0]}-{r[1]}")

print("\nPROVE — tabella 2: acquisizioni_cittadinanza")
r=con.execute("SELECT COUNT(*) FROM acquisizioni_cittadinanza").fetchone()[0]
prova("righe", r==RIGHE_CIT, f"{r:,}")
c=con.execute("SELECT COUNT(DISTINCT cittadinanza) FROM acquisizioni_cittadinanza").fetchone()[0]
prova("23 cittadinanze", c==CITTADINANZE, f"{c}")
prova("typeof(anno)='integer'",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(anno) FROM acquisizioni_cittadinanza")]==["integer"])
q5="""SELECT COUNT(*), SUM(ABS(d)>0.5) FROM (
  SELECT cittadinanza,anno,sesso,
    SUM(CASE WHEN motivo<>'Totale' THEN valore ELSE 0 END)
  - SUM(CASE WHEN motivo='Totale' THEN valore ELSE 0 END) d
  FROM acquisizioni_cittadinanza GROUP BY cittadinanza,anno,sesso)"""
n5,b5 = con.execute(q5).fetchone()
prova("Sigma 5 motivi == Totale", (b5 or 0)==0, f"{n5:,} gruppi, {b5 or 0} ecc.")
mf2=con.execute("""SELECT COUNT(*) FROM (SELECT cittadinanza,anno,motivo,
  SUM(CASE sesso WHEN 'Maschi' THEN valore WHEN 'Femmine' THEN valore
                 WHEN 'Maschi e femmine' THEN -valore END) d
  FROM acquisizioni_cittadinanza GROUP BY cittadinanza,anno,motivo HAVING ABS(d)>0.5)""").fetchone()[0]
prova("M + F = 'Maschi e femmine'", mf2==0, f"{mf2} eccezioni")

con.close()
print("\nESITO:", "VERDE — ACQ certificato (2 tabelle)" if ok else "ROSSO — NON usare")
sys.exit(0 if ok else 1)
