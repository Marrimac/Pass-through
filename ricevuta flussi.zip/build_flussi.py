#!/usr/bin/env python3
# ============================================================================
#  build_flussi.py — RICETTA (Ricevuta CSD, 09/07/2026)
#  Prodotta DAL Magazzino certificato. Ricarica e RIVERIFICA.
#  [K9] · [P3.B] dtype+indici · [T15] chiave TEXT · [T30] anno INTEGER
#  USO:   python3 build_flussi.py
#  Prova: ISTAT_DB=/tmp/test.db python3 build_flussi.py
#  Exit:  0 = verde · 1 = rosso
# ============================================================================
import sqlite3, pandas as pd, os, sys

RECEIPT = os.environ.get("RECEIPT", "flussi.csv.gz")
DB      = os.environ.get("ISTAT_DB", "istat.db")
RIGHE, CODICI = 377_866, 8_063
ANNI  = list(range(2019, 2026))
TIPI  = ['DEATH','INTERTNMIG_REGOF','INTNETMIGR_REGOF','LBIRTH',
         'NTGROW_REGOF','STAT_ADJUST','TOTAL_BAL']
LIVELLI = ['Italia','comune','provincia','regione','ripartizione']
G_NAT, G_TOT = 56_276, 48_243     # gruppi completi
SCISSIONI = 4                     # eccezioni attese: comuni scissi
ANCORE = {2019: -175_185, 2024: -27_766}   # Sigma province TOTAL_BAL == Italia

print(f"RECEIPT: {RECEIPT}\nDB:      {DB}\n")
if not os.path.exists(RECEIPT): print(f"MANCA {RECEIPT}"); sys.exit(1)

df = pd.read_csv(RECEIPT, dtype={"codice":str,"nome":str,"livello":str,"tipo":str},
                 keep_default_na=False, na_values=[])
df["anno"]   = df.anno.astype(int)
df["valore"] = df.valore.astype(float)

con = sqlite3.connect(DB)
con.execute("DROP TABLE IF EXISTS flussi")
con.execute("""CREATE TABLE flussi(
  codice TEXT, nome TEXT, livello TEXT, anno INTEGER, tipo TEXT, valore REAL)""")
df.to_sql("flussi", con, if_exists="append", index=False)
con.execute("CREATE INDEX idx_flu_cod ON flussi(codice)")
con.execute("CREATE INDEX idx_flu_key ON flussi(codice,anno,tipo)")
con.commit()
print(f"caricate {len(df):,} righe · indici creati\n")

ok=True
def prova(nome, cond, det=""):
    global ok; ok &= bool(cond)
    print(f"  [{'VERDE' if cond else 'ROSSO'}] {nome}{' — '+det if det else ''}")

print("PROVE")
r=con.execute("SELECT COUNT(*) FROM flussi").fetchone()[0]
prova("righe", r==RIGHE, f"{r:,}")
c=con.execute("SELECT COUNT(DISTINCT codice) FROM flussi").fetchone()[0]
prova("codici", c==CODICI, f"{c:,} (tutti i livelli)")
a=[x[0] for x in con.execute("SELECT DISTINCT anno FROM flussi ORDER BY anno")]
prova("anni", a==ANNI, str(a))
t=sorted(x[0] for x in con.execute("SELECT DISTINCT tipo FROM flussi"))
prova("7 tipi di evento", t==TIPI, f"{len(t)}")
lv=sorted(x[0] for x in con.execute("SELECT DISTINCT livello FROM flussi"))
prova("5 livelli", lv==LIVELLI, str(lv))

prova("typeof(codice)='text' [T15]",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(codice) FROM flussi")]==["text"])
prova("typeof(anno)='integer' [T30]",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(anno) FROM flussi")]==["integer"])
z=con.execute("SELECT COUNT(DISTINCT codice) FROM flussi WHERE codice LIKE '00%'").fetchone()[0]
prova("zeri iniziali conservati", z>0, f"{z} comuni")
nm=con.execute("SELECT nome FROM flussi WHERE codice='001168' LIMIT 1").fetchone()
prova("sentinella K9: 001168 = 'None'", bool(nm) and nm[0]=="None", repr(nm[0] if nm else None))

# SALDATURA 1: saldo naturale
q="""SELECT COUNT(*), SUM(ABS(d)>0.001) FROM (
  SELECT codice,anno,
    SUM(CASE tipo WHEN 'NTGROW_REGOF' THEN valore ELSE 0 END)
  - SUM(CASE tipo WHEN 'LBIRTH' THEN valore ELSE 0 END)
  + SUM(CASE tipo WHEN 'DEATH'  THEN valore ELSE 0 END) AS d
  FROM flussi WHERE tipo IN ('NTGROW_REGOF','LBIRTH','DEATH')
  GROUP BY codice,anno HAVING COUNT(DISTINCT tipo)=3)"""
n,b = con.execute(q).fetchone()
prova("saldatura naturale  NTGROW = LBIRTH - DEATH",
      n==G_NAT and (b or 0)==0, f"{n:,} gruppi completi, {b or 0} eccezioni")

# SALDATURA 2: bilancio totale — QUATTRO componenti (il migratorio e' SCISSO)
q2="""SELECT COUNT(*), SUM(ABS(d)>0.001) FROM (
  SELECT codice,anno,
    SUM(CASE tipo WHEN 'TOTAL_BAL' THEN valore ELSE 0 END)
  - SUM(CASE tipo WHEN 'NTGROW_REGOF'     THEN valore ELSE 0 END)
  - SUM(CASE tipo WHEN 'INTNETMIGR_REGOF' THEN valore ELSE 0 END)
  - SUM(CASE tipo WHEN 'INTERTNMIG_REGOF' THEN valore ELSE 0 END)
  - SUM(CASE tipo WHEN 'STAT_ADJUST'      THEN valore ELSE 0 END) AS d
  FROM flussi WHERE tipo IN ('TOTAL_BAL','NTGROW_REGOF','INTNETMIGR_REGOF',
                             'INTERTNMIG_REGOF','STAT_ADJUST')
  GROUP BY codice,anno HAVING COUNT(DISTINCT tipo)=5)"""
n2,b2 = con.execute(q2).fetchone()
prova("saldatura totale  TOTAL_BAL = NTGROW + INTNETMIGR + INTERTNMIG + STAT_ADJUST",
      n2==G_TOT and (b2 or 0)==SCISSIONI, f"{n2:,} gruppi completi, {b2 or 0} eccezioni (attese {SCISSIONI})")
print("       (le 4 eccezioni sono SCISSIONI comunali, a coppie che si compensano:")
print("        Trapani -8415 <-> Misiliscemi +8415 (2021, comune nato);")
print("        Agrigento -949 <-> Favara +949 (2020). NON e' un difetto.)")

# CONFRONTO ESTERNO: Sigma province == Italia  ([F3]: mai Sigma comuni)
print("  confronto esterno — Sigma province TOTAL_BAL == Italia [F3]:")
for anno, att in ANCORE.items():
    sp=con.execute("""SELECT SUM(valore) FROM flussi
      WHERE livello='provincia' AND tipo='TOTAL_BAL' AND anno=?""",(anno,)).fetchone()[0]
    it=con.execute("""SELECT valore FROM flussi
      WHERE codice='IT' AND tipo='TOTAL_BAL' AND anno=?""",(anno,)).fetchone()
    prova(f"  {anno}: Sigma province == Italia == {att:,}",
          it and abs(sp-it[0])<0.5 and abs(sp-att)<0.5, f"{sp:,.0f}")

con.close()
print("\nESITO:", "VERDE — flussi certificato" if ok else "ROSSO — NON usare")
sys.exit(0 if ok else 1)
