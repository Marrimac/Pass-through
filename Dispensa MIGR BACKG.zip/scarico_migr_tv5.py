# ============================================================================
#  SCARICO — DF_DCSS_MIGR_BACKG_PAR_TV_5_COM
#  Naturalizzati nati all'estero — comuni
#  CSD · Dispensa MIGR_BACKG · da S9_SCARICO_COMUNI (gemello v2)
#  SENZA VPN. Copia in Carnets, Run. Riprende se interrotto.
#  Freno 15.0s (K3: 4 query/min). 1.172 lotti (9.380 comuni codelist) -> ~4.9h
# ============================================================================
import sdmx, time, os, glob, shutil, collections, re
import pandas as pd

# ---- CAMBIA QUI (1/3): il cubo, il timbro, l'arco -------------------------
FLOW     = "DF_DCSS_MIGR_BACKG_PAR_TV_5_COM"
VERSIONE = "migr_tv5_v1.0"      # timbro: cambiarlo forza ripartenza pulita
START, END = "2021", "2023"            # arco reale (R20-R22)
NOME     = "migr_tv5"
# ---------------------------------------------------------------------------

# ---- CAMBIA QUI (2/3): i FISSI = SOLO le dimensioni degeneri (dalla F3) ----
FISSI = {
    "CITIZENSHIP": "ITL",
    "EDU_ATTAIN": "ALL",
}
# ---------------------------------------------------------------------------

G0       = 8
LIMBO    = "ISTAT/limbo"; CH = LIMBO + "/" + NOME + "_g"
COMUNI_F = LIMBO + "/comuni_list.txt"; DONE_F = CH + "/_done.txt"
VERS_F   = CH + "/_versione.txt"

# --- Timbro di versione (standard CSD) ---
def _timbro_attuale():
    if os.path.isfile(VERS_F): return open(VERS_F).read().strip()
    return None
if os.path.isdir(CH) and _timbro_attuale() != VERSIONE:
    print(f"[TIMBRO] versione diversa ({_timbro_attuale()}): svuoto per {VERSIONE}.")
    shutil.rmtree(CH)
os.makedirs(CH, exist_ok=True)
if _timbro_attuale() != VERSIONE:
    open(VERS_F, "w").write(VERSIONE + "\n")
    print(f"[TIMBRO] cartella marcata {VERSIONE}, parto pulito.")
else:
    print(f"[TIMBRO] {VERSIONE} confermato: riprendo dai file esistenti.")

# --- Freno: >=15.0s tra le PARTENZE. Non dorme 15s ogni volta: dorme il
#     residuo. Se il server e' lento, non dorme affatto. Cosi' la cadenza
#     non dipende dalla velocita' di ISTAT. ---
INTERVALLO = 15.0; _last = [0.0]
def freno():
    a = INTERVALLO - (time.time() - _last[0])
    if a > 0: time.sleep(a)
    _last[0] = time.time()

ISTAT = sdmx.Client("ISTAT", timeout=300)
def chiama(fn, att=4, base=8):
    for k in range(att):
        freno()
        try: return fn()
        except Exception as e:
            if "404" in str(e): raise      # 404 = vuoto certificato: non ritentare
            if k == att-1: raise
            time.sleep(base * (k+1))       # backoff 8/16/24s, SOPRA il freno

if os.path.exists(COMUNI_F):
    comuni = [l.strip() for l in open(COMUNI_F) if l.strip()]
else:
    cl = chiama(lambda: ISTAT.codelist("CL_ITTER107").codelist["CL_ITTER107"])
    comuni = sorted(c for c in cl.items if re.fullmatch(r"\d{6}", c))
    open(COMUNI_F, "w").write("\n".join(comuni))
print(f"comuni: {len(comuni)}")

done = {l.strip() for l in open(DONE_F)} if os.path.exists(DONE_F) else set()
todo = [c for c in comuni if c not in done]
print(f"gia' fatti: {len(done)} - da fare: {len(todo)}")

# ---- CAMBIA QUI (3/3): mappa colonne ISTAT -> CSD + ordine keep ------------
#      Rinominare SOLO le dimensioni vive (le degeneri non tornano nell'output).
REN  = {"REF_AREA":"territorio", "INDICATOR":"indicatore", "GENDER":"sesso", "AGE_CLASS":"eta", "PREVOUS_CITIZEN":"citt_prec", "PLACE_BIRTH_PAR":"luogo_nasc_gen", "TIME_PERIOD":"anno"}
KEEP = ["territorio", "indicatore", "sesso", "eta", "citt_prec", "luogo_nasc_gen", "anno", "valore"]
# ---------------------------------------------------------------------------

def tidy(s):
    if isinstance(s, pd.DataFrame):
        s = s.iloc[:,0] if s.shape[1] else s.squeeze()
    df = s.rename("valore").reset_index()
    df = df.rename(columns={k:v for k,v in REN.items() if k in df.columns})
    return df[[c for c in KEEP if c in df.columns]]

counter = len(glob.glob(CH + "/g_*.csv"))
def salva(df):
    global counter
    df.to_csv(f"{CH}/g_{counter:04d}.csv", index=False); counter += 1
def marca(cs): open(DONE_F, "a").write("\n".join(cs) + "\n")
VUOTO = lambda: pd.DataFrame(columns=KEEP)

queue = collections.deque(todo[i:i+G0] for i in range(0, len(todo), G0))
t0 = time.time()
print("=" * 60)
while queue:
    g = queue.popleft()
    key = dict(FISSI); key["REF_AREA"] = "+".join(g)
    try:
        df = tidy(chiama(lambda: sdmx.to_pandas(ISTAT.data(FLOW, key=key,
                  params={"startPeriod":START, "endPeriod":END}))))
        salva(df); marca(g)
        print(f"  ok {len(g)} com -> {len(df)} righe - "
              f"restano {len(queue)} - {(time.time()-t0)/60:.1f}min")
    except Exception as e:
        m = str(e); code = getattr(getattr(e,'response',None),'status_code',None)
        if code == 400 or "400" in m:
            if len(g) <= 1: salva(VUOTO()); marca(g)      # singolo comune: vuoto
            else:
                h = len(g)//2                              # lotto grosso: dimezza
                queue.appendleft(g[h:]); queue.appendleft(g[:h])
        elif "404" in m:
            salva(VUOTO()); marca(g)
            print(f"  . {len(g)} com -> vuoto - {(time.time()-t0)/60:.1f}min")
        else:
            queue.append(g); print(f"  rete? rimando - {type(e).__name__}"); time.sleep(20)
print("=" * 60)
done2 = {l.strip() for l in open(DONE_F)} if os.path.exists(DONE_F) else set()
if set(comuni) <= done2:
    z = shutil.make_archive(LIMBO + "/" + NOME + "_g", "zip", CH)
    print(f"COMPLETO! Zip: {z} ({round(os.path.getsize(z)/1e6,1)} MB)")
else:
    print(f"mancano {len(comuni)-len(done2)} comuni. Rilancia (riprende).")
