#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RICETTA DI BUILD — Fuga dei cervelli (laureati italiani verso l'estero)
========================================================================
Viste ISTAT di origine (ANPR, Trasferimenti di residenza 2002-2024):
  · Tavola 10 (tavola10_serie_istr.xlsx) — laureati, ISCRITTI/CANCELLATI
    per l'ESTERO, per REGIONE e classe d'età. [arco 2013-2024]
  · Tavola 13 (tavola13_serie_istr.xlsx) — gli stessi flussi per PAESE
    di origine/destinazione (per le destinazioni dei partenti).

Questo script è AUTOPORTANTE: legge i due .xlsx grezzi, li normalizza
in formato lungo, scrive due CSV puliti e li carica in istat.db.

⚠  TRAPPOLE (perché questa tabella NON è entrata liscia) — vedi TRAPPOLE.md:
  1. La riga "Italia" nel file è CORROTTA: riporta il totale degli ISCRITTI
     in entrambi i blocchi (iscritti e cancellati). NON va usata.
     → l'Italia si RICOSTRUISCE sommando le 20 regioni.
  2. Doppio blocco verticale: ISCRITTI (righe ~4-26) e CANCELLATI (~31-53)
     condividono le stesse colonne. Vanno letti come due blocchi distinti.
  3. Sub-righe da NON doppiare: "Bolzano/Bozen" e "Trento" sono componenti
     di "Trentino-Alto Adige". Sommando le regioni vanno ESCLUSE.
  4. Classi d'età: la tavola 10 è coerente (0-24, 25-34, 35-64, 65+) su
     tutto l'arco. La tavola 13 usa invece (0-24, 25-39, 40-64, 65+).
     NON mescolare le due classificazioni.
  5. NON confondere con la tavola 16 ("_int" = INTERNO): quella è
     migrazione interregionale (Sud→Nord dentro l'Italia), i cui totali
     nazionali iscritti/cancellati si CONSERVANO (quadratura = prova).
"""
import pandas as pd, sqlite3, os, sys

# ---- percorsi (adatta SRC alla posizione dei file grezzi) ----
SRC = os.environ.get('SRC_DIR', '.')
T10 = os.path.join(SRC, 'tavola10_serie_istr.xlsx')
T13 = os.path.join(SRC, 'tavola13_serie_istr.xlsx')
DB  = os.environ.get('ISTAT_DB', '/tmp/estint/istat.db')
OUT = os.environ.get('OUT_DIR', '.')

SUBROWS = {'Bolzano/Bozen', 'Trento'}          # componenti di Trentino-Alto Adige
SKIP    = {'REGIONI', 'PAESI', 'ISCRITTI', 'CANCELLATI', 'nan', ''}

def normalizza(path, geo_col):
    """Legge una tavola 10/13 e restituisce un DataFrame lungo:
       geo · tipo · classe_eta · anno · valore   (con Italia ricostruita)."""
    raw = pd.read_excel(path, header=None)
    anni  = raw.iloc[1].ffill()                # forward-fill dell'anno (celle unite)
    classi = raw.iloc[2]
    colmap = {}
    for j in range(1, raw.shape[1]):
        a, c = anni.iloc[j], classi.iloc[j]
        if pd.notna(a) and pd.notna(c):
            colmap[j] = (str(int(float(a))), str(c).strip())

    # individua i blocchi ISCRITTI / CANCELLATI dalla colonna 0
    sez = {}
    for i in range(raw.shape[0]):
        v = str(raw.iloc[i, 0]).strip().upper()
        if v in ('ISCRITTI', 'CANCELLATI'):
            sez[v] = i
    blocchi = sorted(sez.items(), key=lambda kv: kv[1])   # in ordine di riga

    righe = []
    for k, (tipo, start) in enumerate(blocchi):
        end = blocchi[k + 1][1] if k + 1 < len(blocchi) else raw.shape[0]
        somma_italia = {}                      # (anno,classe) -> somma regioni/paesi
        for r in range(start + 1, end):
            nome = str(raw.iloc[r, 0]).strip()
            if nome in SKIP or nome in SUBROWS or nome.upper() in ('ITALIA', 'TOTALE'):
                continue   # 'Totale' è il totale generale dei paesi: non è un paese
            for j, (anno, classe) in colmap.items():
                v = raw.iloc[r, j]
                if isinstance(v, (int, float)) and pd.notna(v):
                    righe.append({geo_col: nome, 'tipo': tipo.lower(),
                                  'classe_eta': classe, 'anno': int(anno),
                                  'valore': float(v)})
                    if geo_col == 'territorio':          # Italia solo per le regioni
                        somma_italia[(anno, classe)] = somma_italia.get((anno, classe), 0) + v
        # riga Italia RICOSTRUITA (mai quella corrotta del file)
        if geo_col == 'territorio':
            for (anno, classe), tot in somma_italia.items():
                righe.append({geo_col: 'Italia', 'tipo': tipo.lower(),
                              'classe_eta': classe, 'anno': int(anno), 'valore': float(tot)})
    return pd.DataFrame(righe)

def main():
    reg = normalizza(T10, 'territorio')        # tavola 10: regioni (+ Italia ricostruita)
    # NB: la tavola 13 (per paese) NON entra in Magazzino: i suoi totali non
    # riconciliano con la tavola 10 (struttura asimmetrica, aggregati continentali
    # mescolati ai paesi). Si usa, eventualmente, solo in lettura per la classifica
    # delle destinazioni — mai come fonte di conteggi assoluti.

    # --- quadratura di sicurezza: per l'estero iscritti != cancellati ---
    q = reg[reg.territorio == 'Italia'].groupby('tipo').valore.sum()
    assert q.get('iscritti', 0) != q.get('cancellati', 0), \
        "Totali iscritti/cancellati IDENTICI: file interregionale, NON estero!"
    print(f"  quadratura OK — Italia, tutte età/anni: "
          f"rientri {int(q['iscritti']):,} ≠ partenze {int(q['cancellati']):,}")

    # --- scrittura CSV puliti ---
    p_reg = os.path.join(OUT, 'fuga_cervelli_regioni.csv')
    reg.to_csv(p_reg, index=False)
    print(f"  scritto: {p_reg} ({len(reg):,} righe)")

    # --- caricamento in istat.db ---
    con = sqlite3.connect(DB)
    reg.to_sql('fuga_cervelli_regioni', con, if_exists='replace', index=False)
    con.commit()
    n = con.execute("SELECT COUNT(*) FROM fuga_cervelli_regioni").fetchone()[0]
    print(f"  caricata fuga_cervelli_regioni: {n:,} righe")
    con.close()
    print("FATTO.")

if __name__ == '__main__':
    main()
