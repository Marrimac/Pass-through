# TRAPPOLE — Fuga dei cervelli (laureati italiani verso l'estero)

Ricevuta della tabella **`fuga_cervelli_regioni`** del Magazzino CSD.
Vista ISTAT di origine: **Tavola 10** dei *Trasferimenti di residenza* (ANPR),
`tavola10_serie_istr.xlsx` — "Cittadini italiani laureati iscritti e cancellati
per trasferimento di residenza **per l'estero**", per regione e classe d'età,
arco **2013–2024**.

Questa tabella **non è entrata liscia** in Magazzino. Le insidie sotto sono il
motivo per cui esiste questa ricevuta: chi dovesse rifare il caricamento le
ritrovi già risolte, senza rifare il lavoro di detective.

---

## Le cinque trappole

**1. La riga «Italia» del file è CORROTTA.**
Nel file grezzo la riga "Italia" riporta lo stesso numero — il totale degli
*iscritti* — in **entrambi** i blocchi (iscritti e cancellati). È un errore
della vista ISTAT. Usarla darebbe saldo netto zero (assurdo).
→ **L'Italia va RICOSTRUITA sommando le 20 regioni**, separatamente per
iscritti e per cancellati. È ciò che fa lo script (`somma_italia`).

**2. Doppio blocco verticale ISCRITTI / CANCELLATI.**
Il foglio impila due blocchi che condividono le stesse colonne: ISCRITTI
(righe ~4–26) sopra, CANCELLATI (righe ~31–53) sotto. Vanno letti come due
blocchi distinti e marcati con `tipo`. Lo script li individua dalle etichette
in colonna 0.

**3. Sub-righe Bolzano/Trento da NON doppiare.**
"Bolzano/Bozen" e "Trento" compaiono come righe a sé, ma sono **componenti**
di "Trentino-Alto Adige". Nella somma delle regioni vanno **escluse**, o si
conta due volte quel territorio. Lo script le tiene in `SUBROWS`.

**4. Classi d'età: coerenti qui, NON altrove.**
La tavola 10 usa `0-24 · 25-34 · 35-64 · 65+` su **tutto** l'arco — coerente.
ATTENZIONE: la tavola 13 (per paese) usa invece `0-24 · 25-39 · 40-64 · 65+`.
Le due classificazioni **non vanno mescolate**. (E la tavola 16 cambia
classi nel 2016, da 25-39 a 25-34: rottura di serie.)

**5. Il falso amico: la tavola 16 («_int») NON è l'estero.**
La tavola 16 ha i totali nazionali iscritti e cancellati che **coincidono al
numero esatto, ogni anno**. È la prova che è migrazione **interregionale**
(Sud→Nord *dentro* l'Italia): un sistema chiuso conserva i totali. Il suffisso
`_int` vuol dire **interno**, non internazionale. Non usarla per la fuga
all'estero. La verifica di quadratura nello script (`assert iscritti != cancellati`)
serve proprio a non confondersi: se scatta, è il file sbagliato.

---

## Cosa contiene la tabella in Magazzino

`fuga_cervelli_regioni` — formato lungo, 2.001 righe:

| colonna | valori |
|---|---|
| `territorio` | 20 regioni + `Italia` (ricostruita) |
| `tipo` | `iscritti` (rientri dall'estero) · `cancellati` (partenze per l'estero) |
| `classe_eta` | `0-24` · `25-34` · `35-64` · `65+` |
| `anno` | 2013–2024 |
| `valore` | numero di laureati |

**Saldo netto** = `cancellati − iscritti` (positivo = fuga netta).
Numeri-chiave di controllo (Italia): giovani 25-34, saldo netto **+6.047 (2013)
→ +20.706 (2024)**; tutte le età, saldo netto **+30.503 (2024)**.

## Come rigenerare

```
SRC_DIR="<cartella con tavola10_serie_istr.xlsx>" \
OUT_DIR="." \
ISTAT_DB="/tmp/estint/istat.db" \
python3 build_fuga_cervelli.py
```

Lo script è autoportante: legge il grezzo, ricostruisce, verifica la quadratura,
scrive il CSV e carica la tabella. La tavola 13 (per paese) **non** entra in
Magazzino — vedi nota nello script.
