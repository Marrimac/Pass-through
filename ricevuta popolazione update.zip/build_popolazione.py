#!/usr/bin/env python3
# ============================================================================
#  build_popolazione.py — RICETTA (Ricevuta CSD, 09/07/2026)
#  Prodotta DAL Magazzino certificato. Ricarica e RIVERIFICA.
#
#  E' la TABELLA-MADRE: porta le ancore [K7] e le sentinelle [K6].
#  Ha la GIUNTURA 2018|2019 fra due fonti ISTAT diverse (RIC2011 / POPRES1).
#
#  ⚠ DIFETTO NOTO [F13]: 72 righe hanno valore=0 (24 comune-anno x 3 sessi).
#    Uno zero significa "il comune non esisteva", non "zero abitanti".
#    Nelle quadrature a livello comunale: escludere  valore > 0.
#
#  [K9] · [P3.B] dtype+indici · [T15] chiave TEXT · [T30] anno INTEGER
#  USO:   python3 build_popolazione.py
#  Prova: ISTAT_DB=/tmp/test.db python3 build_popolazione.py
#  Exit:  0 = verde · 1 = rosso
# ============================================================================
import sqlite3, pandas as pd, os, sys

RECEIPT = os.environ.get("RECEIPT", "popolazione.csv.gz")
DB      = os.environ.get("ISTAT_DB", "istat.db")
RIGHE, CODICI = 627_861, 8_128
ANNI    = list(range(2001, 2027))
LIVELLI = ['Italia','comune','provincia','regione','ripartizione']
G_MF    = 209_287
# la giuntura
RIC2011 = (2001, 2018, 434_754)
POPRES1 = (2019, 2026, 193_107)
# sentinelle [K6]
SENTINELLE = {("097035",2025):747, ("083041",2025):12_766, ("ITC43",2026):334_211}
# ancore [K7]
ANCORE = {2021:59_236_213, 2022:59_030_133, 2023:58_997_201}
# [F13] righe con valore=0: NON sono "zero abitanti", sono "il comune non esisteva"
ZERI_RIGHE, ZERI_COMUNI = 72, 7

print(f"RECEIPT: {RECEIPT}\nDB:      {DB}\n")
if not os.path.exists(RECEIPT): print(f"MANCA {RECEIPT}"); sys.exit(1)

df = pd.read_csv(RECEIPT, dtype={"codice":str,"nome":str,"livello":str,
                                 "sesso":str,"fonte":str},
                 keep_default_na=False, na_values=[])
df["anno"]   = df.anno.astype(int)
df["valore"] = df.valore.astype(float)

con = sqlite3.connect(DB)
con.execute("DROP TABLE IF EXISTS popolazione")
con.execute("""CREATE TABLE popolazione(
  codice TEXT, nome TEXT, livello TEXT, anno INTEGER,
  sesso TEXT, valore REAL, fonte TEXT)""")
df.to_sql("popolazione", con, if_exists="append", index=False)
con.execute("CREATE INDEX idx_pop_cod ON popolazione(codice)")
con.execute("CREATE INDEX idx_pop_key ON popolazione(codice,anno,sesso)")
con.commit()
print(f"caricate {len(df):,} righe · indici creati\n")

ok=True
def prova(nome, cond, det=""):
    global ok; ok &= bool(cond)
    print(f"  [{'VERDE' if cond else 'ROSSO'}] {nome}{' — '+det if det else ''}")

print("PROVE")
r=con.execute("SELECT COUNT(*) FROM popolazione").fetchone()[0]
prova("righe", r==RIGHE, f"{r:,}")
c=con.execute("SELECT COUNT(DISTINCT codice) FROM popolazione").fetchone()[0]
prova("codici", c==CODICI, f"{c:,} (tutti i livelli)")
a=[x[0] for x in con.execute("SELECT DISTINCT anno FROM popolazione ORDER BY anno")]
prova("anni 2001-2026", a==ANNI, f"{len(a)} anni")
lv=sorted(x[0] for x in con.execute("SELECT DISTINCT livello FROM popolazione"))
prova("5 livelli", lv==LIVELLI, str(lv))

prova("typeof(codice)='text' [T15]",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(codice) FROM popolazione")]==["text"])
prova("typeof(anno)='integer' [T30]",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(anno) FROM popolazione")]==["integer"])
z=con.execute("SELECT COUNT(DISTINCT codice) FROM popolazione WHERE codice LIKE '00%'").fetchone()[0]
prova("zeri iniziali conservati", z>0, f"{z} comuni")
nm=con.execute("SELECT nome FROM popolazione WHERE codice='001168' LIMIT 1").fetchone()
prova("sentinella K9: 001168 = 'None'", bool(nm) and nm[0]=="None", repr(nm[0] if nm else None))

# LA GIUNTURA 2018|2019 — due fonti ISTAT, nessuna sovrapposizione
for fonte, (y0, y1, nr) in [("RIC2011", RIC2011), ("POPRES1", POPRES1)]:
    q=con.execute("SELECT MIN(anno), MAX(anno), COUNT(*) FROM popolazione WHERE fonte=?",(fonte,)).fetchone()
    prova(f"giuntura: {fonte} copre {y0}-{y1}", q==(y0,y1,nr), f"{q[0]}-{q[1]}, {q[2]:,} righe")
ov=con.execute("""SELECT COUNT(*) FROM (SELECT anno FROM popolazione
  GROUP BY anno HAVING COUNT(DISTINCT fonte)>1)""").fetchone()[0]
prova("nessun anno con DUE fonti (giuntura netta)", ov==0, f"{ov} anni sovrapposti")

# SALDATURA: M+F=T
q="""SELECT COUNT(*), SUM(ABS(d)>0.001) FROM (
  SELECT codice,anno,
    SUM(CASE sesso WHEN 'maschi'  THEN valore
                   WHEN 'femmine' THEN valore
                   WHEN 'totale'  THEN -valore END) AS d
  FROM popolazione GROUP BY codice,anno HAVING COUNT(DISTINCT sesso)=3)"""
n,b = con.execute(q).fetchone()
prova("saldatura M + F = T", n==G_MF and (b or 0)==0, f"{n:,} gruppi completi, {b or 0} eccezioni")

# SALDATURA TERRITORIALE
print("  saldatura territoriale:")
for anno in (2001, 2019, 2024, 2026):
    sp=con.execute("""SELECT SUM(valore) FROM popolazione
      WHERE livello='provincia' AND sesso='totale' AND anno=?""",(anno,)).fetchone()[0]
    sc=con.execute("""SELECT SUM(valore) FROM popolazione
      WHERE livello='comune' AND sesso='totale' AND anno=?""",(anno,)).fetchone()[0]
    sr=con.execute("""SELECT SUM(valore) FROM popolazione
      WHERE livello='regione' AND codice<>'ITDA' AND sesso='totale' AND anno=?""",(anno,)).fetchone()[0]
    it=con.execute("SELECT valore FROM popolazione WHERE codice='IT' AND sesso='totale' AND anno=?",(anno,)).fetchone()[0]
    prova(f"  {anno}: Sigma province == Sigma comuni == Sigma 21 regioni == Italia",
          abs(sp-it)<0.5 and abs(sc-it)<0.5 and abs(sr-it)<0.5, f"{it:,.0f}")

# SENTINELLE [K6]
print("  sentinelle [K6]:")
for (cod, anno), att in SENTINELLE.items():
    v=con.execute("SELECT valore FROM popolazione WHERE codice=? AND anno=? AND sesso='totale'",(cod,anno)).fetchone()
    prova(f"  {cod} {anno} = {att:,}", v and abs(v[0]-att)<0.5, f"{v[0]:,.0f}" if v else "assente")

# [F13] PROVA NEGATIVA: i 24 zeri (x3 sessi = 72 righe) devono esserci, ESATTI.
# Uno zero significa "il comune non esisteva quell'anno", non "zero abitanti".
z=con.execute("SELECT COUNT(*) FROM popolazione WHERE valore=0").fetchone()[0]
zc=con.execute("SELECT COUNT(DISTINCT codice) FROM popolazione WHERE valore=0").fetchone()[0]
prova(f"[F13] {ZERI_RIGHE} righe a ZERO su {ZERI_COMUNI} comuni (prova negativa)",
      z==ZERI_RIGHE and zc==ZERI_COMUNI, f"{z} righe, {zc} comuni")
print("       (comuni NATI dopo: 001316 Mappano, 015250 Baranzate.")
print("        comuni SOPPRESSI nel 2023: 005079 005110 012009 012018 012095.")
print("        Moransengo: 186 abitanti nel 2022, 0 nel 2023. Lo zero NON e' un dato.)")

# ANCORE [K7]
print("  ancore [K7] — popolazione Italia:")
for anno, att in ANCORE.items():
    v=con.execute("SELECT valore FROM popolazione WHERE codice='IT' AND anno=? AND sesso='totale'",(anno,)).fetchone()
    prova(f"  Italia {anno} = {att:,}", v and abs(v[0]-att)<0.5, f"{v[0]:,.0f}" if v else "assente")

con.close()
print("\nESITO:", "VERDE — popolazione certificato" if ok else "ROSSO — NON usare")
sys.exit(0 if ok else 1)
