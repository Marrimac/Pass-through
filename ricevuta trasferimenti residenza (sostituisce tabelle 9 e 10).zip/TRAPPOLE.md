# TRAPPOLE — Set «Trasferimenti di residenza» (ISTAT / ANPR)

Ricevuta **unica per set**. Copre tutte le tabelle di questo set montate in
Magazzino con fatica. Le tavole condividono la stessa struttura ostica: la
fatica vera è stata decifrarla una volta, e questa nota la congela per sempre.

Fonte: ISTAT, *Trasferimenti di residenza* — Migrazioni interne e
internazionali della popolazione residente (registro ANPR), arco 2002–2024
(le tavole per istruzione/età/sesso: 2013–2024, provvisorie).

## Tabelle del set attualmente in Magazzino

| tabella db | tavola | dimensione di dettaglio | righe |
|---|---|---|---|
| `fuga_cervelli_regioni`   | Tavola 10 | classe d'età (0-24, 25-34, 35-64, 65+) | 2.001 |
| `emig_istruzione_regioni` | Tavola 9  | livello istruzione (basso, medio, alto) | 1.512 |

Entrambe: cittadini **italiani**, flussi **da e per l'estero**, per **regione**
(+ Italia ricostruita), distinti in `iscritti` (rientri) e `cancellati` (partenze).

---

## Le cinque trappole del set

**1. La riga «Italia» del file è CORROTTA.**
Riporta lo stesso numero — il totale degli *iscritti* — in **entrambi** i
blocchi (iscritti e cancellati). Usarla darebbe saldo netto zero (assurdo).
=> **Italia va RICOSTRUITA sommando le 20 regioni**, separatamente per iscritti
e cancellati. (Funzione `normalizza`, accumulo `italia`.)

**2. Doppio blocco verticale ISCRITTI / CANCELLATI.**
Due blocchi impilati che condividono le stesse colonne: ISCRITTI sopra
(righe ~4-26), CANCELLATI sotto (~31-53). Vanno letti distinti e marcati `tipo`.

**3. Sub-righe Bolzano/Trento da NON doppiare.**
"Bolzano/Bozen" e "Trento" sono **componenti** di "Trentino-Alto Adige".
Nella somma delle regioni vanno **escluse** (`SUBROWS`).

**4. Colonna «totale» (solo tavole per istruzione).**
La tavola 9 (e le sue sorelle per istruzione) ha, per ogni anno, le colonne
`basso . medio . alto . totale`. La colonna **`totale`** è la somma delle altre
tre: va **esclusa** dalla normalizzazione, o si conta due volte. (Filtro
`dim_validi`.) Le tavole per età non hanno questa colonna.

**5. Il falso amico: le tavole «_int» sono INTERNE, non estere.**
Le tavole con suffisso `_int` (es. Tavola 16) sono migrazione **interregionale**
(Sud->Nord *dentro* l'Italia). Prova: i loro totali nazionali iscritti e
cancellati **coincidono al numero esatto, ogni anno** - un sistema chiuso
conserva i totali. `_int` = **interno**, non internazionale. NON usarle per la
fuga all'estero.
=> La **quadratura-spia** nello script (`assert iscritti != cancellati`) scatta
proprio se per errore si dà in pasto una tavola interna: è la rete di sicurezza.

---

## Numeri-chiave di controllo (Italia)

- `fuga_cervelli_regioni` (laureati, 25-34): saldo netto (cancellati-iscritti)
  **+6.047 (2013) -> +20.706 (2024)**; tutte le età, **+30.503 (2024)**.
- `emig_istruzione_regioni`: quota a istruzione **alta** fra i cancellati
  **23,8% (2013) -> 31,7% (2024)**; fra gli iscritti **24,3% (2024)**.

## Cosa NON entra in Magazzino (e perché)

- **Tavole per paese** (T13 laureati/età, T12 istruzione): i totali non
  riconciliano con le tavole per regione (struttura asimmetrica, aggregati
  continentali mescolati ai paesi). Si usano solo in lettura per la *classifica*
  delle destinazioni, mai come conteggi assoluti.
- **Tavole «_int»** (interregionali): vedi trappola 5. Materiale per un'eventuale
  analisi futura del divario Sud->Nord, non per la fuga all'estero.

## Come rigenerare l'intero set

```
SRC_DIR="<cartella con le tavole grezze>" \
OUT_DIR="." \
ISTAT_DB="/tmp/estint/istat.db" \
python3 build_trasferimenti_residenza.py
```

Per aggiungere altre tavole del set in futuro, basta estendere la lista
`TABELLE` in fondo allo script (tavola, file, nome db, dimensione, valori).
