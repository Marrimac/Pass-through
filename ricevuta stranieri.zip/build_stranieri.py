#!/usr/bin/env python3
# ============================================================================
#  build_stranieri.py — RICETTA (Ricevuta CSD, 09/07/2026)
#  Prodotta DAL Magazzino certificato. Ricarica e RIVERIFICA.
#
#  ⚠ Questa tabella ha un DIFETTO NOTO della fonte, non del set:
#    in 3 anni  Sigma comuni > Italia,  perche' i comuni nati da FUSIONE
#    sono esposti INSIEME ai loro predecessori. Vedi [F3]. NON si corregge.
#
#  [K9] · [P3.B] dtype+indici · [T15] chiave TEXT · [T30] anno INTEGER
#  USO:   python3 build_stranieri.py
#  Prova: ISTAT_DB=/tmp/test.db python3 build_stranieri.py
#  Exit:  0 = verde · 1 = rosso
# ============================================================================
import sqlite3, pandas as pd, os, sys

RECEIPT = os.environ.get("RECEIPT", "stranieri.csv.gz")
DB      = os.environ.get("ISTAT_DB", "istat.db")
RIGHE, CODICI = 193_155, 8_128
ANNI    = list(range(2019, 2027))
LIVELLI = ['Italia','comune','provincia','regione','ripartizione']
G_MF    = 64_385
# [F3] i tre Delta ATTESI su Sigma comuni: sono la fonte, non un difetto nostro
DELTA_COMUNI = {2019: 6_983, 2020: 838, 2022: 218}
# sentinelle del collaudo Estintore
SENTINELLE = {("097035",2025):36, ("ITC4",2024):1_203_138, ("IT",2024):5_253_658}

print(f"RECEIPT: {RECEIPT}\nDB:      {DB}\n")
if not os.path.exists(RECEIPT): print(f"MANCA {RECEIPT}"); sys.exit(1)

df = pd.read_csv(RECEIPT, dtype={"codice":str,"nome":str,"livello":str,
                                 "sesso":str,"fonte":str},
                 keep_default_na=False, na_values=[])
df["anno"]   = df.anno.astype(int)
df["valore"] = df.valore.astype("int64")     # INTEGER, non REAL

con = sqlite3.connect(DB)
con.execute("DROP TABLE IF EXISTS stranieri")
con.execute("""CREATE TABLE stranieri(
  codice TEXT, nome TEXT, livello TEXT, anno INTEGER,
  sesso TEXT, valore INTEGER, fonte TEXT)""")
df.to_sql("stranieri", con, if_exists="append", index=False)
con.execute("CREATE INDEX idx_str_cod ON stranieri(codice)")
con.execute("CREATE INDEX idx_str_key ON stranieri(codice,anno,sesso)")
con.commit()
print(f"caricate {len(df):,} righe · indici creati\n")

ok=True
def prova(nome, cond, det=""):
    global ok; ok &= bool(cond)
    print(f"  [{'VERDE' if cond else 'ROSSO'}] {nome}{' — '+det if det else ''}")

print("PROVE")
r=con.execute("SELECT COUNT(*) FROM stranieri").fetchone()[0]
prova("righe", r==RIGHE, f"{r:,}")
c=con.execute("SELECT COUNT(DISTINCT codice) FROM stranieri").fetchone()[0]
prova("codici", c==CODICI, f"{c:,} (tutti i livelli)")
a=[x[0] for x in con.execute("SELECT DISTINCT anno FROM stranieri ORDER BY anno")]
prova("anni 2019-2026", a==ANNI, f"{len(a)} anni")
lv=sorted(x[0] for x in con.execute("SELECT DISTINCT livello FROM stranieri"))
prova("5 livelli", lv==LIVELLI, str(lv))
f=[x[0] for x in con.execute("SELECT DISTINCT fonte FROM stranieri")]
prova("fonte unica POPSTRRES1 (nessuna giuntura)", f==["POPSTRRES1"], str(f))

prova("typeof(codice)='text' [T15]",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(codice) FROM stranieri")]==["text"])
prova("typeof(anno)='integer' [T30]",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(anno) FROM stranieri")]==["integer"])
prova("typeof(valore)='integer' (non REAL)",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(valore) FROM stranieri")]==["integer"])
z=con.execute("SELECT COUNT(DISTINCT codice) FROM stranieri WHERE codice LIKE '00%'").fetchone()[0]
prova("zeri iniziali conservati", z>0, f"{z} comuni")
nm=con.execute("SELECT nome FROM stranieri WHERE codice='001168' LIMIT 1").fetchone()
prova("sentinella K9: 001168 = 'None'", bool(nm) and nm[0]=="None", repr(nm[0] if nm else None))

# SALDATURA: M+F=T
q="""SELECT COUNT(*), SUM(ABS(d)>0.001) FROM (
  SELECT codice,anno,
    SUM(CASE sesso WHEN 'maschi'  THEN valore
                   WHEN 'femmine' THEN valore
                   WHEN 'totale'  THEN -valore END) AS d
  FROM stranieri GROUP BY codice,anno HAVING COUNT(DISTINCT sesso)=3)"""
n,b = con.execute(q).fetchone()
prova("saldatura M + F = T", n==G_MF and (b or 0)==0, f"{n:,} gruppi completi, {b or 0} eccezioni")

# SALDATURA TERRITORIALE: province e 21 regioni reggono SEMPRE
print("  saldatura territoriale (province e 21 regioni: reggono sempre):")
for anno in (2019, 2024, 2026):
    sp=con.execute("""SELECT SUM(valore) FROM stranieri
      WHERE livello='provincia' AND sesso='totale' AND anno=?""",(anno,)).fetchone()[0]
    sr=con.execute("""SELECT SUM(valore) FROM stranieri
      WHERE livello='regione' AND codice<>'ITDA' AND sesso='totale' AND anno=?""",(anno,)).fetchone()[0]
    it=con.execute("SELECT valore FROM stranieri WHERE codice='IT' AND sesso='totale' AND anno=?",(anno,)).fetchone()[0]
    prova(f"  {anno}: Sigma province == Sigma 21 regioni == Italia",
          abs(sp-it)<0.5 and abs(sr-it)<0.5, f"{it:,}")

# [F3] Sigma comuni: i tre Delta sono ATTESI. Verificarli ESATTAMENTE.
print("  [F3] Sigma comuni: 3 anni sforano, per FUSIONI comunali della fonte:")
for anno in ANNI:
    sc=con.execute("""SELECT SUM(valore) FROM stranieri
      WHERE livello='comune' AND sesso='totale' AND anno=?""",(anno,)).fetchone()[0]
    it=con.execute("SELECT valore FROM stranieri WHERE codice='IT' AND sesso='totale' AND anno=?",(anno,)).fetchone()[0]
    d = sc - it
    att = DELTA_COMUNI.get(anno, 0)
    prova(f"  {anno}: Sigma comuni - Italia = {att:+,} (atteso)", d==att, f"{d:+,}")
print("       (i comuni nati da FUSIONE sono esposti INSIEME ai predecessori:")
print("        16 comuni nuovi nel 2019 valgono esattamente 6.983 stranieri.")
print("        NON e' un difetto del set: e' la fonte. Usare Sigma province.)")

# SENTINELLE
print("  sentinelle (collaudo Estintore):")
for (cod, anno), att in SENTINELLE.items():
    v=con.execute("SELECT valore FROM stranieri WHERE codice=? AND anno=? AND sesso='totale'",(cod,anno)).fetchone()
    prova(f"  {cod} {anno} = {att:,}", v and v[0]==att, f"{v[0]:,}" if v else "assente")

con.close()
print("\nESITO:", "VERDE — stranieri certificato" if ok else "ROSSO — NON usare")
sys.exit(0 if ok else 1)
