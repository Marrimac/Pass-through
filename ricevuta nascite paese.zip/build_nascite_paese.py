#!/usr/bin/env python3
# ============================================================================
#  build_nascite_paese.py — RICETTA (Ricevuta CSD, 09/07/2026)
#  Prodotta DAL Magazzino certificato. Ricarica e RIVERIFICA.
#
#  ⚠ SENTINELLA CRITICA [K9]: la Namibia ha codice ISO 'NA'.
#    Senza keep_default_na=False, pandas lo trasforma in NaN e la CHIAVE
#    sparisce: join e somme per paese si rompono in silenzio.
#
#  [P3.B] dtype+indici · [T15] chiave TEXT · [T30] anno INTEGER
#  USO:   python3 build_nascite_paese.py
#  Prova: ISTAT_DB=/tmp/test.db python3 build_nascite_paese.py
#  Exit:  0 = verde · 1 = rosso
# ============================================================================
import sqlite3, pandas as pd, os, sys

RECEIPT = os.environ.get("RECEIPT", "nascite_paese.csv.gz")
DB      = os.environ.get("ISTAT_DB", "istat.db")
RIGHE, CODICI, PAESI = 158_790, 30, 204
ANNI    = list(range(1999, 2025))
LIVELLI = ['Italia','regione','ripartizione']
NA_RIGHE = 780                       # Namibia
G_ITDA   = 5_293                     # ITDA = ITD1 + ITD2
# ancore: Sigma 21 regioni (senza ITDA) == Italia == nati stranieri
ANCORE = {1999: 21_186, 2010: 78_082, 2024: 50_593}

print(f"RECEIPT: {RECEIPT}\nDB:      {DB}\n")
if not os.path.exists(RECEIPT): print(f"MANCA {RECEIPT}"); sys.exit(1)

# [K9] OBBLIGATORIO: 'NA' (Namibia) e' una CHIAVE, non un valore mancante
df = pd.read_csv(RECEIPT, dtype={"codice":str,"nome":str,"livello":str,
                                 "paese_cod":str,"paese":str},
                 keep_default_na=False, na_values=[])
df["anno"]   = df.anno.astype(int)
df["valore"] = df.valore.astype(float)

# controllo IMMEDIATO: se [K9] fallisse, qui la Namibia sarebbe gia' persa
_na = (df.paese_cod == "NA").sum()
if _na != NA_RIGHE:
    print(f"ERRORE [K9]: Namibia 'NA' = {_na} righe (attese {NA_RIGHE}).")
    print("  keep_default_na=False mancante? la CHIAVE e' stata mangiata.")
    sys.exit(1)

con = sqlite3.connect(DB)
con.execute("DROP TABLE IF EXISTS nascite_paese")
con.execute("""CREATE TABLE nascite_paese(
  codice TEXT, nome TEXT, livello TEXT, anno INTEGER,
  paese_cod TEXT, paese TEXT, valore REAL)""")
df.to_sql("nascite_paese", con, if_exists="append", index=False)
con.execute("CREATE INDEX idx_np_cod   ON nascite_paese(codice)")
con.execute("CREATE INDEX idx_np_paese ON nascite_paese(paese_cod)")
con.execute("CREATE INDEX idx_np_key   ON nascite_paese(codice,anno,paese_cod)")
con.commit()
print(f"caricate {len(df):,} righe · indici creati\n")

ok=True
def prova(nome, cond, det=""):
    global ok; ok &= bool(cond)
    print(f"  [{'VERDE' if cond else 'ROSSO'}] {nome}{' — '+det if det else ''}")

print("PROVE")
r=con.execute("SELECT COUNT(*) FROM nascite_paese").fetchone()[0]
prova("righe", r==RIGHE, f"{r:,}")
c=con.execute("SELECT COUNT(DISTINCT codice) FROM nascite_paese").fetchone()[0]
prova("codici", c==CODICI, f"{c} (Italia + 22 regioni + 7 ripartizioni)")
a=[x[0] for x in con.execute("SELECT DISTINCT anno FROM nascite_paese ORDER BY anno")]
prova("anni 1999-2024", a==ANNI, f"{len(a)} anni")
lv=sorted(x[0] for x in con.execute("SELECT DISTINCT livello FROM nascite_paese"))
prova("3 livelli (MAI province, MAI comuni)", lv==LIVELLI, str(lv))
p=con.execute("SELECT COUNT(DISTINCT paese_cod) FROM nascite_paese").fetchone()[0]
prova("204 paesi", p==PAESI, f"{p} (198 ISO + 6 speciali)")

prova("typeof(codice)='text' [T15]",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(codice) FROM nascite_paese")]==["text"])
prova("typeof(anno)='integer' [T30]",
      [x[0] for x in con.execute("SELECT DISTINCT typeof(anno) FROM nascite_paese")]==["integer"])

# SENTINELLA K9 — la piu' importante di questo set
na=con.execute("SELECT COUNT(*) FROM nascite_paese WHERE paese_cod='NA'").fetchone()[0]
prova("SENTINELLA [K9]: Namibia 'NA' viva (e' la CHIAVE)", na==NA_RIGHE, f"{na} righe")
nm=con.execute("SELECT paese FROM nascite_paese WHERE paese_cod='NA' LIMIT 1").fetchone()
prova("  ...e si chiama 'Namibia'", bool(nm) and nm[0]=="Namibia", repr(nm[0] if nm else None))
vuoti=con.execute("SELECT COUNT(*) FROM nascite_paese WHERE paese_cod='' OR paese_cod='nan'").fetchone()[0]
prova("nessun paese_cod vuoto/nan", vuoti==0, f"{vuoti}")

# SALDATURA TERRITORIALE [S1]: Sigma 21 regioni == Italia (ITDA escluso!)
print("  saldatura territoriale [S1] — Sigma 21 regioni (senza ITDA) == Italia:")
for anno, att in ANCORE.items():
    sr=con.execute("""SELECT SUM(valore) FROM nascite_paese
      WHERE livello='regione' AND codice<>'ITDA' AND anno=?""",(anno,)).fetchone()[0]
    it=con.execute("SELECT SUM(valore) FROM nascite_paese WHERE codice='IT' AND anno=?",(anno,)).fetchone()[0]
    prova(f"  {anno}: Sigma21 == Italia == {att:,}",
          abs(sr-it)<0.5 and abs(sr-att)<0.5, f"{sr:,.0f}")

# ITDA = ITD1 + ITD2 (il Trentino compare due volte: e' [S1])
q="""SELECT COUNT(*), SUM(ABS(d)>0.001) FROM (
  SELECT anno, paese_cod,
    SUM(CASE codice WHEN 'ITDA' THEN valore ELSE 0 END)
  - SUM(CASE codice WHEN 'ITD1' THEN valore ELSE 0 END)
  - SUM(CASE codice WHEN 'ITD2' THEN valore ELSE 0 END) AS d
  FROM nascite_paese WHERE codice IN ('ITDA','ITD1','ITD2')
  GROUP BY anno, paese_cod HAVING COUNT(DISTINCT codice)=3)"""
n,b = con.execute(q).fetchone()
prova("ITDA = ITD1 + ITD2 (Trentino: regione E due province) [S1]",
      n==G_ITDA and (b or 0)==0, f"{n:,} gruppi, {b or 0} eccezioni")

# CONFRONTO ESTERNO: Sigma paesi == nascite.stranieri
if con.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='nascite'").fetchone()[0]:
    q2="""SELECT COUNT(*), SUM(ABS(d)>0.001) FROM (
      SELECT np.codice, np.anno, SUM(np.valore) - MAX(n.valore) AS d
      FROM nascite_paese np JOIN nascite n
        ON n.codice=np.codice AND n.anno=np.anno
       AND n.gruppo='stranieri' AND n.sesso='totale'
      GROUP BY np.codice, np.anno)"""
    n2,b2 = con.execute(q2).fetchone()
    prova("Sigma paesi == nascite.stranieri (NON esiste WORLD interno)",
          (b2 or 0)==0, f"{n2:,} gruppi, {b2 or 0} eccezioni")
else:
    print("  [nota] `nascite` assente: saldatura esterna non verificabile")
    print("         (il totale NON e' nel set: Sigma paesi == nascite.stranieri)")

con.close()
print("\nESITO:", "VERDE — nascite_paese certificato" if ok else "ROSSO — NON usare")
sys.exit(0 if ok else 1)
