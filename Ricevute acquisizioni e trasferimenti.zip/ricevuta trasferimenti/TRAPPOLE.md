# TRAPPOLE — Trasferimenti di residenza (ISTAT / ANPR)

**Versione CSD del 09/07/2026.** Rifatta leggendo i **grezzi Excel**, che sono
l'autorità. Sostituisce i tre `TRAPPOLE.md` precedenti — e ne **recupera** ciò
che avevano perduto.

> ⚠⚠ **AVVERTENZA SUI DOCUMENTI PRECEDENTI.**
> Esistevano tre Ricevute di questo set, ognuna che «sostituiva» la precedente:
> *«sostituisce solo tavola 10»* → *«sostituisce tabelle 9 e 10»* → *«sostituisce 7,8,9,10»*.
> Ogni volta il `TRAPPOLE.md` è stato **riscritto da capo**, non esteso.
> **La trappola 4 è stata sovrascritta**, e con essa un'informazione che non
> compare più in nessun documento successivo (vedi § «Recuperato»).
> **Tre di quei documenti dichiarano una trappola che NON ESISTE** (§ FALSE).

---

## La fonte

ISTAT, *Trasferimenti di residenza* — Migrazioni interne e internazionali della
popolazione residente (registro **ANPR**).

| tavola | titolo (dal grezzo) | arco |
|---|---|---|
| **T7** | Cittadini **stranieri iscritti** dall'estero, per paese | 2002–2024 |
| **T8** | Cittadini **stranieri cancellati** per l'estero, per paese | 2002–2024 |
| **T9** | Cittadini **italiani** iscritti/cancellati per l'estero, per regione e **istruzione** | 2013–2024 (provv.) |
| **T10** | Cittadini italiani **LAUREATI** iscritti/cancellati per l'estero, per regione e **età** | 2013–2024 (provv.) |

---

## Le tabelle in Magazzino

```
migrazioni_italiani(codice, nome, tipo, anno, dimensione, categoria, valore)
    dimensione ∈ {istruzione, eta_laureati}      3.513 righe · 21 territori
migrazioni_stranieri(paese, livello, tipo, anno, valore)
    livello ∈ {totale, continente, partizione_ue, paese}   1.376 righe
```

Due tabelle e non quattro: **T9 e T10 hanno la stessa chiave** `(territorio, tipo, anno)`
e una è la **scomposizione** dell'altra (vedi § L'ALBERO). T7/T8 hanno chiave
`paese`, popolazione diversa (stranieri), arco diverso: **non si condensano**.

---

## ⚠⚠ FALSE — trappole dichiarate dai documenti precedenti, che NON esistono

### «La riga Italia è CORROTTA»

I tre documenti affermano:
> *«La riga Italia riporta lo stesso numero — il totale degli iscritti — in
> entrambi i blocchi. Usarla darebbe saldo netto zero (assurdo). Va RICOSTRUITA
> sommando le 20 regioni.»*

**VERIFICATO SUI GREZZI: la riga Italia è GIUSTA.**

```
T10:  Italia ISCRITTI  ≠ Σ 20 regioni:   0 colonne su 48
      Italia CANCELLATI ≠ Σ 20 regioni:   0 colonne su 48
      colonne dove ISCRITTI == CANCELLATI:  0

T9:   0 su 57.  Stesso esito.

Italia 2013, T10:
  ISCRITTI     223 · 2017 · 3605 ·  519
  CANCELLATI   441 · 8064 · 10213 · 803      ← diverse
```

Tre builder ricostruivano l'Italia per un difetto che **non esiste**. Ottenevano
il numero giusto **per la ragione sbagliata**, e nessuno se n'era accorto perché
il risultato coincide.

### «Le tavole per nazionalità non contengono un totale nazionale»

**FALSO.** T7 e T8 hanno una riga **`Totale`**, ed è esatta:
`Totale == Σ 6 continenti`, 46 celle, **Δ = 0**.

---

## ✔ VERE — verificate sui grezzi

**1. Doppio blocco verticale ISCRITTI / CANCELLATI (T9/T10).**
Due blocchi impilati sulle stesse colonne. **ISCRITTI righe 5–27**, **CANCELLATI
righe 32–54**. Le righe **27** e **54** sono `Italia` (giusta, vedi sopra).

**2. Sub-righe Bolzano/Trento da NON doppiare (T9/T10).**
`Bolzano/Bozen` (righe 9, 36) e `Trento` (10, 37) sono **componenti** di
`Trentino-Alto Adige`. Nella somma vanno **escluse**, o si conta due volte.

**3. Colonna «totale» nelle tavole per istruzione (T9).**
`basso · medio · alto · totale`. La colonna `totale` **è la somma**:
`865 + 441 + 413 = 1719`. Va esclusa.

**4. Aggregati mescolati ai paesi (T7/T8).**
Le tavole elencano, insieme ai 21 paesi:
- **6 continenti**: `Europa` `Africa` `Asia` `America` `Oceania` `Apolidi`
- **4 partizioni UE**: `EU27 (2020)` `Extra EU27 (2020)` `EU28 (2007-2020)` `Extra EU28 (2007-2020)`
- **1 totale**: `Totale`
- separatori `di cui:` (da saltare)

Sommando tutto si conta più volte. **In `migrazioni_stranieri` non sono buttati:
sono marcati con la colonna `livello`.** I builder precedenti li scartavano.

**5. Il falso amico «_int» = INTERNO, non estero.**
Le tavole col suffisso `_int` (T15–T17) sono migrazione **interregionale**
(Sud→Nord *dentro* l'Italia). Prova: i totali nazionali iscritti e cancellati
**coincidono al numero esatto, ogni anno** — un sistema chiuso conserva i totali.
`_int` = **interno**, non internazionale. **Non usarle per la fuga all'estero.**

---

## ⚠ RECUPERATO — la trappola caduta fra la prima e la seconda Ricevuta

Presente **solo** nel primo `TRAPPOLE.md`, sovrascritta quando arrivò la T9,
e mai più ripetuta:

> **Classi d'età: coerenti qui, NON altrove.**
> La **tavola 10** usa `0-24 · 25-34 · 35-64 · 65+` su tutto l'arco — coerente.
> La **tavola 13** (per paese) usa invece `0-24 · **25-39 · 40-64** · 65+`.
> **Le due classificazioni non vanno mescolate.**
> E la **tavola 16 cambia classi nel 2016**, da `25-39` a `25-34`: **rottura di serie.**

L'ultimo documento non nomina nemmeno più le classi d'età.

---

## ⚠⚠ MAI DETTE — scoperte leggendo i grezzi

### L'ALBERO: T10 è la scomposizione dei soli laureati

```
Σ(eta_laureati) == 'alto' di istruzione.   504 gruppi, Δ = 0.

Abruzzo, cancellati, 2013:
  istruzione:    basso 962 · medio 573 · alto 318
  eta_laureati:  0-24 9 · 25-34 133 · 35-64 157 · 65+ 19   →  Σ = 318
```

T10 **non è un dato parallelo**: è la scomposizione per età della categoria
`alto`. Il titolo del grezzo lo dice: *«Cittadini italiani **LAUREATI**…»*.
Nessuno dei tre documenti lo nota.

È la ragione per cui le due tavole stanno in **una** tabella: con due tabelle
separate quella saldatura è invisibile; qui è un `GROUP BY` che il builder
ripete a ogni ricarica.

### I punti: 15 celle con dato assente (T10)

Il grezzo usa **`.`** — la notazione ISTAT per *«dato assente o non
significativo»*. **Non è zero.**

```
Valle d'Aosta  10 celle      Molise  3      Basilicata  2
```

Sono le tre regioni più piccole, sulle classi `0-24` e `65+`. I CSV ereditati
le **scartavano senza registrarle**. Ora sono in `lacune_note`.
T9 non ne ha nessuna.

### Le partizioni UE sono vuote prima del 2024

`Europa == EU27 + Extra EU27 == EU28 + Extra EU28` — ma **solo dal 2024**.
Prima quelle righe sono vuote: **69 celle** in T7 e T8.

### `ITDA` qui NON è l'aggregato di [F7]

Bolzano e Trento sono escluse come sub-righe, quindi il Trentino-Alto Adige è
una **regione vera** e non c'è doppio conteggio. Sono 20 regioni amministrative,
non le 21 del ponte.
Valle d'Aosta va a **`ITC2`** (livello *regione*), non `ITC20` (provincia).

---

## Numeri-chiave di controllo

*(erano giusti nei documenti precedenti: i numeri sì, le trappole no)*

- **Laureati, saldo netto** (`cancellati − iscritti`, positivo = fuga netta), Italia:
  25-34 anni **+6.047 (2013) → +20.706 (2024)**; tutte le età **+30.503 (2024)**.
- **Istruzione**, Italia: quota `alto` fra i cancellati **23,8% (2013) → 31,7% (2024)**;
  fra gli iscritti **24,3% (2024)**.
- **Stranieri, saldo 2024** (`iscritti − cancellati`): Bangladesh **+29.907**,
  Romania **+7.813** (con 15.335 partenze, le più alte: la Romania è UE).

---

## Cosa NON entra in Magazzino (e perché)

- **Tavole italiani per paese** (T12 istruzione, T13 laureati/età): i totali non
  riconciliano con le tavole per regione. **E la T13 usa classi d'età diverse**
  (vedi § Recuperato). Si usano solo in lettura per la *classifica* delle
  destinazioni, mai come conteggi assoluti.
- **Tavole «_int»** (T15–T17, interregionali): vedi trappola 5. Materiale per
  un'analisi del divario Sud→Nord, non per la fuga all'estero.

---

## Come rigenerare

```
SRC_DIR="<cartella coi 4 .xlsx GREZZA>" \
ISTAT_DB="/percorso/istat.db" \
python3 build_trasferimenti.py
```

Il builder **rimonta dai grezzi Excel**, non dai CSV. Ripete 20 prove, fra cui
tre **prove negative** [P4.2]:
- le **15 celle con `.`** devono esserci (se sparissero, il grezzo è cambiato);
- `Italia == Σ 20 regioni` e `ISCRITTI ≠ CANCELLATI` (se un domani coincidessero,
  la «trappola 1» diventerebbe vera);
- `Σ(21 paesi) < Totale` in tutte le 46 celle.

I quattro `.xlsx` sono **dentro questo zip**: sono l'autorità, e senza di loro
il lavoro non si rifà.
