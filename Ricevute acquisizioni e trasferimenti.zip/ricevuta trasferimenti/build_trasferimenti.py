#!/usr/bin/env python3
# ============================================================================
#  build_trasferimenti.py — RICETTA (Ricevuta CSD, 09/07/2026)
#
#  ⚠ RIMONTA DAI GREZZI EXCEL, non dai CSV. Gli Excel sono l'autorita'.
#    I CSV sono l'uscita certificata; i grezzi sono nello zip per rifare tutto.
#
#  ⚠ UNA FONTE (Trasferimenti di residenza / ANPR), 4 TAVOLE, 2 TABELLE. [P4.4]
#
#  ⚠⚠ LA "TRAPPOLA 1" DEI TRE TRAPPOLE.md EREDITATI E' FALSA.
#     Dicono: "la riga Italia e' CORROTTA, va ricostruita sommando le regioni".
#     VERIFICATO: e' GIUSTA. 0 colonne discordanti su 48 (T10) e 57 (T9).
#     Italia 2013: iscritti 223·2017·3605·519  cancellati 441·8064·10213·803.
#     Tre builder la ricostruivano per un difetto che non esiste.
#
#  ⚠⚠ Sigma(eta_laureati) == 'alto' di istruzione. 504 gruppi, Delta=0.
#     T10 e' la SCOMPOSIZIONE PER ETA DEI SOLI LAUREATI. Nessun TRAPPOLE.md
#     lo dice. Il titolo del grezzo si': "Cittadini italiani LAUREATI...".
#
#  TRAPPOLE VERE (verificate sui grezzi):
#    · doppio blocco: ISCRITTI righe 5-27, CANCELLATI 32-54 (27/54 = Italia)
#    · Bolzano/Bozen (9,36) e Trento (10,37): SUB-RIGHE del Trentino, escluse
#    · T9 ha la colonna 'totale' = basso+medio+alto: esclusa
#    · T7/T8: aggregati continentali + partizioni UE + 'di cui:' mescolati
#
#  MAI DETTE dai TRAPPOLE.md:
#    · T10 usa '.' per dato assente: 15 celle (VdA 10, Molise 3, Basilicata 2)
#    · T7/T8 HANNO un 'Totale' (= Sigma 6 continenti, Delta=0)
#    · le partizioni UE sono vuote prima del 2024
#
#  USO:   python3 build_trasferimenti.py
#  Prova: ISTAT_DB=/tmp/test.db python3 build_trasferimenti.py
#  Exit:  0 = verde · 1 = rosso
# ============================================================================
import sqlite3, os, sys, re
import pandas as pd, openpyxl

SRC = os.environ.get("SRC_DIR", ".")
DB  = os.environ.get("ISTAT_DB", "istat.db")
RIGHE_I, RIGHE_S = 3_513, 1_376
TERRITORI = 21
SUBROWS = {"Bolzano/Bozen", "Trento"}
CONTINENTI = ["Europa","Africa","Asia","America","Oceania","Apolidi"]
PARTIZ_UE  = ["EU27 (2020)","Extra EU27 (2020)","EU28 (2007-2020)","Extra EU28 (2007-2020)"]
ASSENTI_T10 = 15                       # prova negativa: i punti DEVONO esserci
G_ALBERO = 504                         # Sigma(eta_laureati) == 'alto'
ANCORE_IT = {(2013,"25-34"):6_047, (2024,"25-34"):20_706}
ANCORE_ST = {"Bangladesh":29_907, "Romania":7_813}
# il ponte non serve: i 21 codici sono qui, verificati
CODICI = {"Piemonte":"ITC1","Valle d'Aosta/Vallée d'Aoste":"ITC2","Lombardia":"ITC4",
  "Trentino-Alto Adige":"ITDA","Veneto":"ITD3","Friuli-Venezia Giulia":"ITD4",
  "Liguria":"ITC3","Emilia-Romagna":"ITD5","Toscana":"ITE1","Umbria":"ITE2",
  "Marche":"ITE3","Lazio":"ITE4","Abruzzo":"ITF1","Molise":"ITF2","Campania":"ITF3",
  "Puglia":"ITF4","Basilicata":"ITF5","Calabria":"ITF6","Sicilia":"ITG1",
  "Sardegna":"ITG2","Italia":"IT"}

print(f"SRC: {SRC}\nDB:  {DB}\n")
def apri(f):
    p = os.path.join(SRC, f)
    if not os.path.exists(p): print(f"MANCA {p}"); sys.exit(1)
    wb = openpyxl.load_workbook(p, data_only=True)
    return wb[wb.sheetnames[0]]

def cella(ws,r,c):
    v = ws.cell(r,c).value
    if v is None: return None,"vuota"
    if isinstance(v,str) and v.strip()==".": return None,"punto"
    if isinstance(v,(int,float)): return float(v),None
    return None,"altro"

def leggi_regioni(file, escludi=()):
    ws = apri(file)
    anni = {}
    anno = None
    for c in range(2, ws.max_column+1):
        a = ws.cell(2,c).value
        if isinstance(a,int): anno = a
        d = ws.cell(3,c).value
        if d and anno: anni[c] = (anno, str(d).strip())
    righe, assenti = [], []
    for tipo, r0, r1 in [("iscritti",5,27), ("cancellati",32,54)]:
        for r in range(r0, r1+1):
            nome = ws.cell(r,1).value
            if not nome: continue
            nome = str(nome).strip()
            if nome in SUBROWS: continue
            for c,(a,dim) in anni.items():
                if dim in escludi: continue
                v, mark = cella(ws,r,c)
                if v is None:
                    if mark=="punto": assenti.append((nome,tipo,a,dim))
                    continue
                righe.append((nome, tipo, a, dim, v))
    return righe, assenti

def leggi_paesi(file, tipo):
    ws = apri(file)
    anni = {c: ws.cell(2,c).value for c in range(2,ws.max_column+1)
            if isinstance(ws.cell(2,c).value,int)}
    out = []
    for r in range(4, ws.max_row+1):
        nome = ws.cell(r,1).value
        if not nome: continue
        nome = str(nome).strip()
        if nome == "di cui:": continue
        liv = ("continente" if nome in CONTINENTI else
               "partizione_ue" if nome in PARTIZ_UE else
               "totale" if nome=="Totale" else "paese")
        for c,a in anni.items():
            v,_ = cella(ws,r,c)
            if v is not None: out.append((nome, liv, tipo, a, v))
    return out

r9,  a9  = leggi_regioni("tavola9_serie_istr_GREZZA.xlsx",  escludi=("totale",))
r10, a10 = leggi_regioni("tavola10_serie_istr_GREZZA.xlsx")
I = pd.DataFrame(
  [(CODICI[t], t, tp, int(a), "istruzione", d, v) for t,tp,a,d,v in r9] +
  [(CODICI[t], t, tp, int(a), "eta_laureati", d, v) for t,tp,a,d,v in r10],
  columns=["codice","nome","tipo","anno","dimensione","categoria","valore"])
S = pd.DataFrame(leggi_paesi("tavola7_serie_GREZZA.xlsx","iscritti") +
                 leggi_paesi("tavola8_serie_GREZZA.xlsx","cancellati"),
                 columns=["paese","livello","tipo","anno","valore"])
S["anno"]=S.anno.astype(int)

con = sqlite3.connect(DB)
con.execute("DROP TABLE IF EXISTS migrazioni_italiani")
con.execute("""CREATE TABLE migrazioni_italiani(codice TEXT, nome TEXT, tipo TEXT,
  anno INTEGER, dimensione TEXT, categoria TEXT, valore REAL)""")
I.to_sql("migrazioni_italiani", con, if_exists="append", index=False)
con.execute("CREATE INDEX idx_mi_cod ON migrazioni_italiani(codice)")
con.execute("CREATE INDEX idx_mi_key ON migrazioni_italiani(codice,anno,tipo,dimensione,categoria)")
con.execute("DROP TABLE IF EXISTS migrazioni_stranieri")
con.execute("""CREATE TABLE migrazioni_stranieri(paese TEXT, livello TEXT, tipo TEXT,
  anno INTEGER, valore REAL)""")
S.to_sql("migrazioni_stranieri", con, if_exists="append", index=False)
con.execute("CREATE INDEX idx_ms_key ON migrazioni_stranieri(paese,anno,tipo)")
con.commit()
print(f"caricate {len(I):,} + {len(S):,} righe dai GREZZI · indici creati\n")

ok=True
def prova(n,c,d=""):
    global ok; ok&=bool(c)
    print(f"  [{'VERDE' if c else 'ROSSO'}] {n}{' — '+d if d else ''}")

print("PROVE")
prova("righe italiani", len(I)==RIGHE_I, f"{len(I):,}")
prova("righe stranieri", len(S)==RIGHE_S, f"{len(S):,}")
prova("21 territori (20 regioni + Italia)", I.nome.nunique()==TERRITORI, f"{I.nome.nunique()}")
prova("typeof(codice)='text'", [x[0] for x in con.execute("SELECT DISTINCT typeof(codice) FROM migrazioni_italiani")]==["text"])
prova("typeof(anno)='integer'", [x[0] for x in con.execute("SELECT DISTINCT typeof(anno) FROM migrazioni_italiani")]==["integer"])
prova("Bolzano e Trento ESCLUSI (sub-righe)",
      not {"Bolzano/Bozen","Trento"} & set(I.nome), "")
prova("colonna 'totale' di T9 ESCLUSA",
      sorted(I[I.dimensione=="istruzione"].categoria.unique())==["alto","basso","medio"])

# ⚠ PROVA NEGATIVA: i 15 punti DEVONO esserci
prova(f"PROVA NEGATIVA: T10 ha {ASSENTI_T10} celle con '.' (dato assente)",
      len(a10)==ASSENTI_T10 and len(a9)==0, f"T10={len(a10)} T9={len(a9)}")
reg = sorted({x[0][:14] for x in a10})
print(f"       (sono {reg} — le regioni piu' piccole)")

# ⚠⚠ L'ALBERO
print("\n  L'ALBERO: T10 e' la scomposizione per eta dei soli LAUREATI")
q="""SELECT COUNT(*), SUM(ABS(d)>0.5) FROM (
  SELECT (SELECT SUM(valore) FROM migrazioni_italiani x
      WHERE x.codice=a.codice AND x.anno=a.anno AND x.tipo=a.tipo
        AND x.dimensione='eta_laureati') - a.valore AS d
  FROM migrazioni_italiani a WHERE a.dimensione='istruzione' AND a.categoria='alto')"""
n,b = con.execute(q).fetchone()
prova("  Sigma(eta_laureati) == 'alto'", n==G_ALBERO and (b or 0)==0, f"{n} gruppi, {b or 0} ecc.")

# ⚠⚠ LA TRAPPOLA 1 E' FALSA
print("\n  la 'trappola 1' dei TRAPPOLE.md ereditati e' FALSA:")
for dim in ("istruzione","eta_laureati"):
    q2=f"""SELECT COUNT(*), SUM(ABS(d)>0.5) FROM (
      SELECT (SELECT SUM(valore) FROM migrazioni_italiani x
          WHERE x.anno=a.anno AND x.tipo=a.tipo AND x.categoria=a.categoria
            AND x.dimensione=a.dimensione AND x.codice<>'IT') - a.valore AS d
      FROM migrazioni_italiani a WHERE a.codice='IT' AND a.dimensione='{dim}')"""
    n2,b2 = con.execute(q2).fetchone()
    prova(f"  Italia == Sigma 20 regioni ({dim})", (b2 or 0)==0, f"{n2} celle, {b2 or 0} discordanti")
q3="""SELECT COUNT(*) FROM (SELECT anno,dimensione,categoria,
  MAX(CASE tipo WHEN 'iscritti' THEN valore END) i,
  MAX(CASE tipo WHEN 'cancellati' THEN valore END) c
  FROM migrazioni_italiani WHERE codice='IT' GROUP BY anno,dimensione,categoria HAVING i=c)"""
prova("  ...e ISCRITTI != CANCELLATI: la 'corruzione' NON c'e'",
      con.execute(q3).fetchone()[0]==0)

print("\n  ancore (numeri di controllo dei TRAPPOLE.md — quelli erano giusti):")
for (anno,cls), att in ANCORE_IT.items():
    v=con.execute("""SELECT SUM(CASE tipo WHEN 'cancellati' THEN valore WHEN 'iscritti' THEN -valore END)
      FROM migrazioni_italiani WHERE codice='IT' AND anno=? AND dimensione='eta_laureati'
        AND categoria=?""",(anno,cls)).fetchone()[0]
    prova(f"  saldo netto laureati {cls} {anno} = +{att:,}", abs(v-att)<0.5, f"{v:+,.0f}")
v=con.execute("""SELECT SUM(CASE tipo WHEN 'cancellati' THEN valore WHEN 'iscritti' THEN -valore END)
  FROM migrazioni_italiani WHERE codice='IT' AND anno=2024 AND dimensione='eta_laureati'""").fetchone()[0]
prova("  saldo netto tutte le eta 2024 = +30.503", abs(v-30503)<0.5, f"{v:+,.0f}")

print("\n  migrazioni_stranieri: la gerarchia")
liv = sorted(S.livello.unique())
prova("  4 livelli", liv==["continente","paese","partizione_ue","totale"], str(liv))
q4="""SELECT COUNT(*), SUM(ABS(d)>0.5) FROM (
  SELECT (SELECT SUM(valore) FROM migrazioni_stranieri x
      WHERE x.anno=a.anno AND x.tipo=a.tipo AND x.livello='continente') - a.valore AS d
  FROM migrazioni_stranieri a WHERE a.livello='totale')"""
n4,b4 = con.execute(q4).fetchone()
prova("  Totale == Sigma 6 continenti", (b4 or 0)==0, f"{n4} celle, {b4 or 0} ecc.")
print("       (⚠ i TRAPPOLE.md dicono 'non contiene un totale nazionale': FALSO)")
q5="""SELECT COUNT(*) FROM (
  SELECT (SELECT SUM(valore) FROM migrazioni_stranieri x
      WHERE x.anno=a.anno AND x.tipo=a.tipo AND x.livello='paese') - a.valore AS d
  FROM migrazioni_stranieri a WHERE a.livello='totale' AND d < -0.5)"""
prova("  PROVA NEGATIVA: Sigma(21 paesi) < Totale, sempre",
      con.execute(q5).fetchone()[0]==46, f"{con.execute(q5).fetchone()[0]}/46")

for paese, att in ANCORE_ST.items():
    v=con.execute("""SELECT SUM(CASE tipo WHEN 'iscritti' THEN valore WHEN 'cancellati' THEN -valore END)
      FROM migrazioni_stranieri WHERE paese=? AND anno=2024""",(paese,)).fetchone()[0]
    prova(f"  saldo {paese} 2024 = +{att:,}", abs(v-att)<0.5, f"{v:+,.0f}")

con.close()
print("\nESITO:", "VERDE — trasferimenti certificati (2 tabelle)" if ok else "ROSSO — NON usare")
sys.exit(0 if ok else 1)
